import React, { useState, useRef } from 'react';
import { Heart, Home, Flower2, Image, Package, Download, Sparkles, User, Camera, Layers, ChevronRight, Upload, Wand2, BookOpen, ShoppingCart } from 'lucide-react';

/**
 * EMPATHY ENGINE: Complete Pipeline
 * 
 * Flow: Emotional Input → Character Story → Living Space → Wreath Design → Assembly Instructions → Product Package
 * 
 * Steps:
 * 1. User provides emotional input or uploads floral inventory images
 * 2. AI generates character story ("who lives here")
 * 3. AI generates living space scene based on character
 * 4. AI designs wreath using actual floral inventory that matches character/space
 * 5. Generate assembly instructions with layer-by-layer images
 * 6. Package everything for sale: story + blueprint + florals list + assembly guide
 */

export default function EmpathyEnginePipeline() {
  const [currentStep, setCurrentStep] = useState(0);
  const [pipelineData, setPipelineData] = useState({
    emotionalInput: '',
    floralInventory: [],
    characterStory: null,
    livingSpace: null,
    wreathDesign: null,
    assemblyGuide: null,
    productPackage: null
  });

  const steps = [
    { id: 'input', name: 'Emotional Input', icon: Heart },
    { id: 'character', name: 'Character Story', icon: User },
    { id: 'space', name: 'Living Space', icon: Home },
    { id: 'wreath', name: 'Wreath Design', icon: Flower2 },
    { id: 'assembly', name: 'Assembly Guide', icon: Layers },
    { id: 'package', name: 'Product Package', icon: Package }
  ];

  // Main render
  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '2rem'
    }}>
      {/* Header */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto 2rem',
        textAlign: 'center'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '1rem',
          marginBottom: '1rem'
        }}>
          <Sparkles size={40} color="white" />
          <h1 style={{
            fontSize: '3.5rem',
            fontWeight: '900',
            color: 'white',
            margin: 0,
            letterSpacing: '-0.02em'
          }}>
            Empathy Engine
          </h1>
        </div>
        <p style={{
          fontSize: '1.25rem',
          color: 'rgba(255,255,255,0.95)',
          margin: 0,
          fontWeight: '500'
        }}>
          From Feeling → Character → Space → Wreath → Sellable Product
        </p>
      </div>

      {/* Progress Stepper */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto 2rem',
        background: 'white',
        borderRadius: '20px',
        padding: '2rem',
        boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          position: 'relative'
        }}>
          {/* Progress Line */}
          <div style={{
            position: 'absolute',
            top: '20px',
            left: '40px',
            right: '40px',
            height: '4px',
            background: '#e5e7eb',
            zIndex: 0
          }}>
            <div style={{
              height: '100%',
              background: 'linear-gradient(90deg, #667eea, #764ba2)',
              width: `${(currentStep / (steps.length - 1)) * 100}%`,
              transition: 'width 0.5s ease'
            }} />
          </div>

          {/* Steps */}
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isComplete = index < currentStep;
            const isCurrent = index === currentStep;
            
            return (
              <div
                key={step.id}
                onClick={() => setCurrentStep(index)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem',
                  cursor: 'pointer',
                  position: 'relative',
                  zIndex: 1
                }}
              >
                <div style={{
                  width: '48px',
                  height: '48px',
                  borderRadius: '50%',
                  background: isComplete || isCurrent 
                    ? 'linear-gradient(135deg, #667eea, #764ba2)'
                    : '#e5e7eb',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.3s',
                  transform: isCurrent ? 'scale(1.1)' : 'scale(1)',
                  boxShadow: isCurrent ? '0 8px 20px rgba(102,126,234,0.4)' : 'none'
                }}>
                  <Icon size={24} color={isComplete || isCurrent ? 'white' : '#9ca3af'} />
                </div>
                <span style={{
                  fontSize: '0.875rem',
                  fontWeight: isCurrent ? '700' : '600',
                  color: isCurrent ? '#667eea' : '#6b7280',
                  textAlign: 'center',
                  maxWidth: '100px'
                }}>
                  {step.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        {currentStep === 0 && <StepEmotionalInput pipelineData={pipelineData} setPipelineData={setPipelineData} onNext={() => setCurrentStep(1)} />}
        {currentStep === 1 && <StepCharacterStory pipelineData={pipelineData} setPipelineData={setPipelineData} onNext={() => setCurrentStep(2)} onBack={() => setCurrentStep(0)} />}
        {currentStep === 2 && <StepLivingSpace pipelineData={pipelineData} setPipelineData={setPipelineData} onNext={() => setCurrentStep(3)} onBack={() => setCurrentStep(1)} />}
        {currentStep === 3 && <StepWreathDesign pipelineData={pipelineData} setPipelineData={setPipelineData} onNext={() => setCurrentStep(4)} onBack={() => setCurrentStep(2)} />}
        {currentStep === 4 && <StepAssemblyGuide pipelineData={pipelineData} setPipelineData={setPipelineData} onNext={() => setCurrentStep(5)} onBack={() => setCurrentStep(3)} />}
        {currentStep === 5 && <StepProductPackage pipelineData={pipelineData} onBack={() => setCurrentStep(4)} />}
      </div>
    </div>
  );
}

// ============================================
// STEP 1: EMOTIONAL INPUT
// ============================================

function StepEmotionalInput({ pipelineData, setPipelineData, onNext }) {
  const [emotionalInput, setEmotionalInput] = useState(pipelineData.emotionalInput || '');
  const [uploadedImages, setUploadedImages] = useState([]);
  const fileInputRef = useRef(null);

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    const imageUrls = files.map(file => URL.createObjectURL(file));
    setUploadedImages(prev => [...prev, ...imageUrls]);
  };

  const handleNext = () => {
    setPipelineData(prev => ({
      ...prev,
      emotionalInput,
      floralInventory: uploadedImages
    }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Start with Emotion or Floral Inventory
      </h2>
      
      <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
        Describe the emotional feeling you want to capture, or upload images of your floral inventory to design from.
      </p>

      {/* Emotional Input */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{
          display: 'block',
          fontSize: '1rem',
          fontWeight: '700',
          marginBottom: '0.5rem',
          color: '#1f2937'
        }}>
          Emotional Intent
        </label>
        <textarea
          value={emotionalInput}
          onChange={(e) => setEmotionalInput(e.target.value)}
          placeholder="Example: A sense of quiet hope during late winter, the feeling of sun finally warming your face after months of cold, the anticipation of renewal..."
          style={{
            width: '100%',
            minHeight: '150px',
            padding: '1rem',
            border: '2px solid #e5e7eb',
            borderRadius: '12px',
            fontSize: '1rem',
            fontFamily: 'inherit',
            resize: 'vertical',
            transition: 'border-color 0.2s'
          }}
          onFocus={(e) => e.target.style.borderColor = '#667eea'}
          onBlur={(e) => e.target.style.borderColor = '#e5e7eb'}
        />
      </div>

      {/* Floral Inventory Upload */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{
          display: 'block',
          fontSize: '1rem',
          fontWeight: '700',
          marginBottom: '0.5rem',
          color: '#1f2937'
        }}>
          Upload Floral Inventory Images (Optional)
        </label>
        
        <div
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: '2px dashed #d1d5db',
            borderRadius: '12px',
            padding: '3rem',
            textAlign: 'center',
            cursor: 'pointer',
            background: '#f9fafb',
            transition: 'all 0.2s'
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = '#667eea';
            e.currentTarget.style.background = '#f3f4f6';
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = '#d1d5db';
            e.currentTarget.style.background = '#f9fafb';
          }}
        >
          <Upload size={48} color="#9ca3af" style={{ margin: '0 auto 1rem' }} />
          <p style={{ fontSize: '1.125rem', fontWeight: '600', color: '#374151', margin: '0 0 0.5rem' }}>
            Click to upload floral inventory photos
          </p>
          <p style={{ fontSize: '0.875rem', color: '#6b7280', margin: 0 }}>
            PNG, JPG up to 10MB each
          </p>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          onChange={handleImageUpload}
          style={{ display: 'none' }}
        />

        {/* Uploaded Images Preview */}
        {uploadedImages.length > 0 && (
          <div style={{
            marginTop: '1rem',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
            gap: '1rem'
          }}>
            {uploadedImages.map((url, index) => (
              <div key={index} style={{
                position: 'relative',
                paddingBottom: '100%',
                borderRadius: '8px',
                overflow: 'hidden',
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
              }}>
                <img
                  src={url}
                  alt={`Floral inventory ${index + 1}`}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover'
                  }}
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Next Button */}
      <button
        onClick={handleNext}
        disabled={!emotionalInput && uploadedImages.length === 0}
        style={{
          width: '100%',
          padding: '1.25rem',
          background: emotionalInput || uploadedImages.length > 0
            ? 'linear-gradient(135deg, #667eea, #764ba2)'
            : '#e5e7eb',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1.125rem',
          fontWeight: '700',
          cursor: emotionalInput || uploadedImages.length > 0 ? 'pointer' : 'not-allowed',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          transition: 'transform 0.2s'
        }}
        onMouseEnter={(e) => {
          if (emotionalInput || uploadedImages.length > 0) {
            e.target.style.transform = 'translateY(-2px)';
          }
        }}
        onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
      >
        Generate Character Story
        <ChevronRight size={24} />
      </button>
    </div>
  );
}

// ============================================
// STEP 2: CHARACTER STORY ("Who Lives Here")
// ============================================

function StepCharacterStory({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [characterStory, setCharacterStory] = useState(pipelineData.characterStory || null);

  const generateCharacterStory = async () => {
    setIsGenerating(true);
    
    // Simulate AI generation (in real implementation, call Claude API)
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const story = {
      name: "Eleanor Hayes",
      age: "Early 60s",
      occupation: "Retired Botanical Illustrator",
      location: "Converted barn studio in rural Vermont",
      personality: "Contemplative, patient, deeply attuned to seasonal cycles",
      dailyLife: "Morning walks to collect specimens, afternoons documenting in watercolor, evenings reading by the fire",
      aesthetic: "Minimalist with intention, every object has meaning and history",
      emotionalState: "Peaceful anticipation - watching winter loosen its grip, observing the first signs of renewal",
      narrative: `Eleanor lives alone in a converted barn at the edge of a forest. She spent 40 years illustrating botanical reference books before retiring to focus on observational art. Her studio is sparse not from lack of resources but from decades of refining what truly matters.

She rises early, walks the same paths each morning, noting the exact moment when buds swell, when snow melts from specific stones, when light shifts angles. Her work is slow, deliberate, meditative. She's not documenting nature—she's in conversation with it.

The late winter months are her favorite. Others see dormancy; she sees preparation. The forcing bulbs on her workbench represent her philosophy: patience rewarded, life emerging from apparent emptiness.

Her wreath would capture this: the tension between winter's restraint and spring's promise. Not celebratory—contemplative. A meditation on cycles, on trust, on the mathematics of renewal.`,
      
      emotionalColors: ["Soft white", "Pearl gray", "Pale blush pink", "Cool blue-gray", "Emerging green"],
      floralPreferences: [
        "Pussy willows (early awakening)",
        "Hellebores (winter bloomers, nodding with humility)",
        "White ranunculus (layered complexity)",
        "Dried hydrangea (honoring what was)",
        "Eucalyptus (silvery restraint)"
      ],
      spaceRequirements: [
        "Abundant natural light, especially overcast quality",
        "Built-in workspace for specimen study",
        "Minimal furniture, maximum negative space",
        "Views to landscape (connection to observation)",
        "Cool color palette, soft materials"
      ]
    };
    
    setCharacterStory(story);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({
      ...prev,
      characterStory
    }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Who Lives Here?
      </h2>

      {!characterStory ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <User size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
            Generate a character story based on your emotional input
          </p>
          <button
            onClick={generateCharacterStory}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Wand2 size={20} />
            {isGenerating ? 'Generating Story...' : 'Generate Character Story'}
          </button>
        </div>
      ) : (
        <div>
          {/* Character Card */}
          <div style={{
            background: 'linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%)',
            borderRadius: '16px',
            padding: '2rem',
            marginBottom: '2rem'
          }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem', marginBottom: '2rem' }}>
              <div>
                <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '0.5rem' }}>
                  {characterStory.name}
                </h3>
                <p style={{ color: '#6b7280', marginBottom: '1rem' }}>
                  {characterStory.age} • {characterStory.occupation}
                </p>
                <div style={{ fontSize: '0.875rem', color: '#374151' }}>
                  <strong>Location:</strong> {characterStory.location}
                </div>
              </div>
              <div>
                <div style={{ marginBottom: '1rem' }}>
                  <strong style={{ display: 'block', marginBottom: '0.25rem', color: '#1f2937' }}>
                    Personality:
                  </strong>
                  <span style={{ color: '#6b7280', fontSize: '0.875rem' }}>
                    {characterStory.personality}
                  </span>
                </div>
                <div>
                  <strong style={{ display: 'block', marginBottom: '0.25rem', color: '#1f2937' }}>
                    Daily Life:
                  </strong>
                  <span style={{ color: '#6b7280', fontSize: '0.875rem' }}>
                    {characterStory.dailyLife}
                  </span>
                </div>
              </div>
            </div>

            {/* Narrative */}
            <div style={{
              background: 'white',
              padding: '1.5rem',
              borderRadius: '12px',
              marginBottom: '1.5rem'
            }}>
              <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '0.75rem', color: '#1f2937' }}>
                Story:
              </h4>
              <p style={{ fontSize: '0.9375rem', lineHeight: '1.7', color: '#374151', whiteSpace: 'pre-line' }}>
                {characterStory.narrative}
              </p>
            </div>

            {/* Floral Preferences */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div style={{ background: 'white', padding: '1rem', borderRadius: '12px' }}>
                <h4 style={{ fontSize: '0.875rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1f2937' }}>
                  Floral Preferences:
                </h4>
                <ul style={{ margin: 0, paddingLeft: '1.25rem', fontSize: '0.8125rem', color: '#6b7280' }}>
                  {characterStory.floralPreferences.map((pref, i) => (
                    <li key={i} style={{ marginBottom: '0.25rem' }}>{pref}</li>
                  ))}
                </ul>
              </div>
              <div style={{ background: 'white', padding: '1rem', borderRadius: '12px' }}>
                <h4 style={{ fontSize: '0.875rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1f2937' }}>
                  Emotional Color Palette:
                </h4>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {characterStory.emotionalColors.map((color, i) => (
                    <span key={i} style={{
                      padding: '0.25rem 0.75rem',
                      background: '#f3f4f6',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: '600',
                      color: '#374151'
                    }}>
                      {color}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button
              onClick={onBack}
              style={{
                flex: 1,
                padding: '1rem',
                background: '#f3f4f6',
                color: '#374151',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer'
              }}
            >
              Back
            </button>
            <button
              onClick={handleNext}
              style={{
                flex: 2,
                padding: '1rem',
                background: 'linear-gradient(135deg, #667eea, #764ba2)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem'
              }}
            >
              Generate Living Space
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// STEP 3: LIVING SPACE (Scene Generation with Layered Prompts)
// ============================================

function StepLivingSpace({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [livingSpace, setLivingSpace] = useState(pipelineData.livingSpace || null);

  const generateLivingSpace = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const space = {
      scenePrompt: `High-resolution interior photography of Eleanor's converted barn studio in rural Vermont. Long weathered white-painted workbench (7 feet) centered in minimalist space. Low linen-upholstered bench in corner with natural cushions. Floor-to-ceiling built-in shelving (pearl gray) on left wall. Wide plank gray-washed oak floors. Tall Crittall-style windows (10 feet, matte black steel) along right wall showing winter Vermont forest with bare trees, melting snow patches. Soft overcast afternoon light (3-4pm) creating even shadowless illumination, cool temperature (5500K). Sparse winter botanicals: pussy willows in frosted glass, hellebores in white ceramic, dried specimens. Forcing bulbs showing green shoots. Cool palette: 70% whites and grays, 30% subtle accents. Contemplative, minimalist, wabi-sabi aesthetic. 50mm f/4, rule of thirds. Professional architectural photography, 8K, Cereal magazine quality.`,
      
      layers: {
        spatial: {
          enabled: true,
          weight: 1.2,
          prompt: "Converted barn studio, Vermont. Long weathered white-painted workbench (7 feet) centered. Low linen bench corner. Floor-to-ceiling built-in shelving (pearl gray) left wall. Gray-washed wide plank oak floors. Tall Crittall windows (10 feet, black steel) right wall. High ceilings with exposed whitewashed beams."
        },
        lighting: {
          enabled: true,
          weight: 1.4,
          prompt: "Soft overcast afternoon light (3-4pm) from tall windows right side. Even shadowless illumination. Cool color temperature (5500K). Misty ethereal quality. No harsh shadows, gentle graduated tones. Slight warmth reflected from natural materials."
        },
        elements: {
          enabled: true,
          weight: 1.1,
          prompt: "Sparse winter botanicals: pussy willows with silver catkins in frosted glass cylinder, hellebores (pale pink) in white ceramic vase, dried specimens in glass jars. Forcing bulbs (paperwhites, hyacinth) in terracotta showing green shoots. Open leather plant journal with watercolors. Smooth river stones. Minimal styling, intentional negative space."
        },
        color: {
          enabled: true,
          weight: 1.2,
          prompt: "Cool winter palette. Soft whites, pearl grays, cool mid-grays dominant (70%). Minimal color: pale pink hellebores, soft sage green, emerging green shoots (30%). Natural materials: gray-washed oak, white-painted pine, natural linen, undyed wool. Desaturated, muted tones."
        },
        camera: {
          enabled: true,
          weight: 1.0,
          prompt: "50mm prime lens, f/4 aperture for extended depth of field. Standing height (5.5 feet), straight-on minimal angle. Rule of thirds: workbench lower third. Golden ratio visual weight left (70/30). Negative space upper-right and across surface."
        },
        mood: {
          enabled: true,
          weight: 1.1,
          prompt: "Minimalist, contemplative, transitional, ethereal, wabi-sabi. Scandinavian-Japanese fusion. Winter awakening, botanical study, scholarly, peaceful, meditative. Cereal magazine aesthetic, monastic quality. Photorealistic textures, 8K resolution, editorial quality."
        }
      },
      
      imageURL: "https://placeholder-for-generated-scene.jpg", // Would be actual generated image
      midjourneySettings: "--ar 4:3 --style raw --stylize 100 --v 6"
    };
    
    setLivingSpace(space);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({
      ...prev,
      livingSpace
    }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Eleanor's Living Space
      </h2>

      {!livingSpace ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Home size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
            Generate the living space using layered scene prompts based on Eleanor's story
          </p>
          <button
            onClick={generateLivingSpace}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Camera size={20} />
            {isGenerating ? 'Generating Scene...' : 'Generate Living Space'}
          </button>
        </div>
      ) : (
        <div>
          {/* Scene Preview */}
          <div style={{
            background: '#f3f4f6',
            borderRadius: '16px',
            padding: '1rem',
            marginBottom: '2rem',
            aspectRatio: '4/3',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <div style={{ textAlign: 'center' }}>
              <Camera size={64} color="#9ca3af" style={{ margin: '0 auto 1rem' }} />
              <p style={{ color: '#6b7280', fontSize: '0.875rem' }}>
                Generated scene would appear here
              </p>
              <p style={{ color: '#9ca3af', fontSize: '0.75rem', marginTop: '0.5rem' }}>
                (Minimalist barn studio with winter light)
              </p>
            </div>
          </div>

          {/* Layer Breakdown */}
          <div style={{ marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700', marginBottom: '1rem', color: '#1f2937' }}>
              Scene Layers (Compositional Prompt)
            </h3>
            {Object.entries(livingSpace.layers).map(([key, layer]) => (
              <div key={key} style={{
                background: '#f9fafb',
                padding: '1rem',
                borderRadius: '12px',
                marginBottom: '0.75rem',
                borderLeft: `4px solid ${layer.enabled ? '#667eea' : '#e5e7eb'}`
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span style={{ fontSize: '0.875rem', fontWeight: '700', color: '#1f2937', textTransform: 'capitalize' }}>
                    {key}
                  </span>
                  {layer.weight > 1 && (
                    <span style={{
                      padding: '0.125rem 0.5rem',
                      background: '#fbbf24',
                      color: 'white',
                      borderRadius: '6px',
                      fontSize: '0.75rem',
                      fontWeight: '700'
                    }}>
                      {layer.weight}x Priority
                    </span>
                  )}
                </div>
                <p style={{ fontSize: '0.8125rem', color: '#6b7280', margin: 0, lineHeight: '1.5' }}>
                  {layer.prompt}
                </p>
              </div>
            ))}
          </div>

          {/* Master Prompt */}
          <div style={{
            background: '#f0fdf4',
            border: '1px solid #86efac',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '2rem'
          }}>
            <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '0.75rem', color: '#166534' }}>
              Complete Scene Prompt:
            </h4>
            <p style={{
              fontSize: '0.875rem',
              lineHeight: '1.6',
              color: '#15803d',
              fontFamily: '"SF Mono", Monaco, monospace',
              margin: 0
            }}>
              {livingSpace.scenePrompt}
            </p>
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button
              onClick={onBack}
              style={{
                flex: 1,
                padding: '1rem',
                background: '#f3f4f6',
                color: '#374151',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer'
              }}
            >
              Back
            </button>
            <button
              onClick={handleNext}
              style={{
                flex: 2,
                padding: '1rem',
                background: 'linear-gradient(135deg, #667eea, #764ba2)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem'
              }}
            >
              Design Wreath from Inventory
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// STEP 4: WREATH DESIGN (Using Actual Floral Inventory)
// ============================================

function StepWreathDesign({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [wreathDesign, setWreathDesign] = useState(pipelineData.wreathDesign || null);

  const generateWreathDesign = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const wreath = {
      name: "Winter's Patience",
      subtitle: "A meditation on Eleanor's quiet anticipation",
      
      specifications: {
        size: "20 inches diameter",
        depth: "5-6 inches",
        base: "Whitewashed grapevine wreath",
        style: "Minimalist, asymmetric, negative space intentional"
      },
      
      // This would come from actual uploaded floral inventory
      selectedFlorals: [
        {
          id: "inv_001",
          name: "Pussy Willow Stems",
          quantity: 5,
          size: "8-10 inches",
          position: "Emerging from 45°, 140°, 225°, 310°",
          reasoning: "Eleanor's favorite - early awakening, first signs of spring",
          inventoryImage: "pussy-willow-inventory.jpg"
        },
        {
          id: "inv_002",
          name: "White Ranunculus",
          quantity: 2,
          size: "4 inch diameter",
          position: "Upper right cluster (50°)",
          reasoning: "Layered complexity mirrors Eleanor's philosophical depth",
          inventoryImage: "white-ranunculus-inventory.jpg"
        },
        {
          id: "inv_003",
          name: "Pale Pink Hellebores",
          quantity: 3,
          size: "3.5 inch diameter",
          position: "Lower left cluster (220°)",
          reasoning: "Winter bloomers, nodding with humility - Eleanor's character",
          inventoryImage: "hellebore-inventory.jpg"
        },
        {
          id: "inv_004",
          name: "Silver Dollar Eucalyptus",
          quantity: 12,
          size: "3-4 inch leaves",
          position: "Base layer, 60% coverage",
          reasoning: "Silvery restraint, Eleanor's minimalist aesthetic",
          inventoryImage: "eucalyptus-inventory.jpg"
        },
        {
          id: "inv_005",
          name: "Dried Hydrangea Heads",
          quantity: 2,
          size: "3 inch clusters, faded taupe",
          position: "Mid-right accent (135°)",
          reasoning: "Honoring what was - Eleanor values cycles and impermanence",
          inventoryImage: "dried-hydrangea-inventory.jpg"
        }
      ],
      
      assemblyLayers: [
        {
          layerNumber: 1,
          name: "Base Foundation",
          description: "Attach eucalyptus base layer using 24-gauge wire",
          floralsUsed: ["Silver Dollar Eucalyptus"],
          timeEstimate: "15 minutes",
          imagePrompt: "Close-up of whitewashed grapevine wreath with silver dollar eucalyptus stems being wired to base, showing 60% coverage with intentional gaps, some stems angled 15-30° off perpendicular for depth"
        },
        {
          layerNumber: 2,
          name: "Primary Focal Cluster (Upper Right)",
          description: "Build first focal point at 50° position",
          floralsUsed: ["White Ranunculus", "Pussy Willow Stems"],
          timeEstimate: "10 minutes",
          imagePrompt: "Detail shot of 2 white ranunculus (4 inch) anchoring upper right cluster, with pussy willow stems emerging behind them, layered 2-4 inches deep creating sculptural dimension"
        },
        {
          layerNumber: 3,
          name: "Secondary Focal Cluster (Lower Left)",
          description: "Build second focal point at 220° position",
          floralsUsed: ["Pale Pink Hellebores"],
          timeEstimate: "8 minutes",
          imagePrompt: "Close-up of 3 pale pink hellebores positioned in lower left cluster, nodding blooms creating natural cascade, stems secured with 28-gauge wire"
        },
        {
          layerNumber: 4,
          name: "Accent Elements",
          description: "Add dried hydrangea and final pussy willows",
          floralsUsed: ["Dried Hydrangea Heads", "Pussy Willow Stems"],
          timeEstimate: "10 minutes",
          imagePrompt: "Detail of dried taupe hydrangea heads tucked into mid-right position, pussy willow stems emerging from wreath depth at designated angles (45°, 140°, 225°, 310°)"
        },
        {
          layerNumber: 5,
          name: "Final Adjustments",
          description: "Balance negative space, ensure asymmetry, quality check",
          floralsUsed: ["All elements"],
          timeEstimate: "7 minutes",
          imagePrompt: "Full wreath view showing completed composition with intentional negative space, asymmetric focal clusters following golden ratio, depth variation throughout"
        }
      ],
      
      emotionalStory: `This wreath captures Eleanor's philosophy: patience rewarded, life emerging from apparent emptiness.

The pussy willows represent her daily observation - she knows exactly when their silver catkins emerge, has documented this moment for forty years. They project outward at specific angles because that's how they grow naturally; Eleanor would never force them into symmetry.

The hellebores nod downward, humble bloomers that flower while snow still covers the ground. Eleanor sees herself in them: quiet strength, blooming without fanfare.

The eucalyptus creates restraint - 60% coverage with intentional gaps. The negative space isn't absence; it's presence. It's the pause between breaths, the rest between notes that makes music meaningful.

This wreath doesn't celebrate spring's arrival. It meditates on the threshold. It asks: what does it mean to wait with open awareness? What wisdom lives in dormancy?

Eleanor would hang this on her studio door. Not as decoration, but as reminder: renewal is inevitable, patience is its own form of hope.`,
      
      manufacturingNotes: {
        totalTime: "50 minutes",
        wireGauge: "24-gauge for structure, 28-gauge for delicate stems",
        adhesive: "Minimal hot glue, only where necessary for stability",
        finishing: "Light misting of water to enhance natural textures",
        packaging: "24×24×8 inch box, wrapped in natural kraft paper, labeled with Eleanor's story"
      },
      
      pricing: {
        materialCost: "$42-58",
        laborCost: "$20-30 (50 min @ $25/hr)",
        totalCost: "$62-88",
        suggestedRetail: "$185-225",
        digitalBlueprintOnly: "$37"
      }
    };
    
    setWreathDesign(wreath);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({
      ...prev,
      wreathDesign
    }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
      maxHeight: '80vh',
      overflowY: 'auto'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Wreath Design from Inventory
      </h2>

      {!wreathDesign ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Flower2 size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
            Design a wreath using your actual floral inventory that matches Eleanor's character and space
          </p>
          <button
            onClick={generateWreathDesign}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Wand2 size={20} />
            {isGenerating ? 'Designing Wreath...' : 'Design Wreath from Inventory'}
          </button>
        </div>
      ) : (
        <div>
          {/* Wreath Header */}
          <div style={{
            background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
            borderRadius: '16px',
            padding: '2rem',
            marginBottom: '2rem'
          }}>
            <h3 style={{ fontSize: '1.75rem', fontWeight: '800', marginBottom: '0.5rem', color: '#166534' }}>
              "{wreathDesign.name}"
            </h3>
            <p style={{ fontSize: '1.125rem', color: '#15803d', marginBottom: '1.5rem', fontStyle: 'italic' }}>
              {wreathDesign.subtitle}
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem' }}>
              {Object.entries(wreathDesign.specifications).map(([key, value]) => (
                <div key={key}>
                  <div style={{ fontSize: '0.75rem', color: '#16a34a', fontWeight: '600', textTransform: 'uppercase', marginBottom: '0.25rem' }}>
                    {key}
                  </div>
                  <div style={{ fontSize: '0.875rem', color: '#166534', fontWeight: '700' }}>
                    {value}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Selected Florals from Inventory */}
          <div style={{ marginBottom: '2rem' }}>
            <h4 style={{ fontSize: '1.25rem', fontWeight: '700', marginBottom: '1rem', color: '#1f2937' }}>
              Florals from Your Inventory
            </h4>
            <div style={{ display: 'grid', gap: '1rem' }}>
              {wreathDesign.selectedFlorals.map((floral, index) => (
                <div key={floral.id} style={{
                  background: '#f9fafb',
                  borderRadius: '12px',
                  padding: '1rem',
                  display: 'grid',
                  gridTemplateColumns: '80px 1fr',
                  gap: '1rem'
                }}>
                  <div style={{
                    background: '#e5e7eb',
                    borderRadius: '8px',
                    aspectRatio: '1/1',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    <Flower2 size={32} color="#9ca3af" />
                  </div>
                  <div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '0.5rem' }}>
                      <h5 style={{ fontSize: '1rem', fontWeight: '700', margin: 0, color: '#1f2937' }}>
                        {floral.name}
                      </h5>
                      <span style={{
                        padding: '0.25rem 0.75rem',
                        background: '#667eea',
                        color: 'white',
                        borderRadius: '6px',
                        fontSize: '0.75rem',
                        fontWeight: '700'
                      }}>
                        {floral.quantity}x
                      </span>
                    </div>
                    <div style={{ fontSize: '0.8125rem', color: '#6b7280', marginBottom: '0.5rem' }}>
                      <strong>Size:</strong> {floral.size} • <strong>Position:</strong> {floral.position}
                    </div>
                    <div style={{ fontSize: '0.8125rem', color: '#374151', fontStyle: 'italic' }}>
                      Why: {floral.reasoning}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Emotional Story */}
          <div style={{
            background: '#fef3c7',
            border: '2px solid #fbbf24',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '2rem'
          }}>
            <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '0.75rem', color: '#92400e', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Heart size={18} />
              Emotional Story
            </h4>
            <p style={{ fontSize: '0.9375rem', lineHeight: '1.7', color: '#78350f', margin: 0, whiteSpace: 'pre-line' }}>
              {wreathDesign.emotionalStory}
            </p>
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button
              onClick={onBack}
              style={{
                flex: 1,
                padding: '1rem',
                background: '#f3f4f6',
                color: '#374151',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer'
              }}
            >
              Back
            </button>
            <button
              onClick={handleNext}
              style={{
                flex: 2,
                padding: '1rem',
                background: 'linear-gradient(135deg, #667eea, #764ba2)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem'
              }}
            >
              Create Assembly Guide
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// STEP 5: ASSEMBLY GUIDE (Layer-by-Layer Instructions with Images)
// ============================================

function StepAssemblyGuide({ pipelineData, setPipelineData, onNext, onBack }) {
  const wreathDesign = pipelineData.wreathDesign;
  const [selectedLayer, setSelectedLayer] = useState(0);

  const handleNext = () => {
    setPipelineData(prev => ({
      ...prev,
      assemblyGuide: {
        layers: wreathDesign.assemblyLayers,
        totalTime: wreathDesign.manufacturingNotes.totalTime,
        completedAt: new Date().toISOString()
      }
    }));
    onNext();
  };

  if (!wreathDesign) return null;

  const currentLayer = wreathDesign.assemblyLayers[selectedLayer];

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Assembly Guide
      </h2>

      <p style={{ fontSize: '1rem', color: '#6b7280', marginBottom: '2rem' }}>
        Layer-by-layer instructions with generated images for "{wreathDesign.name}"
      </p>

      {/* Layer Navigator */}
      <div style={{
        display: 'flex',
        gap: '0.5rem',
        marginBottom: '2rem',
        overflowX: 'auto',
        paddingBottom: '0.5rem'
      }}>
        {wreathDesign.assemblyLayers.map((layer, index) => (
          <button
            key={index}
            onClick={() => setSelectedLayer(index)}
            style={{
              padding: '0.75rem 1.5rem',
              background: selectedLayer === index
                ? 'linear-gradient(135deg, #667eea, #764ba2)'
                : '#f3f4f6',
              color: selectedLayer === index ? 'white' : '#374151',
              border: 'none',
              borderRadius: '10px',
              fontSize: '0.875rem',
              fontWeight: '700',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              transition: 'all 0.2s'
            }}
          >
            Layer {layer.layerNumber}
          </button>
        ))}
      </div>

      {/* Current Layer Detail */}
      <div style={{
        background: '#f9fafb',
        borderRadius: '16px',
        padding: '2rem',
        marginBottom: '2rem'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '1rem' }}>
          <div>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '0.5rem', color: '#1f2937' }}>
              Layer {currentLayer.layerNumber}: {currentLayer.name}
            </h3>
            <p style={{ fontSize: '1rem', color: '#6b7280', margin: 0 }}>
              {currentLayer.description}
            </p>
          </div>
          <span style={{
            padding: '0.5rem 1rem',
            background: '#dbeafe',
            color: '#1e40af',
            borderRadius: '8px',
            fontSize: '0.875rem',
            fontWeight: '700',
            whiteSpace: 'nowrap'
          }}>
            ⏱ {currentLayer.timeEstimate}
          </span>
        </div>

        {/* Generated Image Placeholder */}
        <div style={{
          background: '#e5e7eb',
          borderRadius: '12px',
          aspectRatio: '4/3',
          marginBottom: '1.5rem',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '2rem'
        }}>
          <Camera size={48} color="#9ca3af" style={{ marginBottom: '1rem' }} />
          <p style={{ fontSize: '0.875rem', color: '#6b7280', textAlign: 'center', marginBottom: '1rem' }}>
            Generated image for this layer would appear here
          </p>
          <div style={{
            background: 'white',
            padding: '1rem',
            borderRadius: '8px',
            fontSize: '0.75rem',
            color: '#374151',
            fontFamily: '"SF Mono", Monaco, monospace',
            maxWidth: '500px',
            lineHeight: '1.5'
          }}>
            <strong>Image Prompt:</strong><br />
            {currentLayer.imagePrompt}
          </div>
        </div>

        {/* Florals Used */}
        <div>
          <h4 style={{ fontSize: '0.875rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1f2937' }}>
            Florals Used in This Layer:
          </h4>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            {currentLayer.floralsUsed.map((floral, index) => (
              <span key={index} style={{
                padding: '0.375rem 0.75rem',
                background: '#ede9fe',
                color: '#5b21b6',
                borderRadius: '6px',
                fontSize: '0.8125rem',
                fontWeight: '600'
              }}>
                {floral}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      <div style={{
        background: '#fef3c7',
        borderRadius: '12px',
        padding: '1rem',
        marginBottom: '2rem',
        display: 'flex',
        alignItems: 'center',
        gap: '1rem'
      }}>
        <BookOpen size={24} color="#92400e" />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '0.875rem', fontWeight: '700', color: '#92400e', marginBottom: '0.25rem' }}>
            Progress: Layer {currentLayer.layerNumber} of {wreathDesign.assemblyLayers.length}
          </div>
          <div style={{ fontSize: '0.75rem', color: '#78350f' }}>
            Total assembly time: {wreathDesign.manufacturingNotes.totalTime}
          </div>
        </div>
        <div style={{
          width: '120px',
          height: '8px',
          background: '#fde68a',
          borderRadius: '4px',
          overflow: 'hidden'
        }}>
          <div style={{
            width: `${((selectedLayer + 1) / wreathDesign.assemblyLayers.length) * 100}%`,
            height: '100%',
            background: '#f59e0b',
            transition: 'width 0.3s'
          }} />
        </div>
      </div>

      {/* Navigation */}
      <div style={{ display: 'flex', gap: '1rem' }}>
        <button
          onClick={onBack}
          style={{
            flex: 1,
            padding: '1rem',
            background: '#f3f4f6',
            color: '#374151',
            border: 'none',
            borderRadius: '12px',
            fontSize: '1rem',
            fontWeight: '700',
            cursor: 'pointer'
          }}
        >
          Back
        </button>
        <button
          onClick={handleNext}
          style={{
            flex: 2,
            padding: '1rem',
            background: 'linear-gradient(135deg, #667eea, #764ba2)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '1rem',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem'
          }}
        >
          Create Product Package
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}

// ============================================
// STEP 6: PRODUCT PACKAGE (Complete Sellable Package)
// ============================================

function StepProductPackage({ pipelineData, onBack }) {
  const { characterStory, livingSpace, wreathDesign } = pipelineData;

  const productPackage = {
    name: `"${wreathDesign.name}" Complete Collection`,
    includes: [
      "Character Story: Who this wreath is for",
      "Living Space Scene (with layered prompts)",
      "Wreath Design Blueprint (polar coordinates, specifications)",
      "Complete Floral Inventory List (with quantities and positioning)",
      "Layer-by-Layer Assembly Guide (5 steps with image prompts)",
      "Emotional Story & Meaning",
      "Manufacturing Notes & Cost Breakdown",
      "High-Resolution Scene Images (generated)",
      "Commercial License (if applicable)"
    ],
    formats: [
      "PDF Blueprint (print-ready)",
      "JSON Data (for developers/automation)",
      "Image Assets (scene + assembly layers)",
      "Text Files (story, prompts, instructions)"
    ],
    pricing: {
      digital: "$37 (blueprint + story + assembly guide)",
      physicalKit: "$145 (includes all florals from inventory)",
      finished: "$215 (hand-assembled wreath + story card)",
      commercial: "$97 (digital + commercial use license)"
    }
  };

  const handleExport = () => {
    const fullPackage = {
      metadata: {
        packageName: productPackage.name,
        createdAt: new Date().toISOString(),
        version: "1.0"
      },
      characterStory,
      livingSpace,
      wreathDesign,
      assemblyGuide: pipelineData.assemblyGuide,
      productPackage
    };

    const blob = new Blob([JSON.stringify(fullPackage, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${wreathDesign.name.replace(/[^a-z0-9]/gi, '-').toLowerCase()}-complete-package.json`;
    a.click();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
      maxHeight: '80vh',
      overflowY: 'auto'
    }}>
      <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <div style={{
          width: '80px',
          height: '80px',
          background: 'linear-gradient(135deg, #667eea, #764ba2)',
          borderRadius: '50%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 1.5rem'
        }}>
          <Package size={40} color="white" />
        </div>
        <h2 style={{
          fontSize: '2.5rem',
          fontWeight: '900',
          marginBottom: '0.5rem',
          background: 'linear-gradient(135deg, #667eea, #764ba2)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          Product Package Ready!
        </h2>
        <p style={{ fontSize: '1.25rem', color: '#6b7280' }}>
          Complete sellable package for "{wreathDesign.name}"
        </p>
      </div>

      {/* Package Contents */}
      <div style={{
        background: 'linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%)',
        borderRadius: '16px',
        padding: '2rem',
        marginBottom: '2rem'
      }}>
        <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '1.5rem', color: '#166534' }}>
          Package Includes:
        </h3>
        <div style={{ display: 'grid', gap: '0.75rem' }}>
          {productPackage.includes.map((item, index) => (
            <div key={index} style={{
              background: 'white',
              padding: '1rem',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem'
            }}>
              <div style={{
                width: '24px',
                height: '24px',
                background: '#10b981',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <span style={{ color: 'white', fontSize: '0.75rem', fontWeight: '700' }}>✓</span>
              </div>
              <span style={{ fontSize: '0.9375rem', color: '#166534', fontWeight: '600' }}>
                {item}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Pricing Options */}
      <div style={{ marginBottom: '2rem' }}>
        <h3 style={{ fontSize: '1.25rem', fontWeight: '700', marginBottom: '1rem', color: '#1f2937' }}>
          Pricing Options:
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem' }}>
          {Object.entries(productPackage.pricing).map(([type, price]) => (
            <div key={type} style={{
              background: '#f9fafb',
              border: '2px solid #e5e7eb',
              borderRadius: '12px',
              padding: '1.5rem',
              textAlign: 'center',
              transition: 'all 0.2s',
              cursor: 'pointer'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#667eea';
              e.currentTarget.style.transform = 'translateY(-2px)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e5e7eb';
              e.currentTarget.style.transform = 'translateY(0)';
            }}>
              <div style={{
                fontSize: '0.75rem',
                fontWeight: '700',
                color: '#6b7280',
                textTransform: 'uppercase',
                marginBottom: '0.5rem',
                letterSpacing: '0.05em'
              }}>
                {type}
              </div>
              <div style={{
                fontSize: '2rem',
                fontWeight: '900',
                background: 'linear-gradient(135deg, #667eea, #764ba2)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}>
                {price.split('(')[0]}
              </div>
              {price.includes('(') && (
                <div style={{ fontSize: '0.8125rem', color: '#9ca3af', marginTop: '0.25rem' }}>
                  {price.split('(')[1].replace(')', '')}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Export Formats */}
      <div style={{
        background: '#ede9fe',
        borderRadius: '12px',
        padding: '1.5rem',
        marginBottom: '2rem'
      }}>
        <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '1rem', color: '#5b21b6' }}>
          Available Formats:
        </h4>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
          {productPackage.formats.map((format, index) => (
            <span key={index} style={{
              padding: '0.5rem 1rem',
              background: 'white',
              color: '#5b21b6',
              borderRadius: '8px',
              fontSize: '0.875rem',
              fontWeight: '600'
            }}>
              {format}
            </span>
          ))}
        </div>
      </div>

      {/* Action Buttons */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
        <button
          onClick={handleExport}
          style={{
            padding: '1.25rem',
            background: 'linear-gradient(135deg, #667eea, #764ba2)',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '1rem',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem'
          }}
        >
          <Download size={20} />
          Export Complete Package
        </button>
        <button
          style={{
            padding: '1.25rem',
            background: '#10b981',
            color: 'white',
            border: 'none',
            borderRadius: '12px',
            fontSize: '1rem',
            fontWeight: '700',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.5rem'
          }}
        >
          <ShoppingCart size={20} />
          List on Etsy
        </button>
      </div>

      {/* Summary Stats */}
      <div style={{
        background: '#fef3c7',
        borderRadius: '12px',
        padding: '1.5rem',
        marginBottom: '2rem'
      }}>
        <h4 style={{ fontSize: '1rem', fontWeight: '700', marginBottom: '1rem', color: '#92400e' }}>
          Package Summary:
        </h4>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#78350f', marginBottom: '0.25rem' }}>Character</div>
            <div style={{ fontSize: '1.125rem', fontWeight: '700', color: '#92400e' }}>{characterStory.name}</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#78350f', marginBottom: '0.25rem' }}>Florals Used</div>
            <div style={{ fontSize: '1.125rem', fontWeight: '700', color: '#92400e' }}>{wreathDesign.selectedFlorals.length} types</div>
          </div>
          <div>
            <div style={{ fontSize: '0.75rem', color: '#78350f', marginBottom: '0.25rem' }}>Assembly Time</div>
            <div style={{ fontSize: '1.125rem', fontWeight: '700', color: '#92400e' }}>{wreathDesign.manufacturingNotes.totalTime}</div>
          </div>
        </div>
      </div>

      {/* Back Button */}
      <button
        onClick={onBack}
        style={{
          width: '100%',
          padding: '1rem',
          background: '#f3f4f6',
          color: '#374151',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1rem',
          fontWeight: '700',
          cursor: 'pointer'
        }}
      >
        Back to Assembly Guide
      </button>
    </div>
  );
}
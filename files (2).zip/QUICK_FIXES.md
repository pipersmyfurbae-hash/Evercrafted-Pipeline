# QUICK FIXES FOR TEST HTML

## Issue 1: Same Character Every Time

**Problem:** Character is hardcoded as "Eleanor Hayes" every time.

**Solution:** The generateCharacter() function needs to parse the emotional input and create variations.

**Quick Fix (add after line 387):**

```javascript
function generateCharacter() {
    const emotionalInput = document.getElementById('emotionalInput').value.toLowerCase();
    if (!emotionalInput) {
        alert('Please enter emotional intent first!');
        return;
    }

    // Parse emotions from input
    const emotions = [];
    if (emotionalInput.includes('hope')) emotions.push('hopeful', 'optimistic');
    if (emotionalInput.includes('quiet') || emotionalInput.includes('peaceful')) emotions.push('contemplative', 'peaceful');
    if (emotionalInput.includes('joy')) emotions.push('joyful', 'bright');
    if (emotionalInput.includes('warm')) emotions.push('warm', 'comforting');
    if (emotionalInput.includes('melancholy')) emotions.push('melancholic', 'nostalgic');
    if (emotions.length === 0) emotions.push('contemplative', 'elegant');

    // Randomize character details
    const firstNames = ["Eleanor", "Margaret", "Claire", "Isabelle", "Sophia", "Charlotte"];
    const lastNames = ["Hayes", "Morrison", "Bennett", "Sterling", "Foster", "Chen"];
    const name = firstNames[Math.floor(Math.random() * firstNames.length)] + " " + 
                 lastNames[Math.floor(Math.random() * lastNames.length)];

    const occupations = [
        "Retired Botanical Illustrator",
        "Freelance Watercolor Artist", 
        "Independent Ceramicist",
        "Published Nature Photographer"
    ];
    const occupation = occupations[Math.floor(Math.random() * occupations.length)];

    // Determine colors based on input
    let colors = ["Soft white", "Pearl gray", "Pale blush pink"];
    if (emotionalInput.includes('warm') || emotionalInput.includes('autumn')) {
        colors = ["Burnt orange", "Deep burgundy", "Golden yellow"];
    } else if (emotionalInput.includes('spring')) {
        colors = ["Pale pink", "Soft lavender", "Fresh green"];
    }

    characterStory = {
        name,
        age: "40s-60s",
        occupation,
        personality: emotions.join(', '),
        aesthetic: emotionalInput.includes('warm') ? "Warm and layered" : "Minimalist restraint",
        emotionalKeywords: emotions.slice(0, 6),
        season: emotionalInput.includes('winter') ? 'winter' : 'all-season',
        mood: emotions[0] + ' and ' + (emotions[1] || 'elegant'),
        wreathCharacteristics: "Sparse, asymmetric, intentional negative space",
        emotionalColors: colors,
        narrative: `${name} works as a ${occupation.toLowerCase()}. They have a ${emotions[0]} approach to their craft and living space, reflecting ${emotionalInput.substring(0, 80)}...`
    };

    // Rest of display code...
}
```

---

## Issue 2: Image Loading Blocked (CSP)

**Problem:** Pioneer Wholesale images blocked by Content Security Policy

**Error:** `violates the following Content Security Policy directive: "img-src..."`

**What This Means:**
Claude.ai is blocking external images for security. This is expected.

**Solutions:**

### Option A: Test URLs in Midjourney (RECOMMENDED)
```
1. Copy a floral image URL from your inventory
2. Open Midjourney Discord
3. Type: /imagine https://www.pioneerwholesaleco.com/media/catalog/product/.../pww2330cr.jpg
4. See if it loads
```

**If it works in Midjourney:** ✅ Perfect! Use URLs directly in prompts
**If it doesn't work:** ❌ Need to re-host images

### Option B: Hide Images in Test HTML
Since the test HTML just shows the list anyway, you can remove image display:

**In the floral selection display (line ~310), change:**
```html
<!-- FROM: -->
<img src="${floral.images.main}" ...>

<!-- TO: -->
<div style="background: #e5e7eb; width: 80px; height: 80px; display: flex; align-items: center; justify-content: center;">
    <span style="font-size: 2rem;">🌸</span>
</div>
```

This removes CSP errors and still shows the florals clearly.

### Option C: Re-host Images (If Midjourney blocks them too)
```javascript
// Add this function to upload to Imgur
async function rehost ImageToImgur(imageURL) {
    // Download image
    const response = await fetch(imageURL);
    const blob = await response.blob();
    
    // Convert to base64
    const base64 = await blobToBase64(blob);
    
    // Upload to Imgur
    const imgurResponse = await fetch('https://api.imgur.com/3/image', {
        method: 'POST',
        headers: {
            'Authorization': 'Client-ID YOUR_CLIENT_ID',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            image: base64.split(',')[1],
            type: 'base64'
        })
    });
    
    const data = await imgurResponse.json();
    return data.data.link; // New Imgur URL
}
```

---

## IMMEDIATE ACTION PLAN:

### **For Now (Testing):**
1. ✅ **Ignore the image CSP errors** - they don't affect functionality
2. ✅ **Test the wreath generation** - should work despite image errors
3. ✅ **Copy the prompts** - that's what matters!

### **For Production:**
1. 🔴 **Test Pioneer URLs in Midjourney FIRST**
2. ✅ **If they work** → Use directly (no changes needed!)
3. ❌ **If they don't** → Re-host to Imgur/Cloudinary

### **To Make Characters Dynamic:**
1. Replace the hardcoded characterStory object
2. Add randomization based on emotional input
3. Parse keywords from user input

---

## WHAT TO DO RIGHT NOW:

**Just test wreath generation!** The CSP errors are annoying but don't break anything. You should still be able to:

1. ✅ Upload inventory
2. ✅ Enter emotion
3. ✅ Generate character (even though same one)
4. ✅ Select florals
5. ✅ **Generate wreath** ← Should work now!
6. ✅ **Copy prompts** ← This is what you need!

Then paste those prompts into Midjourney and see what happens!

---

## NEXT SESSION:

We'll build a proper version that:
1. ✅ Calls Claude API for unique characters
2. ✅ Handles images properly
3. ✅ Generates blueprint PNGs
4. ✅ Auto-uploads to Imgur
5. ✅ Creates complete packages

But for NOW - just test if the wreath generation works! 🎯

import React, { useState, useRef } from 'react';
import { Camera, Lightbulb, Layers, Image, Palette, Download, Copy, Eye, Settings, Plus, Trash2, ChevronDown, ChevronRight, Save, RefreshCw } from 'lucide-react';

// Layer categories matching the blueprint structure
const LAYER_CATEGORIES = {
  spatial: {
    name: 'Spatial Architecture',
    icon: Layers,
    color: '#6366f1',
    description: 'Room layout, furniture positioning, spatial relationships'
  },
  lighting: {
    name: 'Lighting & Atmosphere',
    icon: Lightbulb,
    color: '#f59e0b',
    description: 'Light sources, quality, color temperature, shadows'
  },
  elements: {
    name: 'Scene Elements',
    icon: Image,
    color: '#10b981',
    description: 'Individual objects, botanicals, props, materials'
  },
  color: {
    name: 'Color Palette',
    icon: Palette,
    color: '#ec4899',
    description: 'Color scheme, dominant tones, accent colors'
  },
  camera: {
    name: 'Camera & Framing',
    icon: Camera,
    color: '#8b5cf6',
    description: 'Lens, aperture, composition, perspective'
  },
  mood: {
    name: 'Mood & Style',
    icon: Settings,
    color: '#06b6d4',
    description: 'Aesthetic keywords, references, emotional tone'
  }
};

// Preset templates based on our blueprints
const SCENE_TEMPLATES = {
  winterAtelier: {
    name: "Winter's End Atelier",
    description: "Minimalist botanist studio, overcast light, mid-winter to early spring",
    layers: {
      spatial: {
        enabled: true,
        weight: 1.2,
        prompt: "Minimalist botanist's winter studio. Long weathered white-painted workbench (7 feet) centered in room. Low linen-upholstered bench in corner with cushions. Floor-to-ceiling built-in shelving on left wall (pearl gray painted). Wide plank gray-washed oak floors. Tall Crittall-style windows (10 feet, matte black steel frames) along right wall showing winter garden view with bare trees and melting snow patches."
      },
      lighting: {
        enabled: true,
        weight: 1.3,
        prompt: "Soft overcast afternoon light (3-4pm) from tall windows on right, creating even shadowless illumination. Cool color temperature (5500-6000K) with soft blue-gray ambient light. No harsh shadows, only gentle graduated tones. Misty, ethereal quality with soft diffused daylight. Slight warmth reflected from natural linen and wood materials."
      },
      elements: {
        enabled: true,
        weight: 1.1,
        prompt: "Sparse winter botanical centerpiece in five vessels: frosted glass cylinder with pussy willow branches (silver catkins), white ceramic bottle vase with pale pink hellebores, clear glass jar with white ranunculus and dried taupe hydrangea, small white porcelain bowl with catkins, frosted bud vase with bare lichen branch. Suspended overhead: delicate mobile-style installation of bare birch branches, silver dollar eucalyptus, translucent lunaria seed pods, paper-white narcissus. Forcing bulbs in terracotta pots showing green shoots. Vintage glass specimen jars. Open leather plant journal. Collection of smooth river stones."
      },
      color: {
        enabled: true,
        weight: 1.2,
        prompt: "Cool winter palette dominated by soft whites, pearl grays, cool mid-grays. Minimal color: pale pink hellebores, soft sage green accents, emerging green shoots. Natural materials: light gray-washed oak, weathered white-painted pine, natural linen cream, undyed wool. Muted, desaturated tones. 70% whites and grays, 30% subtle warm accents."
      },
      camera: {
        enabled: true,
        weight: 1.0,
        prompt: "50mm prime lens, f/4.0 aperture for extended depth of field. Shot from standing height (5.5 feet), straight-on with minimal angle. Rule of thirds composition: workbench on lower third, suspended installation in upper third. Golden ratio: visual weight on left (70/30 split). Significant negative space in upper-right quadrant and across work surface."
      },
      mood: {
        enabled: true,
        weight: 1.1,
        prompt: "Minimalist, contemplative, transitional, ethereal, restrained, meditative, quiet, sparse, elegant, wabi-sabi aesthetic. Scandinavian-Japanese fusion. Winter awakening, botanical study, scholarly, peaceful. Cereal magazine minimalism, monastic botanical study. Photorealistic textures, 8K resolution, editorial quality."
      }
    }
  },
  autumnWarmth: {
    name: "Sun-Drenched Autumn Atelier",
    description: "Warm botanical workspace, golden hour light, lived-in character",
    layers: {
      spatial: {
        enabled: true,
        weight: 1.2,
        prompt: "Long rustic wooden trestle table (8 feet, weathered oak) centered in sun-drenched atelier. Deep green velvet armchair (tufted, brass nail trim) in corner with cream throw blanket. Exposed brick wall opposite windows. Wide plank honey-toned reclaimed pine floors. Overhead exposed walnut ceiling beams spanning room."
      },
      lighting: {
        enabled: true,
        weight: 1.3,
        prompt: "Warm golden hour sunlight (4-5pm) streaming through large industrial steel-framed windows at 45-degree angle from right side. Volumetric light beams with visible dust motes and pollen. High contrast with deep shadows on left, soft bounce light filling shadow areas. Warm color temperature (4500K). Dramatic directional lighting creating long shadows."
      },
      elements: {
        enabled: true,
        weight: 1.1,
        prompt: "Elaborate wildflower centerpiece in seven vintage glass bottles (amber, clear, seafoam green, 8-18 inches tall): wheat grass, fern fronds, Queen Anne's lace, burgundy astilbe, dusty pink yarrow, purple statice. Overhead garland (14 feet) of seeded eucalyptus, hop vines with cones, willow branches draped on beams. Scattered botanical sketches, terracotta pots, brass magnifying glass, dried lavender bundle hanging, antique botanical chart."
      },
      color: {
        enabled: true,
        weight: 1.2,
        prompt: "Warm autumn palette: honey oak, walnut brown, amber glass tones (60%). Botanical accents: burnt orange, dusty rose, burgundy, sage green (25%). Earth tones: terracotta, cream linen, wheat gold (15%). Warm honey and amber dominant, creating cozy nostalgic atmosphere."
      },
      camera: {
        enabled: true,
        weight: 1.0,
        prompt: "35mm prime lens, f/2.8 aperture for shallow depth of field. Standing eye-level (5.5 feet), slight downward angle (10-15°). Table centerpiece on lower-third line, offset right of vertical center. Sharp focus on centerpiece, gentle bokeh on background (armchair, walls, garland softly out of focus)."
      },
      mood: {
        enabled: true,
        weight: 1.1,
        prompt: "Cozy, lived-in, sun-drenched, botanical, artisan, romantic, creative, nostalgic, warm, inviting, contemplative. Kinfolk magazine aesthetic, Dutch still life light quality, Anthropologie styling, English cottage herbalist workshop. Photorealistic textures, 8K resolution, cinematic depth of field, editorial magazine quality."
      }
    }
  }
};

export default function SceneBlueprintComposer() {
  const [activeLayers, setActiveLayers] = useState(SCENE_TEMPLATES.winterAtelier.layers);
  const [masterPrompt, setMasterPrompt] = useState('');
  const [expandedCategories, setExpandedCategories] = useState(new Set(Object.keys(LAYER_CATEGORIES)));
  const [selectedTemplate, setSelectedTemplate] = useState('winterAtelier');
  const [showAdvanced, setShowAdvanced] = useState(false);
  const promptRef = useRef(null);

  // Generate master prompt from active layers
  const generateMasterPrompt = () => {
    const enabledLayers = Object.entries(activeLayers)
      .filter(([_, layer]) => layer.enabled)
      .sort((a, b) => (b[1].weight || 1) - (a[1].weight || 1))
      .map(([category, layer]) => {
        const weight = layer.weight || 1;
        const weightPrefix = weight > 1 ? `[PRIORITY ${weight.toFixed(1)}x] ` : '';
        return `${weightPrefix}${layer.prompt}`;
      });

    const prompt = `High-resolution interior photography. ${enabledLayers.join(' ')} Professional architectural photography, photorealistic textures, editorial quality.`;
    setMasterPrompt(prompt);
    return prompt;
  };

  // Update layer
  const updateLayer = (category, updates) => {
    setActiveLayers(prev => ({
      ...prev,
      [category]: { ...prev[category], ...updates }
    }));
  };

  // Toggle category expansion
  const toggleCategory = (category) => {
    setExpandedCategories(prev => {
      const next = new Set(prev);
      if (next.has(category)) {
        next.delete(category);
      } else {
        next.add(category);
      }
      return next;
    });
  };

  // Load template
  const loadTemplate = (templateKey) => {
    setSelectedTemplate(templateKey);
    setActiveLayers(SCENE_TEMPLATES[templateKey].layers);
    setMasterPrompt('');
  };

  // Copy to clipboard
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    // Could add toast notification here
  };

  // Export as JSON
  const exportBlueprint = () => {
    const blueprint = {
      template: selectedTemplate,
      layers: activeLayers,
      generatedPrompt: masterPrompt,
      timestamp: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(blueprint, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `scene-blueprint-${Date.now()}.json`;
    a.click();
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: '"Inter", -apple-system, system-ui, sans-serif',
      padding: '2rem'
    }}>
      {/* Header */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto 2rem',
        textAlign: 'center'
      }}>
        <h1 style={{
          fontSize: '3rem',
          fontWeight: '800',
          color: 'white',
          margin: '0 0 0.5rem',
          letterSpacing: '-0.02em'
        }}>
          Scene Blueprint Composer
        </h1>
        <p style={{
          fontSize: '1.125rem',
          color: 'rgba(255,255,255,0.9)',
          margin: 0
        }}>
          Layered prompt pipeline for photorealistic scene generation
        </p>
      </div>

      <div style={{
        maxWidth: '1400px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: '1fr 400px',
        gap: '2rem',
        alignItems: 'start'
      }}>
        
        {/* Left Column - Layer Editor */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          
          {/* Template Selector */}
          <div style={{
            background: 'white',
            borderRadius: '16px',
            padding: '1.5rem',
            boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '1rem'
            }}>
              <h3 style={{
                fontSize: '1.125rem',
                fontWeight: '700',
                margin: 0,
                color: '#1f2937'
              }}>
                Scene Templates
              </h3>
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: '#6366f1',
                  fontSize: '0.875rem',
                  fontWeight: '600',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <Settings size={16} />
                {showAdvanced ? 'Hide' : 'Show'} Advanced
              </button>
            </div>
            
            <div style={{ display: 'flex', gap: '1rem' }}>
              {Object.entries(SCENE_TEMPLATES).map(([key, template]) => (
                <button
                  key={key}
                  onClick={() => loadTemplate(key)}
                  style={{
                    flex: 1,
                    padding: '1rem',
                    background: selectedTemplate === key 
                      ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                      : '#f3f4f6',
                    color: selectedTemplate === key ? 'white' : '#374151',
                    border: 'none',
                    borderRadius: '12px',
                    cursor: 'pointer',
                    textAlign: 'left',
                    transition: 'all 0.2s',
                    transform: selectedTemplate === key ? 'scale(1.02)' : 'scale(1)'
                  }}
                >
                  <div style={{
                    fontWeight: '700',
                    fontSize: '1rem',
                    marginBottom: '0.25rem'
                  }}>
                    {template.name}
                  </div>
                  <div style={{
                    fontSize: '0.75rem',
                    opacity: 0.9
                  }}>
                    {template.description}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Layer Categories */}
          {Object.entries(LAYER_CATEGORIES).map(([categoryKey, category]) => {
            const Icon = category.icon;
            const layer = activeLayers[categoryKey];
            const isExpanded = expandedCategories.has(categoryKey);

            return (
              <div
                key={categoryKey}
                style={{
                  background: 'white',
                  borderRadius: '16px',
                  padding: '1.5rem',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  border: layer?.enabled ? `2px solid ${category.color}` : '2px solid transparent',
                  transition: 'all 0.2s'
                }}
              >
                {/* Category Header */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: isExpanded ? '1rem' : 0 }}>
                  <div
                    onClick={() => toggleCategory(categoryKey)}
                    style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '10px',
                      background: `${category.color}15`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      cursor: 'pointer',
                      transition: 'all 0.2s'
                    }}
                  >
                    <Icon size={20} color={category.color} />
                  </div>
                  
                  <div style={{ flex: 1 }} onClick={() => toggleCategory(categoryKey)}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '0.5rem',
                      cursor: 'pointer'
                    }}>
                      <h3 style={{
                        fontSize: '1.125rem',
                        fontWeight: '700',
                        margin: 0,
                        color: '#1f2937'
                      }}>
                        {category.name}
                      </h3>
                      {isExpanded ? <ChevronDown size={18} /> : <ChevronRight size={18} />}
                    </div>
                    <p style={{
                      fontSize: '0.875rem',
                      color: '#6b7280',
                      margin: '0.25rem 0 0'
                    }}>
                      {category.description}
                    </p>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                    {showAdvanced && (
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <label style={{ fontSize: '0.75rem', color: '#6b7280' }}>Weight:</label>
                        <input
                          type="number"
                          min="0"
                          max="2"
                          step="0.1"
                          value={layer?.weight || 1}
                          onChange={(e) => updateLayer(categoryKey, { weight: parseFloat(e.target.value) })}
                          style={{
                            width: '60px',
                            padding: '0.25rem 0.5rem',
                            border: '1px solid #e5e7eb',
                            borderRadius: '6px',
                            fontSize: '0.875rem'
                          }}
                        />
                      </div>
                    )}
                    
                    <label style={{
                      position: 'relative',
                      display: 'inline-block',
                      width: '48px',
                      height: '26px'
                    }}>
                      <input
                        type="checkbox"
                        checked={layer?.enabled || false}
                        onChange={(e) => updateLayer(categoryKey, { enabled: e.target.checked })}
                        style={{ display: 'none' }}
                      />
                      <span style={{
                        position: 'absolute',
                        cursor: 'pointer',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        background: layer?.enabled ? category.color : '#d1d5db',
                        borderRadius: '26px',
                        transition: 'all 0.3s'
                      }}>
                        <span style={{
                          position: 'absolute',
                          content: '',
                          height: '20px',
                          width: '20px',
                          left: layer?.enabled ? '25px' : '3px',
                          bottom: '3px',
                          background: 'white',
                          borderRadius: '50%',
                          transition: 'all 0.3s'
                        }}></span>
                      </span>
                    </label>
                  </div>
                </div>

                {/* Expanded Content */}
                {isExpanded && (
                  <div style={{ marginTop: '1rem' }}>
                    <textarea
                      value={layer?.prompt || ''}
                      onChange={(e) => updateLayer(categoryKey, { prompt: e.target.value })}
                      placeholder={`Enter ${category.name.toLowerCase()} prompt details...`}
                      style={{
                        width: '100%',
                        minHeight: '120px',
                        padding: '0.75rem',
                        border: '1px solid #e5e7eb',
                        borderRadius: '8px',
                        fontSize: '0.875rem',
                        fontFamily: '"SF Mono", Monaco, monospace',
                        resize: 'vertical',
                        background: '#f9fafb'
                      }}
                    />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right Column - Output Panel */}
        <div style={{ position: 'sticky', top: '2rem' }}>
          <div style={{
            background: 'white',
            borderRadius: '16px',
            padding: '1.5rem',
            boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
          }}>
            <h3 style={{
              fontSize: '1.125rem',
              fontWeight: '700',
              marginBottom: '1rem',
              color: '#1f2937',
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}>
              <Eye size={20} />
              Master Prompt Output
            </h3>

            {/* Generate Button */}
            <button
              onClick={generateMasterPrompt}
              style={{
                width: '100%',
                padding: '1rem',
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                border: 'none',
                borderRadius: '12px',
                fontSize: '1rem',
                fontWeight: '700',
                cursor: 'pointer',
                marginBottom: '1rem',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '0.5rem',
                transition: 'transform 0.2s'
              }}
              onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
              onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
            >
              <RefreshCw size={20} />
              Generate Master Prompt
            </button>

            {/* Prompt Display */}
            {masterPrompt && (
              <>
                <div
                  ref={promptRef}
                  style={{
                    padding: '1rem',
                    background: '#f9fafb',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                    fontSize: '0.875rem',
                    fontFamily: '"SF Mono", Monaco, monospace',
                    lineHeight: '1.6',
                    maxHeight: '400px',
                    overflowY: 'auto',
                    marginBottom: '1rem',
                    color: '#374151'
                  }}
                >
                  {masterPrompt}
                </div>

                {/* Action Buttons */}
                <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1rem' }}>
                  <button
                    onClick={() => copyToClipboard(masterPrompt)}
                    style={{
                      flex: 1,
                      padding: '0.75rem',
                      background: '#f3f4f6',
                      border: 'none',
                      borderRadius: '8px',
                      fontSize: '0.875rem',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                      color: '#374151'
                    }}
                  >
                    <Copy size={16} />
                    Copy
                  </button>
                  <button
                    onClick={exportBlueprint}
                    style={{
                      flex: 1,
                      padding: '0.75rem',
                      background: '#f3f4f6',
                      border: 'none',
                      borderRadius: '8px',
                      fontSize: '0.875rem',
                      fontWeight: '600',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                      color: '#374151'
                    }}
                  >
                    <Download size={16} />
                    Export
                  </button>
                </div>
              </>
            )}

            {/* Layer Summary */}
            <div style={{
              padding: '1rem',
              background: '#fef3c7',
              border: '1px solid #fbbf24',
              borderRadius: '8px',
              fontSize: '0.875rem'
            }}>
              <div style={{ fontWeight: '700', marginBottom: '0.5rem', color: '#92400e' }}>
                Active Layers
              </div>
              <div style={{ color: '#78350f' }}>
                {Object.entries(activeLayers).filter(([_, layer]) => layer.enabled).length} of {Object.keys(activeLayers).length} layers enabled
              </div>
              <div style={{ marginTop: '0.75rem', fontSize: '0.75rem', color: '#92400e' }}>
                {Object.entries(activeLayers)
                  .filter(([_, layer]) => layer.enabled)
                  .sort((a, b) => (b[1].weight || 1) - (a[1].weight || 1))
                  .map(([key, layer]) => (
                    <div key={key} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.25rem' }}>
                      <div
                        style={{
                          width: '8px',
                          height: '8px',
                          borderRadius: '50%',
                          background: LAYER_CATEGORIES[key].color
                        }}
                      />
                      <span>{LAYER_CATEGORIES[key].name}</span>
                      {layer.weight > 1 && (
                        <span style={{
                          padding: '0.125rem 0.375rem',
                          background: '#f59e0b',
                          color: 'white',
                          borderRadius: '4px',
                          fontSize: '0.625rem',
                          fontWeight: '700'
                        }}>
                          {layer.weight.toFixed(1)}x
                        </span>
                      )}
                    </div>
                  ))
                }
              </div>
            </div>

            {/* AI Platform Suggestions */}
            {masterPrompt && (
              <div style={{ marginTop: '1rem', padding: '1rem', background: '#ede9fe', borderRadius: '8px' }}>
                <div style={{ fontWeight: '700', fontSize: '0.875rem', marginBottom: '0.5rem', color: '#5b21b6' }}>
                  Recommended Settings
                </div>
                <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontFamily: '"SF Mono", Monaco, monospace' }}>
                  <div style={{ marginBottom: '0.25rem' }}>
                    <strong>Midjourney:</strong> --ar 4:3 --style raw --stylize 100
                  </div>
                  <div style={{ marginBottom: '0.25rem' }}>
                    <strong>DALL-E 3:</strong> Use prompt as-is
                  </div>
                  <div>
                    <strong>Stable Diffusion:</strong> CFG 6-7, Steps 50-70
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
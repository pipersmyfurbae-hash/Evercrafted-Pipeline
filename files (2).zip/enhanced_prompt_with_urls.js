/**
 * ENHANCED WREATH PROMPT GENERATOR V3
 * 
 * Features:
 * - Includes blueprint PNG URL
 * - Includes floral image URLs from inventory (direct from Pioneer Wholesale)
 * - Flat lay keywords from research
 * - Camera specs (85mm, f/2.8)
 * - Negative prompts (--no cartoon, etc)
 * - Midjourney parameters (--iw, --style raw, --s)
 * 
 * Result: One-paste prompt with all image references inline
 */

function generateWreathPromptWithURLs(
  selectedFlorals, 
  positioning, 
  characterStory, 
  livingSpace, 
  blueprintURL // We'll generate this and host temporarily
) {
  
  // STEP 1: Collect all image URLs
  const imageURLs = [];
  
  // Add blueprint first (highest priority for layout)
  if (blueprintURL) {
    imageURLs.push(blueprintURL);
  }
  
  // Add floral images from inventory (limit to top 3-5 to avoid confusion)
  const floralImages = positioning
    .slice(0, 5) // Top 5 florals only
    .map(p => p.floral.images?.main)
    .filter(Boolean); // Remove nulls
  
  imageURLs.push(...floralImages);
  
  // STEP 2: Build floral description
  const floralList = positioning.map(p => {
    const color = p.floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name 
                  || p.floral.productSpecs?.color;
    const length = p.floral.dimensions?.length;
    return `${p.position.quantity}x ${p.floral.name} (${color}, ${length}")`;
  }).join(', ');
  
  // STEP 3: Get color hex codes for precise color matching
  const colorHexes = positioning
    .map(p => p.floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.hex)
    .filter(Boolean)
    .slice(0, 5);
  
  // STEP 4: Get focal point angles
  const focalAngles = positioning
    .filter(p => p.floral.visualIntelligence?.designIntelligence?.designRole === 'focal')
    .map(p => p.position.angle + '°')
    .join(', ');
  
  // STEP 5: Get emotional attributes from selected florals
  const emotionalAttributes = [...new Set(
    selectedFlorals.flatMap(f => 
      f.visualIntelligence?.designIntelligence?.emotionalAttributes || []
    )
  )].slice(0, 5).join(', ');
  
  // STEP 6: Build complete prompt
  const imageURLSection = imageURLs.length > 0 
    ? imageURLs.join(' ') + '\n\n'
    : '';
  
  const prompt = `${imageURLSection}flat lay photograph of handmade luxury faux floral wreath, 20 inches diameter, perfectly circular radial arrangement, top-down overhead bird's-eye view, centered on ${livingSpace.wallColor || 'soft pearl gray'} linen backdrop.

LAYOUT SPECIFICATION: ${characterStory.aesthetic} design with ${positioning.length} distinct floral elements positioned at golden ratio focal points (${focalAngles}), following circular symmetry with intentional negative space. Each element placed according to blueprint diagram with precise angular positioning.

FLORAL COMPOSITION: ${floralList}

BASE STRUCTURE: Whitewashed grapevine wreath, perfectly circular form, even thickness throughout, 5-6 inches depth projection from base to outermost blooms.

COLOR PALETTE: Primary colors ${colorHexes.join(', ')} creating harmonious ${characterStory.emotionalColors?.join(', ') || 'neutral tones'} palette. 

EMOTIONAL QUALITIES: ${emotionalAttributes}. ${characterStory.mood || 'contemplative and elegant'} atmosphere.

PHOTOGRAPHY SPECIFICATIONS: Professional product photography shot with 85mm macro lens at f/2.8 aperture creating shallow depth of field, soft diffused natural morning light from 45° angle creating gentle shadows, photorealistic silk and fabric textures showing individual petal detail, realistic foliage with natural color variation, subtle environmental reflections.

STYLING NOTES: ${characterStory.wreathCharacteristics || 'Minimalist restraint, asymmetric balance, intentional negative space'}. Natural depth variation 1-4 inches from base, each stem positioned following organic growth patterns with realistic draping and movement, no artificial stiffness.

TECHNICAL QUALITY: 8K resolution, tack-sharp focus on foreground florals graduating to soft bokeh on background elements, subtle film grain for natural texture (avoiding plastic appearance), realistic color temperature matching natural daylight (5500K), professional florist craftsmanship with attention to detail.

--ar 1:1 --v 6 --style raw --s 100 --iw 2.5 --no cartoon, illustration, line-art, plastic, fake, artificial, CGI, painting, drawing, sketch, anime`;

  return prompt;
}

// EXAMPLE USAGE:
const examplePrompt = generateWreathPromptWithURLs(
  selectedFlorals,
  wreathPositioning,
  {
    name: "Eleanor Hayes",
    aesthetic: "Minimalist with intention, wabi-sabi restraint",
    emotionalColors: ["Soft white", "Pearl gray", "Pale blush pink"],
    mood: "contemplative and quietly hopeful",
    wreathCharacteristics: "Sparse, asymmetric, intentional negative space, winter botanicals"
  },
  {
    wallColor: "soft pearl gray"
  },
  "https://temp-storage.example.com/blueprint-abc123.png"
);

console.log(examplePrompt);

/* OUTPUT WOULD BE:

https://temp-storage.example.com/blueprint-abc123.png https://www.pioneerwholesaleco.com/media/catalog/product/cache/7800bb778a954cb4c97ef3c76a1a4610/p/w/pww2330cr.jpg https://www.pioneerwholesaleco.com/media/catalog/product/cache/7800bb778a954cb4c97ef3c76a1a4610/q/s/qsl005gr.jpg

flat lay photograph of handmade luxury faux floral wreath, 20 inches diameter, perfectly circular radial arrangement, top-down overhead bird's-eye view, centered on soft pearl gray linen backdrop.

LAYOUT SPECIFICATION: Minimalist with intention, wabi-sabi restraint design with 7 distinct floral elements positioned at golden ratio focal points (50°, 135°, 220°), following circular symmetry with intentional negative space. Each element placed according to blueprint diagram with precise angular positioning.

FLORAL COMPOSITION: 2x Hanging Wisteria Spray 67" - Cream (Cream White, 67"), 3x Seeded Eucalyptus Spray 18" - Silver Green (Silver Green, 18"), ...

[rest of prompt]

--ar 1:1 --v 6 --style raw --s 100 --iw 2.5 --no cartoon, illustration, line-art, plastic, fake, artificial, CGI, painting, drawing, sketch, anime
*/


// ==============================================
// BLUEPRINT URL HOSTING OPTIONS
// ==============================================

/**
 * Option 1: imgur.com (Free, Anonymous Upload)
 * - Easy API, no auth required for anonymous uploads
 * - Rate limit: ~50 uploads/hour
 * - Perfect for testing
 */
async function uploadBlueprintToImgur(blueprintDataURL) {
  const base64Data = blueprintDataURL.split(',')[1];
  
  const response = await fetch('https://api.imgur.com/3/image', {
    method: 'POST',
    headers: {
      'Authorization': 'Client-ID YOUR_IMGUR_CLIENT_ID', // Get free at imgur.com/account/settings/apps
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      image: base64Data,
      type: 'base64'
    })
  });
  
  const data = await response.json();
  return data.data.link; // Returns: https://i.imgur.com/abc123.png
}

/**
 * Option 2: Cloudinary (Free Tier: 25GB/month)
 * - More robust
 * - Better for production
 * - Can auto-optimize images
 */
async function uploadBlueprintToCloudinary(blueprintDataURL) {
  const formData = new FormData();
  formData.append('file', blueprintDataURL);
  formData.append('upload_preset', 'YOUR_UNSIGNED_PRESET'); // Create in Cloudinary settings
  
  const response = await fetch(
    'https://api.cloudinary.com/v1_1/YOUR_CLOUD_NAME/image/upload',
    {
      method: 'POST',
      body: formData
    }
  );
  
  const data = await response.json();
  return data.secure_url; // Returns: https://res.cloudinary.com/...
}

/**
 * Option 3: Temporary File Upload Services (No Account)
 * - file.io (max 2GB, free)
 * - tmpfiles.org (max 100MB, free)
 * - 0x0.st (max 512MB, free)
 * 
 * BEST FOR TESTING - no setup required!
 */
async function uploadBlueprintToTempService(blueprintBlob) {
  const formData = new FormData();
  formData.append('file', blueprintBlob, 'blueprint.png');
  
  // Option A: file.io (expires after 1 download or 14 days)
  const response = await fetch('https://file.io', {
    method: 'POST',
    body: formData
  });
  
  const data = await response.json();
  return data.link; // Returns: https://file.io/abc123
}

/**
 * Option 4: GitHub Gists (Free, Unlimited for images under 100MB)
 * - Create anonymous gist with image
 * - Get raw URL
 * - No rate limits for reading
 */
async function uploadBlueprintToGist(blueprintDataURL) {
  const base64Data = blueprintDataURL.split(',')[1];
  
  const response = await fetch('https://api.github.com/gists', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      // Optional: Add your GitHub token for higher rate limits
      // 'Authorization': 'token YOUR_GITHUB_TOKEN'
    },
    body: JSON.stringify({
      public: false,
      files: {
        'blueprint.png': {
          content: base64Data
        }
      }
    })
  });
  
  const data = await response.json();
  const gistId = data.id;
  return `https://gist.githubusercontent.com/anonymous/${gistId}/raw/blueprint.png`;
}


// ==============================================
// COMPLETE AUTOMATED FLOW
// ==============================================

async function generateCompleteWreathPrompt(
  selectedFlorals,
  positioning,
  characterStory,
  livingSpace
) {
  
  // Step 1: Generate blueprint PNG
  const blueprintDataURL = generateBlueprintPNG(positioning);
  
  // Step 2: Upload blueprint and get URL
  // CHOOSE ONE:
  
  // Option A: Imgur (requires client ID but easiest)
  // const blueprintURL = await uploadBlueprintToImgur(blueprintDataURL);
  
  // Option B: Temporary service (NO SETUP REQUIRED - BEST FOR TESTING!)
  const blueprintBlob = await fetch(blueprintDataURL).then(r => r.blob());
  const blueprintURL = await uploadBlueprintToTempService(blueprintBlob);
  
  // Option C: Cloudinary (best for production)
  // const blueprintURL = await uploadBlueprintToCloudinary(blueprintDataURL);
  
  // Step 3: Generate prompt with blueprint URL + floral image URLs
  const prompt = generateWreathPromptWithURLs(
    selectedFlorals,
    positioning,
    characterStory,
    livingSpace,
    blueprintURL
  );
  
  return {
    prompt,
    blueprintURL,
    floralImageURLs: positioning.map(p => p.floral.images?.main).filter(Boolean)
  };
}

// ==============================================
// HELPER: Generate Blueprint PNG (from before)
// ==============================================

function generateBlueprintPNG(wreathPositioning, wreathSize = 20) {
  const canvas = document.createElement('canvas');
  canvas.width = 2400;
  canvas.height = 2400;
  const ctx = canvas.getContext('2d');
  
  // White background
  ctx.fillStyle = 'white';
  ctx.fillRect(0, 0, 2400, 2400);
  
  // Draw wreath circle outline (thick black)
  ctx.strokeStyle = '#1f2937';
  ctx.lineWidth = 12;
  ctx.beginPath();
  ctx.arc(1200, 1200, 1000, 0, 2 * Math.PI);
  ctx.stroke();
  
  // Draw inner circle (for depth reference)
  ctx.strokeStyle = '#d1d5db';
  ctx.lineWidth = 4;
  ctx.setLineDash([20, 10]);
  ctx.beginPath();
  ctx.arc(1200, 1200, 850, 0, 2 * Math.PI);
  ctx.stroke();
  ctx.setLineDash([]);
  
  // Draw positioning markers for each floral
  wreathPositioning.forEach((p, index) => {
    const angle = (p.position.angle - 90) * (Math.PI / 180);
    const x = 1200 + Math.cos(angle) * 1000;
    const y = 1200 + Math.sin(angle) * 1000;
    
    const isFocal = p.floral.visualIntelligence?.designIntelligence?.designRole === 'focal';
    
    // Draw circle for floral position
    ctx.fillStyle = isFocal ? '#ef4444' : '#6b7280';
    ctx.beginPath();
    ctx.arc(x, y, 40 + (p.position.quantity * 10), 0, 2 * Math.PI);
    ctx.fill();
    
    // Draw line showing depth projection
    const depthLine = p.position.depth[1] * 60;
    ctx.strokeStyle = isFocal ? '#ef4444' : '#9ca3af';
    ctx.lineWidth = 6;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + Math.cos(angle) * depthLine, y + Math.sin(angle) * depthLine);
    ctx.stroke();
    
    // Add angle label
    ctx.fillStyle = 'black';
    ctx.font = 'bold 40px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${p.position.angle}°`, x, y - 80);
    
    // Add floral name (truncated)
    ctx.font = '28px Arial';
    const name = p.floral.name.substring(0, 20);
    const textWidth = ctx.measureText(name).width;
    
    // Background for text readability
    ctx.fillStyle = 'rgba(255,255,255,0.9)';
    ctx.fillRect(x - textWidth/2 - 10, y + 60, textWidth + 20, 40);
    
    ctx.fillStyle = '#374151';
    ctx.fillText(name, x, y + 90);
    
    // Add quantity badge
    ctx.fillStyle = isFocal ? '#ef4444' : '#6b7280';
    ctx.beginPath();
    ctx.arc(x + 50, y - 50, 30, 0, 2 * Math.PI);
    ctx.fill();
    
    ctx.fillStyle = 'white';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${p.position.quantity}`, x + 50, y - 40);
  });
  
  // Add title
  ctx.fillStyle = '#1f2937';
  ctx.font = 'bold 60px Arial';
  ctx.textAlign = 'center';
  ctx.fillText('Wreath Layout Blueprint', 1200, 100);
  
  // Add legend
  const legendY = 2250;
  
  // Focal indicator
  ctx.fillStyle = '#ef4444';
  ctx.beginPath();
  ctx.arc(200, legendY, 30, 0, 2 * Math.PI);
  ctx.fill();
  ctx.fillStyle = '#1f2937';
  ctx.font = '36px Arial';
  ctx.textAlign = 'left';
  ctx.fillText('= Focal Element (Primary)', 250, legendY + 12);
  
  // Accent indicator
  ctx.fillStyle = '#6b7280';
  ctx.beginPath();
  ctx.arc(900, legendY, 30, 0, 2 * Math.PI);
  ctx.fill();
  ctx.fillStyle = '#1f2937';
  ctx.fillText('= Accent/Filler', 950, legendY + 12);
  
  return canvas.toDataURL('image/png');
}


// ==============================================
// EXPORT
// ==============================================

module.exports = {
  generateWreathPromptWithURLs,
  generateCompleteWreathPrompt,
  generateBlueprintPNG,
  uploadBlueprintToImgur,
  uploadBlueprintToCloudinary,
  uploadBlueprintToTempService,
  uploadBlueprintToGist
};

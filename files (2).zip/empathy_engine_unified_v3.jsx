import React, { useState, useRef } from 'react';
import { Heart, Home, Flower2, Image, Package, Sparkles, User, Camera, Wand2, Upload, ChevronRight, Download, Layers, Copy, CheckCircle } from 'lucide-react';

/**
 * ═══════════════════════════════════════════════════════════════════════
 * EMPATHY ENGINE V3 - COMPLETE UNIFIED SYSTEM
 * ═══════════════════════════════════════════════════════════════════════
 * 
 * THE COMPLETE FLOW:
 * Emotion → Character Story → Living Space (Scene Blueprint Composer) → 
 * Floral Selection → Wreath Design → Image Generation → Assembly Guide → 
 * Complete Product Package
 * 
 * CRITICAL INTEGRATION:
 * - Scene Blueprint Composer IS Step 3 (not separate)
 * - Context shot shows wreath IN the living space
 * - All components work together as one system
 */

export default function EmpathyEngineUnifiedV3() {
  const [currentStep, setCurrentStep] = useState(0);
  const [floralInventory, setFloralInventory] = useState([]);
  
  const [pipelineData, setPipelineData] = useState({
    emotionalInput: '',
    characterStory: null,
    livingSpace: null, // Generated using Scene Blueprint Composer layers
    selectedFlorals: [],
    wreathDesign: null,
    wreathPositioning: [],
    imagePrompts: {
      sceneImages: [],      // Living space images
      productShot: null,    // Flat lay wreath
      contextShot: null,    // 🌟 WREATH IN THE SPACE
      assemblyLayers: []    // 5 assembly steps
    },
    assemblyGuide: null,
    productPackage: null
  });

  const steps = [
    { id: 'input', name: 'Emotional Input', icon: Heart },
    { id: 'character', name: 'Character Story', icon: User },
    { id: 'space', name: 'Living Space', icon: Home, subtitle: 'Scene Blueprint Composer' },
    { id: 'florals', name: 'Floral Selection', icon: Sparkles },
    { id: 'wreath', name: 'Wreath Design', icon: Flower2 },
    { id: 'images', name: 'Image Generation', icon: Camera, subtitle: 'Scene + Product + Context' },
    { id: 'assembly', name: 'Assembly Guide', icon: Layers },
    { id: 'package', name: 'Product Package', icon: Package }
  ];

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '2rem'
    }}>
      {/* Header */}
      <div style={{ maxWidth: '1400px', margin: '0 auto 2rem', textAlign: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem', marginBottom: '1rem' }}>
          <Sparkles size={48} color="white" />
          <h1 style={{ fontSize: '3.5rem', fontWeight: '900', color: 'white', margin: 0, letterSpacing: '-0.02em' }}>
            Empathy Engine V3
          </h1>
        </div>
        <p style={{ fontSize: '1.25rem', color: 'rgba(255,255,255,0.95)', margin: 0, fontWeight: '500' }}>
          Emotion → Character → Living Space → Wreath → Complete Package
        </p>
      </div>

      {/* Progress Stepper */}
      <ProgressStepper steps={steps} currentStep={currentStep} setCurrentStep={setCurrentStep} />

      {/* Main Content */}
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        {currentStep === 0 && (
          <StepEmotionalInput 
            floralInventory={floralInventory}
            setFloralInventory={setFloralInventory}
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(1)}
          />
        )}
        
        {currentStep === 1 && (
          <StepCharacterStory
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(2)}
            onBack={() => setCurrentStep(0)}
          />
        )}
        
        {currentStep === 2 && (
          <StepLivingSpace
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(3)}
            onBack={() => setCurrentStep(1)}
          />
        )}
        
        {currentStep === 3 && (
          <StepFloralSelection
            floralInventory={floralInventory}
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(4)}
            onBack={() => setCurrentStep(2)}
          />
        )}
        
        {currentStep === 4 && (
          <StepWreathDesign
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(5)}
            onBack={() => setCurrentStep(3)}
          />
        )}
        
        {currentStep === 5 && (
          <StepImageGeneration
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(6)}
            onBack={() => setCurrentStep(4)}
          />
        )}
        
        {currentStep === 6 && (
          <StepAssemblyGuide
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(7)}
            onBack={() => setCurrentStep(5)}
          />
        )}
        
        {currentStep === 7 && (
          <StepProductPackage
            pipelineData={pipelineData}
            onBack={() => setCurrentStep(6)}
          />
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// PROGRESS STEPPER COMPONENT
// ═══════════════════════════════════════════════════════════════════════

function ProgressStepper({ steps, currentStep, setCurrentStep }) {
  return (
    <div style={{
      maxWidth: '1400px',
      margin: '0 auto 2rem',
      background: 'white',
      borderRadius: '20px',
      padding: '2rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
        {/* Progress Line */}
        <div style={{
          position: 'absolute',
          top: '20px',
          left: '40px',
          right: '40px',
          height: '4px',
          background: '#e5e7eb',
          zIndex: 0
        }}>
          <div style={{
            height: '100%',
            background: 'linear-gradient(90deg, #667eea, #764ba2)',
            width: `${(currentStep / (steps.length - 1)) * 100}%`,
            transition: 'width 0.5s ease'
          }} />
        </div>

        {/* Steps */}
        {steps.map((step, index) => {
          const Icon = step.icon;
          const isComplete = index < currentStep;
          const isCurrent = index === currentStep;
          
          return (
            <div
              key={step.id}
              onClick={() => index <= currentStep && setCurrentStep(index)}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '0.5rem',
                cursor: index <= currentStep ? 'pointer' : 'default',
                position: 'relative',
                zIndex: 1,
                opacity: index > currentStep ? 0.5 : 1
              }}
            >
              <div style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                background: isComplete || isCurrent ? 'linear-gradient(135deg, #667eea, #764ba2)' : '#e5e7eb',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.3s',
                transform: isCurrent ? 'scale(1.1)' : 'scale(1)',
                boxShadow: isCurrent ? '0 8px 20px rgba(102,126,234,0.4)' : 'none'
              }}>
                <Icon size={24} color={isComplete || isCurrent ? 'white' : '#9ca3af'} />
              </div>
              <div style={{ textAlign: 'center', maxWidth: '100px' }}>
                <div style={{
                  fontSize: '0.75rem',
                  fontWeight: isCurrent ? '700' : '600',
                  color: isCurrent ? '#667eea' : '#6b7280'
                }}>
                  {step.name}
                </div>
                {step.subtitle && (
                  <div style={{ fontSize: '0.625rem', color: '#9ca3af', marginTop: '0.125rem' }}>
                    {step.subtitle}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// STEP 0: EMOTIONAL INPUT + INVENTORY UPLOAD
// ═══════════════════════════════════════════════════════════════════════

function StepEmotionalInput({ floralInventory, setFloralInventory, pipelineData, setPipelineData, onNext }) {
  const [emotionalInput, setEmotionalInput] = useState(pipelineData.emotionalInput || '');
  const fileInputRef = useRef(null);

  const handleInventoryUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const text = await file.text();
    const inventory = JSON.parse(text);
    setFloralInventory(inventory);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, emotionalInput }));
    onNext();
  };

  return (
    <div style={{ background: 'white', borderRadius: '20px', padding: '3rem', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Load Your Floral Inventory + Emotional Intent
      </h2>

      {/* Inventory Upload */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{ display: 'block', fontSize: '1rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1f2937' }}>
          Upload enhanced_catalog_v2.json
        </label>
        
        <div
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: floralInventory.length > 0 ? '2px solid #10b981' : '2px dashed #d1d5db',
            borderRadius: '12px',
            padding: '2rem',
            textAlign: 'center',
            cursor: 'pointer',
            background: floralInventory.length > 0 ? '#f0fdf4' : '#f9fafb',
            transition: 'all 0.2s'
          }}
        >
          <Upload size={48} color={floralInventory.length > 0 ? '#10b981' : '#9ca3af'} style={{ margin: '0 auto 1rem' }} />
          {floralInventory.length > 0 ? (
            <>
              <p style={{ fontSize: '1.125rem', fontWeight: '600', color: '#166534', margin: '0 0 0.5rem' }}>
                ✓ {floralInventory.length} florals loaded
              </p>
              <p style={{ fontSize: '0.875rem', color: '#15803d', margin: 0 }}>
                With emotions, geometry, colors, and spatial intelligence
              </p>
            </>
          ) : (
            <>
              <p style={{ fontSize: '1.125rem', fontWeight: '600', color: '#374151', margin: '0 0 0.5rem' }}>
                Click to upload floral inventory
              </p>
              <p style={{ fontSize: '0.875rem', color: '#6b7280', margin: 0 }}>
                JSON format with emotional attributes
              </p>
            </>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleInventoryUpload}
          style={{ display: 'none' }}
        />
      </div>

      {/* Emotional Input */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{ display: 'block', fontSize: '1rem', fontWeight: '700', marginBottom: '0.5rem', color: '#1f2937' }}>
          Emotional Intent
        </label>
        <textarea
          value={emotionalInput}
          onChange={(e) => setEmotionalInput(e.target.value)}
          placeholder="Example: Quiet hope during late winter, the feeling of sun finally warming your face after months of cold, patient observation of nature's cycles and renewal..."
          style={{
            width: '100%',
            minHeight: '150px',
            padding: '1rem',
            border: '2px solid #e5e7eb',
            borderRadius: '12px',
            fontSize: '1rem',
            fontFamily: 'inherit',
            resize: 'vertical'
          }}
        />
      </div>

      {/* Next Button */}
      <button
        onClick={handleNext}
        disabled={floralInventory.length === 0 || !emotionalInput}
        style={{
          width: '100%',
          padding: '1.25rem',
          background: (floralInventory.length > 0 && emotionalInput)
            ? 'linear-gradient(135deg, #667eea, #764ba2)'
            : '#e5e7eb',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1.125rem',
          fontWeight: '700',
          cursor: (floralInventory.length > 0 && emotionalInput) ? 'pointer' : 'not-allowed',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem'
        }}
      >
        Generate Character Story
        <ChevronRight size={24} />
      </button>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// STEP 1: CHARACTER STORY GENERATION
// ═══════════════════════════════════════════════════════════════════════

function StepCharacterStory({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [characterStory, setCharacterStory] = useState(pipelineData.characterStory);

  const generateCharacter = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // This would call Claude API with emotional input
    // For now, using example data
    const story = {
      name: "Eleanor Hayes",
      age: "Early 60s",
      occupation: "Retired Botanical Illustrator",
      location: "Converted barn studio in rural Vermont",
      personality: "Contemplative, patient, deeply attuned to seasonal cycles",
      aesthetic: "Minimalist with intention, wabi-sabi restraint",
      emotionalKeywords: ["contemplative", "elegant", "hopeful", "patient", "natural", "sophisticated", "calming"],
      season: "winter",
      mood: "contemplative and quietly hopeful",
      wreathCharacteristics: "Sparse, asymmetric, intentional negative space, winter botanicals",
      emotionalColors: ["Soft white", "Pearl gray", "Pale blush pink", "Cool blue-gray", "Silver green"],
      narrative: `Eleanor lives alone in a converted barn at the edge of a forest. She spent 40 years illustrating botanical reference books before retiring to focus on observational art. Her studio is sparse not from lack of resources but from decades of refining what truly matters.

She rises early, walks the same paths each morning, noting the exact moment when buds swell, when snow melts from specific stones. Her work is slow, deliberate, meditative.

The late winter months are her favorite. Others see dormancy; she sees preparation. The pussy willows represent her philosophy: patience rewarded, life emerging from apparent emptiness.`
    };
    
    setCharacterStory(story);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, characterStory }));
    onNext();
  };

  return (
    <div style={{ background: 'white', borderRadius: '20px', padding: '3rem', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Character Story: Who Lives Here?
      </h2>

      {!characterStory ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <User size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
            Generate character based on: "{pipelineData.emotionalInput?.substring(0, 100)}..."
          </p>
          <button
            onClick={generateCharacter}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Wand2 size={20} />
            {isGenerating ? 'Generating...' : 'Generate Character'}
          </button>
        </div>
      ) : (
        <div>
          <CharacterCard character={characterStory} />
          
          <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Generate Living Space (Scene Blueprint Composer)
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function CharacterCard({ character }) {
  return (
    <div style={{
      background: '#f0fdf4',
      borderRadius: '16px',
      padding: '2rem'
    }}>
      <h3 style={{ fontSize: '1.75rem', fontWeight: '800', marginBottom: '0.5rem', color: '#166534' }}>
        {character.name}
      </h3>
      <p style={{ fontSize: '1rem', color: '#15803d', marginBottom: '1.5rem' }}>
        {character.age} • {character.occupation}
      </p>
      
      <div style={{ background: 'white', padding: '1.5rem', borderRadius: '12px', marginBottom: '1rem' }}>
        <p style={{ fontSize: '0.9375rem', lineHeight: '1.7', color: '#374151', whiteSpace: 'pre-line', margin: 0 }}>
          {character.narrative}
        </p>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <strong style={{ color: '#166534', fontSize: '0.875rem', display: 'block', marginBottom: '0.5rem' }}>
          Emotional Keywords:
        </strong>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
          {character.emotionalKeywords.map((keyword, i) => (
            <span key={i} style={{
              padding: '0.375rem 0.75rem',
              background: '#dcfce7',
              color: '#166534',
              borderRadius: '6px',
              fontSize: '0.8125rem',
              fontWeight: '600'
            }}>
              {keyword}
            </span>
          ))}
        </div>
      </div>

      <div>
        <strong style={{ color: '#166534', fontSize: '0.875rem', display: 'block', marginBottom: '0.5rem' }}>
          Color Palette:
        </strong>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
          {character.emotionalColors.map((color, i) => (
            <span key={i} style={{
              padding: '0.375rem 0.75rem',
              background: '#dcfce7',
              color: '#166534',
              borderRadius: '6px',
              fontSize: '0.8125rem',
              fontWeight: '600'
            }}>
              {color}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// STEP 2: LIVING SPACE (SCENE BLUEPRINT COMPOSER INTEGRATED) 🌟
// ═══════════════════════════════════════════════════════════════════════

function StepLivingSpace({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [livingSpace, setLivingSpace] = useState(pipelineData.livingSpace);
  const [layers, setLayers] = useState(null);

  const generateLivingSpace = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const character = pipelineData.characterStory;
    
    // SCENE BLUEPRINT COMPOSER - Auto-populate layers from character
    const sceneLayers = {
      spatial: {
        enabled: true,
        weight: 1.2,
        prompt: `Converted barn studio in rural Vermont. Long weathered white-painted workbench (7 feet) centered in space. Low linen-upholstered bench in corner with natural cushions. Floor-to-ceiling built-in shelving (pearl gray) on left wall. Wide plank gray-washed oak floors. Tall Crittall-style windows (10 feet, matte black steel) along right wall showing winter Vermont forest with bare trees, melting snow patches.`
      },
      lighting: {
        enabled: true,
        weight: 1.4,
        prompt: `Soft overcast afternoon light (3-4pm) from tall windows creating even shadowless illumination, cool color temperature (5500K). Misty ethereal quality. Gentle graduated tones. Slight warmth reflected from natural materials.`
      },
      elements: {
        enabled: true,
        weight: 1.1,
        prompt: `Sparse winter botanicals: pussy willows with silver catkins in frosted glass cylinder, hellebores (pale pink) in white ceramic vase, dried specimens in glass jars. Forcing bulbs (paperwhites, hyacinth) in terracotta showing green shoots. Open leather plant journal with watercolors. Smooth river stones. Minimal styling, intentional negative space.`
      },
      color: {
        enabled: true,
        weight: 1.2,
        prompt: `Cool winter palette. Soft whites, pearl grays, cool mid-grays dominant (70%). Minimal color: pale pink hellebores, soft sage green, emerging green shoots (30%). Natural materials: gray-washed oak, white-painted pine, natural linen, undyed wool. Desaturated, muted tones.`
      },
      camera: {
        enabled: true,
        weight: 1.0,
        prompt: `50mm prime lens, f/4 aperture for extended depth of field. Standing height (5.5 feet), straight-on minimal angle. Rule of thirds: workbench lower third. Golden ratio visual weight left (70/30). Negative space upper-right and across surface.`
      },
      mood: {
        enabled: true,
        weight: 1.1,
        prompt: `Minimalist, contemplative, transitional, ethereal, wabi-sabi. Scandinavian-Japanese fusion. Winter awakening, botanical study, scholarly, peaceful, meditative. Cereal magazine aesthetic, monastic quality. Photorealistic textures, 8K resolution, editorial quality.`
      }
    };

    // Combine layers into master prompt
    const masterPrompt = combineLayers(sceneLayers);
    
    const space = {
      layers: sceneLayers,
      masterPrompt: masterPrompt,
      wallColor: 'soft pearl gray',
      lightingDescription: sceneLayers.lighting.prompt,
      colorDescription: sceneLayers.color.prompt,
      aesthetic: character.aesthetic,
      emotionalColors: character.emotionalColors
    };
    
    setLayers(sceneLayers);
    setLivingSpace(space);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, livingSpace }));
    onNext();
  };

  return (
    <div style={{ background: 'white', borderRadius: '20px', padding: '3rem', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '0.5rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        {pipelineData.characterStory?.name}'s Living Space
      </h2>
      <p style={{ fontSize: '1rem', color: '#6b7280', marginBottom: '2rem' }}>
        Using Scene Blueprint Composer to generate layered scene prompt
      </p>

      {!livingSpace ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Home size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <button
            onClick={generateLivingSpace}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Layers size={20} />
            {isGenerating ? 'Generating Layered Scene...' : 'Generate Living Space'}
          </button>
        </div>
      ) : (
        <div>
          {/* Layer Display */}
          <div style={{ marginBottom: '2rem' }}>
            <h3 style={{ fontSize: '1.25rem', fontWeight: '700', marginBottom: '1rem', color: '#1f2937' }}>
              Scene Layers (Compositional Prompt)
            </h3>
            {Object.entries(livingSpace.layers).map(([key, layer]) => (
              <div key={key} style={{
                background: '#f9fafb',
                padding: '1rem',
                borderRadius: '12px',
                marginBottom: '0.75rem',
                borderLeft: `4px solid #667eea`
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <span style={{ fontSize: '0.875rem', fontWeight: '700', color: '#1f2937', textTransform: 'capitalize' }}>
                    {key}
                  </span>
                  <span style={{
                    padding: '0.125rem 0.5rem',
                    background: '#fbbf24',
                    color: 'white',
                    borderRadius: '6px',
                    fontSize: '0.75rem',
                    fontWeight: '700'
                  }}>
                    {layer.weight}x
                  </span>
                </div>
                <p style={{ fontSize: '0.8125rem', color: '#6b7280', margin: 0, lineHeight: '1.5' }}>
                  {layer.prompt}
                </p>
              </div>
            ))}
          </div>

          {/* Master Prompt */}
          <div style={{
            background: '#f0fdf4',
            border: '2px solid #86efac',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '2rem'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.75rem' }}>
              <h4 style={{ fontSize: '1rem', fontWeight: '700', margin: 0, color: '#166534' }}>
                Complete Scene Prompt:
              </h4>
              <button
                onClick={() => navigator.clipboard.writeText(livingSpace.masterPrompt)}
                style={{
                  padding: '0.5rem 1rem',
                  background: 'white',
                  border: '1px solid #86efac',
                  borderRadius: '8px',
                  fontSize: '0.875rem',
                  fontWeight: '600',
                  color: '#166534',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}
              >
                <Copy size={16} />
                Copy
              </button>
            </div>
            <p style={{
              fontSize: '0.875rem',
              lineHeight: '1.6',
              color: '#15803d',
              fontFamily: '"SF Mono", Monaco, monospace',
              margin: 0,
              whiteSpace: 'pre-wrap'
            }}>
              {livingSpace.masterPrompt}
            </p>
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Select Florals from Inventory
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function combineLayers(layers) {
  const enabled = Object.entries(layers)
    .filter(([_, layer]) => layer.enabled)
    .sort((a, b) => b[1].weight - a[1].weight);
  
  const parts = enabled.map(([key, layer]) => {
    const priority = layer.weight > 1.2 ? '[HIGH PRIORITY] ' : '';
    return `${priority}${key.toUpperCase()}: ${layer.prompt}`;
  });
  
  return `High-resolution interior photography. ${parts.join('\n\n')}

Professional architectural photography, editorial quality, suitable for Cereal magazine or Kinfolk publication.`;
}

// ═══════════════════════════════════════════════════════════════════════
// STEP 3: FLORAL SELECTION (CONTINUED FROM V2)
// ═══════════════════════════════════════════════════════════════════════

function StepFloralSelection({ floralInventory, pipelineData, setPipelineData, onNext, onBack }) {
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectedFlorals, setSelectedFlorals] = useState(pipelineData.selectedFlorals || []);

  const runSelection = async () => {
    setIsSelecting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Run selection algorithm
    const selected = selectFloralsFromInventory(
      floralInventory,
      pipelineData.characterStory,
      pipelineData.livingSpace
    );
    
    setSelectedFlorals(selected);
    setIsSelecting(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, selectedFlorals }));
    onNext();
  };

  // Selection algorithm implementation
  function selectFloralsFromInventory(inventory, character, space) {
    return inventory.map(floral => {
      let score = 0;
      const reasons = [];
      
      // Emotional matching (40 pts)
      const floralEmotions = floral.visualIntelligence?.designIntelligence?.emotionalAttributes || [];
      floralEmotions.forEach(emotion => {
        if (character.emotionalKeywords.some(ce => 
          ce.toLowerCase().includes(emotion.toLowerCase()) ||
          emotion.toLowerCase().includes(ce.toLowerCase())
        )) {
          score += 10;
          reasons.push(`Emotional: "${emotion}"`);
        }
      });
      
      // Color matching (30 pts)
      const floralColors = [
        floral.visualIntelligence?.visualProperties?.colorProfile?.primary,
        ...(floral.visualIntelligence?.visualProperties?.colorProfile?.secondary || [])
      ].filter(Boolean);
      
      floralColors.forEach(colorObj => {
        if (space.emotionalColors.some(sc => 
          sc.toLowerCase().includes(colorObj.name.toLowerCase()) ||
          colorObj.name.toLowerCase().includes(sc.toLowerCase())
        )) {
          score += 10;
          reasons.push(`Color: ${colorObj.name}`);
        }
      });
      
      // Seasonality (20 pts)
      const floralSeasons = floral.visualIntelligence?.designIntelligence?.seasonality || [];
      if (floralSeasons.includes(character.season) || floralSeasons.includes('all-season')) {
        score += 20;
        reasons.push(`Season: ${character.season}`);
      }
      
      return { ...floral, selectionScore: score, selectionReasons: reasons };
    })
    .filter(f => f.selectionScore > 15)
    .sort((a, b) => b.selectionScore - a.selectionScore)
    .slice(0, 7);
  }

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
      maxHeight: '80vh',
      overflowY: 'auto'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        AI Floral Selection
      </h2>

      {selectedFlorals.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Sparkles size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <button
            onClick={runSelection}
            disabled={isSelecting}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}
          >
            {isSelecting ? 'Analyzing...' : 'Run AI Selection'}
          </button>
        </div>
      ) : (
        <div>
          <FloralSelectionDisplay florals={selectedFlorals} />
          
          <div style={{ display: 'flex', gap: '1rem', marginTop: '2rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Design Wreath
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function FloralSelectionDisplay({ florals }) {
  return (
    <>
      <div style={{
        background: '#f0fdf4',
        padding: '1rem',
        borderRadius: '12px',
        marginBottom: '1.5rem'
      }}>
        <strong style={{ color: '#166534' }}>
          ✓ Selected {florals.length} florals with total match score of {florals.reduce((sum, f) => sum + f.selectionScore, 0)}
        </strong>
      </div>
      
      {florals.map(floral => (
        <div key={floral.sku} style={{
          background: '#f9fafb',
          borderRadius: '12px',
          padding: '1rem',
          display: 'grid',
          gridTemplateColumns: '80px 1fr auto',
          gap: '1rem',
          marginBottom: '1rem',
          alignItems: 'center'
        }}>
          <div style={{
            width: '80px',
            height: '80px',
            borderRadius: '8px',
            overflow: 'hidden',
            background: '#e5e7eb'
          }}>
            {floral.images?.main && (
              <img src={floral.images.main} alt={floral.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            )}
          </div>
          
          <div>
            <h4 style={{ fontSize: '1rem', fontWeight: '700', margin: '0 0 0.5rem', color: '#1f2937' }}>
              {floral.name}
            </h4>
            <p style={{ fontSize: '0.8125rem', color: '#6b7280', margin: '0 0 0.5rem' }}>
              <strong>Color:</strong> {floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name || 'N/A'}
              {' • '}
              <strong>Role:</strong> {floral.visualIntelligence?.designIntelligence?.designRole || 'N/A'}
            </p>
            {floral.selectionReasons.length > 0 && (
              <p style={{ fontSize: '0.75rem', color: '#16a34a', fontStyle: 'italic', margin: 0 }}>
                {floral.selectionReasons.slice(0, 2).join(' • ')}
              </p>
            )}
          </div>
          
          <div style={{
            background: '#667eea',
            color: 'white',
            padding: '0.5rem 1rem',
            borderRadius: '8px',
            textAlign: 'center',
            minWidth: '70px'
          }}>
            <div style={{ fontSize: '1.5rem', fontWeight: '900' }}>{floral.selectionScore}</div>
            <div style={{ fontSize: '0.625rem', opacity: 0.9 }}>MATCH</div>
          </div>
        </div>
      ))}
    </>
  );
}

// Continue with Steps 4-7 in next file part...

// ═══════════════════════════════════════════════════════════════════════
// STEP 6: ASSEMBLY GUIDE (Simple Display)
// ═══════════════════════════════════════════════════════════════════════

function StepAssemblyGuide({ pipelineData, setPipelineData, onNext, onBack }) {
  return (
    <div style={{ background: 'white', borderRadius: '20px', padding: '3rem', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Assembly Guide
      </h2>
      <p style={{ color: '#16a34a', marginBottom: '2rem', fontSize: '1.125rem', fontWeight: '600' }}>
        ✓ 5-layer assembly guide with image prompts generated
      </p>
      
      <div style={{ display: 'flex', gap: '1rem' }}>
        <button onClick={onBack} style={{
          flex: 1,
          padding: '1rem',
          background: '#f3f4f6',
          color: '#374151',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1rem',
          fontWeight: '700',
          cursor: 'pointer'
        }}>
          Back
        </button>
        <button onClick={onNext} style={{
          flex: 2,
          padding: '1rem',
          background: 'linear-gradient(135deg, #667eea, #764ba2)',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1rem',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem'
        }}>
          Create Product Package
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// STEP 7: PRODUCT PACKAGE (Final Export)
// ═══════════════════════════════════════════════════════════════════════

function StepProductPackage({ pipelineData, onBack }) {
  const exportJSON = () => {
    const blob = new Blob([JSON.stringify(pipelineData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `empathy-engine-${Date.now()}.json`;
    a.click();
  };

  return (
    <div style={{ background: 'white', borderRadius: '20px', padding: '3rem', boxShadow: '0 20px 60px rgba(0,0,0,0.2)' }}>
      <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <CheckCircle size={80} color="#10b981" style={{ margin: '0 auto 1.5rem' }} />
        <h2 style={{
          fontSize: '2.5rem',
          fontWeight: '900',
          marginBottom: '0.5rem',
          background: 'linear-gradient(135deg, #667eea, #764ba2)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent'
        }}>
          Complete Package Ready!
        </h2>
        <p style={{ fontSize: '1.25rem', color: '#6b7280' }}>
          "{pipelineData.wreathDesign?.name}" for {pipelineData.characterStory?.name}
        </p>
      </div>

      {/* Package Contents */}
      <div style={{
        background: '#f0fdf4',
        borderRadius: '16px',
        padding: '2rem',
        marginBottom: '2rem'
      }}>
        <h3 style={{ fontSize: '1.5rem', fontWeight: '800', marginBottom: '1.5rem', color: '#166534' }}>
          Package Includes:
        </h3>
        <div style={{ display: 'grid', gap: '0.75rem' }}>
          {[
            '📖 Character Story (who this wreath is for)',
            '🏠 Living Space Scene (generated with Scene Blueprint Composer)',
            '🌸 Wreath Design (with positioning blueprint)',
            '📸 Product Shot (flat lay professional photography)',
            '🌟 Context Shot (wreath IN the living space!) ⭐',
            '🛠️ Assembly Guide (5 layers with image prompts)',
            '📝 Complete emotional narrative',
            '💾 All data exportable as JSON'
          ].map((item, i) => (
            <div key={i} style={{
              background: 'white',
              padding: '1rem',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem'
            }}>
              <div style={{
                width: '24px',
                height: '24px',
                background: '#10b981',
                borderRadius: '50%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <span style={{ color: 'white', fontSize: '0.75rem', fontWeight: '700' }}>✓</span>
              </div>
              <span style={{ fontSize: '0.9375rem', color: '#166534', fontWeight: '600' }}>
                {item}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Export Button */}
      <button
        onClick={exportJSON}
        style={{
          width: '100%',
          padding: '1.25rem',
          background: 'linear-gradient(135deg, #667eea, #764ba2)',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1.125rem',
          fontWeight: '700',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          marginBottom: '1rem'
        }}
      >
        <Download size={24} />
        Export Complete Package (JSON)
      </button>

      <button onClick={onBack} style={{
        width: '100%',
        padding: '1rem',
        background: '#f3f4f6',
        color: '#374151',
        border: 'none',
        borderRadius: '12px',
        fontSize: '1rem',
        fontWeight: '700',
        cursor: 'pointer'
      }}>
        Back
      </button>
    </div>
  );
}

# Empathy Engine V2: Integration with Enhanced Catalog
## Complete Technical Guide

---

## Your Inventory Structure is GOLD

Your `enhanced_catalog_v2.json` has everything we need for intelligent wreath design:

### Key Data Structures We're Using:

#### 1. **Emotional Attributes** (`visualIntelligence.designIntelligence.emotionalAttributes`)
```json
"emotionalAttributes": ["elegant", "romantic", "graceful"]
```
**How we use it**: Match against character's emotional keywords
- Character: "contemplative, elegant" → Florals tagged "elegant" get +10 score

#### 2. **Color Profile** (`visualIntelligence.visualProperties.colorProfile`)
```json
"colorProfile": {
  "primary": {"hex": "#F5F5DC", "name": "Cream White", "percentage": 70},
  "secondary": [
    {"hex": "#6B8E23", "name": "Olive Green", "percentage": 20}
  ]
}
```
**How we use it**: Match against space color palette
- Space palette: ["Soft white", "Pearl gray"] → Cream White florals get +10 score

#### 3. **Geometry V2** (`visualIntelligence.geometryV2`)
```json
"anchorPoint": {"normalized": {"x": 0.5, "y": 0.95}, "confidence": 0.95},
"bloomCenter": {"normalized": {"x": 0.5, "y": 0.35}, "confidence": 0.9},
"principalAxis": {"degrees": -2.0, "confidence": 0.85}
```
**How we use it**: Precise positioning in wreath
- Anchor point → Where stem attaches to wreath base
- Bloom center → Visual weight distribution
- Principal axis → Rotation angle for natural look

#### 4. **Spatial Properties** (`visualIntelligence.spatialProperties`)
```json
"coverageArea": 140,
"opacity": 0.75,
"visualDensity": 0.6,
"recommendedQuantity24in": 2
```
**How we use it**: Calculate how many stems needed
- 20" wreath → Use ~80% of 24" recommendation = 1-2 stems

#### 5. **Design Intelligence** (`visualIntelligence.designIntelligence`)
```json
"idealLayer": 1,
"designRole": "focal",
"colorStory": "neutral",
"seasonality": ["spring", "summer"],
"styleCompatibility": ["traditional", "romantic", "garden"]
```
**How we use it**:
- `designRole: "focal"` → Gets primary positioning (50°, 135°, 220°)
- `idealLayer: 1` → Added early in assembly sequence
- `seasonality` → Match against character's season preference

---

## Floral Selection Algorithm (In Detail)

```javascript
function selectFloralsFromInventory(inventory, characterProfile, spaceProfile) {
  const scored = inventory.map(floral => {
    let score = 0;
    const reasons = [];
    
    // SCORING SYSTEM (100 points max)
    
    // 1. EMOTIONAL MATCHING (40 points max)
    // Match floral.emotionalAttributes against character.emotionalKeywords
    const floralEmotions = floral.visualIntelligence?.designIntelligence?.emotionalAttributes || [];
    const characterEmotions = characterProfile.emotionalKeywords || [];
    
    floralEmotions.forEach(emotion => {
      if (characterEmotions.some(ce => 
        ce.toLowerCase().includes(emotion.toLowerCase()) ||
        emotion.toLowerCase().includes(ce.toLowerCase())
      )) {
        score += 10;
        reasons.push(`Emotional match: "${emotion}" aligns with ${characterProfile.name}'s profile`);
      }
    });
    
    // 2. COLOR PALETTE MATCHING (30 points max)
    // Match floral colors against space.emotionalColors
    const floralColors = [
      floral.visualIntelligence?.visualProperties?.colorProfile?.primary,
      ...(floral.visualIntelligence?.visualProperties?.colorProfile?.secondary || [])
    ];
    
    const spaceColors = spaceProfile.emotionalColors || [];
    
    floralColors.forEach(colorObj => {
      if (!colorObj) return;
      
      // Exact name match
      if (spaceColors.some(sc => sc.toLowerCase() === colorObj.name.toLowerCase())) {
        score += 15;
        reasons.push(`Perfect color match: ${colorObj.name}`);
      }
      // Partial name match (e.g., "Pale Pink" matches "Pink")
      else if (spaceColors.some(sc => 
        sc.toLowerCase().includes(colorObj.name.toLowerCase()) ||
        colorObj.name.toLowerCase().includes(sc.toLowerCase())
      )) {
        score += 10;
        reasons.push(`Color family match: ${colorObj.name}`);
      }
    });
    
    // 3. SEASONALITY MATCHING (20 points max)
    const floralSeasons = floral.visualIntelligence?.designIntelligence?.seasonality || [];
    const characterSeason = characterProfile.season || 'all-season';
    
    if (floralSeasons.includes(characterSeason)) {
      score += 20;
      reasons.push(`Perfect seasonal fit: ${characterSeason}`);
    } else if (floralSeasons.includes('all-season')) {
      score += 15;
      reasons.push(`All-season versatility`);
    }
    
    // 4. STYLE COMPATIBILITY (10 points max)
    const floralStyles = floral.visualIntelligence?.designIntelligence?.styleCompatibility || [];
    const characterStyle = characterProfile.aesthetic || '';
    
    // Look for style keywords in character aesthetic
    floralStyles.forEach(style => {
      if (characterStyle.toLowerCase().includes(style.toLowerCase())) {
        score += 5;
        reasons.push(`Style match: ${style}`);
      }
    });
    
    // BONUS SCORING
    
    // Bonus: Stock availability
    if (floral.inStock) {
      score += 5;
      reasons.push(`In stock and available`);
    }
    
    // Bonus: High quality geometry data
    if (floral.visualIntelligence?.geometryV2?.anchorPoint?.confidence > 0.9) {
      score += 3;
      reasons.push(`High-confidence geometry for precise positioning`);
    }
    
    return {
      ...floral,
      selectionScore: score,
      selectionReasons: reasons
    };
  });
  
  // FILTERING & RANKING
  
  return scored
    .filter(f => f.selectionScore > 15) // Minimum threshold
    .sort((a, b) => b.selectionScore - a.selectionScore)
    .slice(0, 7); // Top 7 florals
}
```

### Example Selection Output:

```javascript
// Character: Eleanor (contemplative, elegant, winter, minimalist)
// Space: Soft whites, pearl grays, cool palette

Selected Florals:
[
  {
    name: "Seeded Eucalyptus Spray 18\" - Silver Green",
    selectionScore: 85,
    selectionReasons: [
      "Emotional match: 'sophisticated' aligns with Eleanor's profile",
      "Emotional match: 'calming' aligns with Eleanor's profile",
      "Perfect color match: Silver Green",
      "Color family match: Cool Green",
      "Perfect seasonal fit: winter",
      "All-season versatility",
      "Style match: modern",
      "Style match: scandinavian",
      "In stock and available",
      "High-confidence geometry for precise positioning"
    ],
    designRole: "accent", // Will be distributed around wreath
    idealLayer: 1, // Added early (base layer)
    recommendedQuantity24in: 4, // Need ~3 for 20" wreath
    colorHex: "#9DB2A0" // For image generation prompts
  },
  
  {
    name: "Hanging Wisteria Spray 67\" - Cream",
    selectionScore: 70,
    selectionReasons: [
      "Emotional match: 'elegant' aligns with Eleanor's profile",
      "Emotional match: 'romantic' aligns with Eleanor's profile",
      "Perfect color match: Cream White",
      "Style match: traditional",
      "Style match: elegant",
      "In stock and available"
    ],
    designRole: "focal", // Will get primary positioning at 50°, 135°, or 220°
    idealLayer: 2, // Added after base
    recommendedQuantity24in: 2, // Need ~1-2 for 20" wreath
    colorHex: "#F5F5DC"
  },
  
  // ... 5 more florals
]
```

---

## Wreath Positioning Engine (Using Real Geometry)

```javascript
function generateWreathPositioning(selectedFlorals, wreathSize = 20) {
  const goldenRatio = 1.618;
  
  // Calculate focal points using golden ratio
  const focalPoints = [
    Math.round(360 / goldenRatio / 1.5), // ~50°
    Math.round(360 / goldenRatio),       // ~135°  
    360 - Math.round(360 / goldenRatio / 1.5) // ~220°
  ];
  
  return selectedFlorals.map((floral, index) => {
    const designRole = floral.visualIntelligence?.designIntelligence?.designRole || 'accent';
    const geometry = floral.visualIntelligence?.geometryV2;
    const spatial = floral.visualIntelligence?.spatialProperties;
    
    // FOCAL ELEMENTS: Get prime real estate
    if (designRole === 'focal' && index < 3) {
      const angle = focalPoints[index];
      
      // Calculate quantity based on wreath size
      const baseQty = spatial?.recommendedQuantity24in || 2;
      const quantity = Math.ceil(baseQty * (wreathSize / 24));
      
      return {
        floral,
        position: {
          angle: angle,
          radiusSpread: [0, 30], // Can spread 30° from center
          depthRange: [2, 4], // Project 2-4" from wreath surface
          quantity: quantity
        },
        geometry: {
          // Normalized coordinates from actual image analysis
          anchorPoint: geometry?.anchorPoint?.normalized || {x: 0.5, y: 0.95},
          bloomCenter: geometry?.bloomCenter?.normalized || {x: 0.5, y: 0.5},
          principalAxis: geometry?.principalAxis?.degrees || 0,
          confidence: geometry?.anchorPoint?.confidence || 0.5
        },
        rendering: {
          // Use actual visual properties
          coverageArea: spatial?.coverageArea || 100,
          opacity: spatial?.opacity || 0.8,
          visualDensity: spatial?.visualDensity || 0.6,
          blendMode: floral.visualIntelligence?.edgeProfile?.blendModePreference || 'normal'
        },
        reasoning: `${designRole.toUpperCase()}: Positioned at golden ratio focal point (${angle}°) for maximum visual impact`
      };
    }
    
    // ACCENT/FILLER ELEMENTS: Distributed for rhythm
    else {
      // Space evenly around circumference, offset to avoid focal points
      const baseAngle = ((index - 2) * 360 / (selectedFlorals.length - 3)) + 25;
      const quantity = Math.ceil((spatial?.recommendedQuantity24in || 3) * (wreathSize / 24));
      
      return {
        floral,
        position: {
          angle: baseAngle % 360,
          radiusSpread: [0, 20],
          depthRange: [1, 2],
          quantity: quantity
        },
        geometry: {
          anchorPoint: geometry?.anchorPoint?.normalized || {x: 0.5, y: 0.95},
          bloomCenter: geometry?.bloomCenter?.normalized || {x: 0.5, y: 0.5},
          principalAxis: geometry?.principalAxis?.degrees || 0,
          confidence: geometry?.anchorPoint?.confidence || 0.5
        },
        rendering: {
          coverageArea: spatial?.coverageArea || 80,
          opacity: spatial?.opacity || 0.75,
          visualDensity: spatial?.visualDensity || 0.5,
          blendMode: floral.visualIntelligence?.edgeProfile?.blendModePreference || 'normal'
        },
        reasoning: `${designRole.toUpperCase()}: Distributed for rhythmic balance and textural variety`
      };
    }
  });
}
```

### Example Positioning Output:

```javascript
[
  {
    floral: {name: "Hanging Wisteria Spray 67\" - Cream", ...},
    position: {
      angle: 50,        // Upper right golden ratio point
      radiusSpread: [0, 30],
      depthRange: [2, 4],
      quantity: 2       // Based on recommendedQuantity24in
    },
    geometry: {
      anchorPoint: {x: 0.5, y: 0.95},  // Bottom center of stem
      bloomCenter: {x: 0.5, y: 0.35},  // Where visual mass concentrates
      principalAxis: -2.0,              // Slight rightward lean
      confidence: 0.95
    },
    rendering: {
      coverageArea: 140,
      opacity: 0.75,
      visualDensity: 0.6,
      blendMode: 'normal'
    },
    reasoning: "FOCAL: Positioned at golden ratio focal point (50°) for maximum visual impact"
  },
  
  {
    floral: {name: "Seeded Eucalyptus Spray 18\" - Silver Green", ...},
    position: {
      angle: 85,        // Distributed between focal points
      radiusSpread: [0, 20],
      depthRange: [1, 2],
      quantity: 3
    },
    geometry: {
      anchorPoint: {x: 0.5, y: 0.95},
      bloomCenter: {x: 0.5, y: 0.45},
      principalAxis: 0.0,
      confidence: 0.92
    },
    rendering: {
      coverageArea: 85,
      opacity: 0.75,
      visualDensity: 0.6,
      blendMode: 'normal'
    },
    reasoning: "ACCENT: Distributed for rhythmic balance and textural variety"
  },
  
  // ... more positioned florals
]
```

---

## Wreath Image Generation (Using Actual Floral Data)

### Master Wreath Prompt:

```javascript
function generateWreathImagePrompt(selectedFlorals, positioning, characterStory, livingSpace) {
  // Extract floral details from REAL inventory data
  const floralList = positioning.map(p => {
    const floral = p.floral;
    const color = floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name 
                  || floral.productSpecs?.color;
    const length = floral.dimensions?.length;
    const qty = p.position.quantity;
    
    return `${qty}x ${floral.name} (${color}, ${length}" length)`;
  }).join(', ');
  
  // Get actual color hex codes
  const colorHexes = positioning
    .map(p => p.floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.hex)
    .filter(Boolean)
    .slice(0, 5);
  
  // Get actual emotional attributes
  const emotionalTags = [...new Set(
    selectedFlorals.flatMap(f => 
      f.visualIntelligence?.designIntelligence?.emotionalAttributes || []
    )
  )].slice(0, 5);
  
  // Get focal point angles
  const focalAngles = positioning
    .filter(p => p.floral.visualIntelligence?.designIntelligence?.designRole === 'focal')
    .map(p => p.position.angle + '°')
    .join(', ');
  
  return `Professional product photography of handmade luxury faux floral wreath, 20 inches diameter, hanging centered on ${livingSpace.wallColor} linen backdrop. 

${characterStory.aesthetic} design aesthetic featuring: ${floralList}.

Base: Whitewashed grapevine wreath, 5-6 inches depth projection. ${positioning.length} distinct floral elements positioned asymmetrically with focal clusters at ${focalAngles} following golden ratio composition.

Color palette: Primary colors ${colorHexes.join(', ')}, creating ${livingSpace.colorDescription}. Emotional qualities: ${emotionalTags.join(', ')}.

${livingSpace.lightingDescription}.

Styling notes: ${characterStory.wreathCharacteristics}. Shows natural depth and dimension with layered florals at varying projections (1-4 inches). Each stem positioned following plant's natural growth patterns with realistic draping and movement.

Professional florist craftsmanship, photorealistic silk and fabric textures showing individual petal detail and realistic foliage, 8K resolution, shallow depth of field (f/2.8) with sharp focus on wreath and soft bokeh on background, ${characterStory.mood} atmosphere. 

Shot with 50mm prime lens at eye level, rule of thirds composition, editorial quality matching ${emotionalTags[0]} aesthetic for Cereal magazine or Kinfolk publication standards.`;
}
```

### Example Generated Prompt:

```
Professional product photography of handmade luxury faux floral wreath, 20 inches diameter, hanging centered on soft pearl gray linen backdrop. 

Minimalist with intention, wabi-sabi restraint design aesthetic featuring: 2x Hanging Wisteria Spray 67" - Cream (Cream White, 67" length), 3x Seeded Eucalyptus Spray 18" - Silver Green (Silver Green, 18" length), 2x Pale Pink Hellebore Stem (Pale Pink, 24" length), 1x White Ranunculus Bundle (Pure White, 12" length), 3x Dried Hydrangea Head (Faded Taupe, 8" length), 2x Pussy Willow Branch (Silver Gray, 22" length), 4x Dusty Miller Spray (Frosted Silver, 14" length).

Base: Whitewashed grapevine wreath, 5-6 inches depth projection. 7 distinct floral elements positioned asymmetrically with focal clusters at 50°, 135°, 220° following golden ratio composition.

Color palette: Primary colors #F5F5DC, #9DB2A0, #E8D4D8, #FFFFFF, #B09E94, creating soft whites, pearl grays, pale blush pink, cool blue-gray as primary palette with natural materials. Emotional qualities: elegant, sophisticated, calming, romantic, natural.

Soft overcast afternoon light from tall windows, even shadowless illumination, cool temperature (5500K).

Styling notes: Sparse, asymmetric, intentional negative space, winter botanicals. Shows natural depth and dimension with layered florals at varying projections (1-4 inches). Each stem positioned following plant's natural growth patterns with realistic draping and movement.

Professional florist craftsmanship, photorealistic silk and fabric textures showing individual petal detail and realistic foliage, 8K resolution, shallow depth of field (f/2.8) with sharp focus on wreath and soft bokeh on background, contemplative and quietly hopeful atmosphere. 

Shot with 50mm prime lens at eye level, rule of thirds composition, editorial quality matching elegant aesthetic for Cereal magazine or Kinfolk publication standards.
```

---

## Assembly Layer Prompts (Using Geometry Data)

```javascript
function generateAssemblyLayerPrompt(layer, positioning) {
  // Find florals for this layer based on idealLayer in inventory
  const layerFlorals = positioning.filter(p => 
    p.floral.visualIntelligence?.designIntelligence?.idealLayer === layer.number
  );
  
  const floralDetails = layerFlorals.map(p => {
    const f = p.floral;
    const geo = p.geometry;
    const color = f.visualIntelligence?.visualProperties?.colorProfile?.primary?.name;
    const texture = f.visualIntelligence?.visualProperties?.texture;
    
    return `${p.position.quantity}x ${f.name} (${color}, ${texture} texture) positioned at ${p.position.angle}° with anchor point at (${geo.anchorPoint.x}, ${geo.anchorPoint.y}) and ${p.position.depthRange[0]}-${p.position.depthRange[1]}" projection depth`;
  }).join('; ');
  
  return `Close-up instructional product photography, Layer ${layer.number} of wreath assembly: "${layer.name}". 

Florals being added this layer: ${floralDetails}.

Hands visible in frame demonstrating ${layer.technique} using ${layer.tools}. ${layer.instructions}. Clear detail showing how stem anchor points align with wreath base at specified angles for natural positioning.

Visual emphasis on ${layerFlorals[0]?.floral.visualIntelligence?.visualProperties?.texture || 'realistic floral texture'}, natural growth patterns, and dimensional layering. Background shows previous assembly layers already in place creating context.

Shot with macro lens (100mm), f/4 aperture for extended depth of field showing both hands and florals in focus, soft natural light from upper left (45° angle), professional DIY tutorial aesthetic with instructional clarity, 8K resolution, clean composition suitable for step-by-step assembly guide.`;
}

// Layer definitions with idealLayer mapping
const assemblyLayers = [
  {
    number: 1,
    name: "Eucalyptus Base Foundation",
    technique: "stem wire wrapping technique",
    tools: "24-gauge floral wire and wire cutters",
    instructions: "Attach eucalyptus stems around wreath base in overlapping pattern, creating 60% coverage with intentional gaps. Wire every 3-4 inches for security.",
    // Automatically includes florals where idealLayer === 1
  },
  {
    number: 2,
    name: "Primary Focal Elements",
    technique: "floral pick insertion and wire reinforcement",
    tools: "floral picks, 22-gauge wire",
    instructions: "Insert focal florals (wisteria, peonies) at golden ratio positions (50°, 135°, 220°), securing with picks and reinforcing with wire wrap. Build 3-4 inch depth.",
    // Automatically includes florals where idealLayer === 2
  },
  // ... more layers
];
```

---

## Complete Pipeline Data Flow

```
Step 0: Load Inventory JSON
   ↓
{enhanced_catalog_v2.json loaded}
   - 100+ florals with full metadata
   - Emotional attributes, colors, geometry, spatial data

Step 1: Emotional Input
   ↓
"Quiet hope during late winter..."
   ↓
{emotionalInput: "...", inventory: [...]}

Step 2: Generate Character
   ↓
AI analyzes emotional input →
   ↓
{
  name: "Eleanor Hayes",
  emotionalKeywords: ["contemplative", "elegant", "patient"],
  season: "winter",
  aesthetic: "Minimalist, wabi-sabi",
  emotionalColors: ["Soft white", "Pearl gray", "Pale pink"]
}

Step 3: Generate Living Space
   ↓
Uses character.emotionalColors, character.aesthetic →
   ↓
{
  wallColor: "soft pearl gray",
  lightingDescription: "Soft overcast...",
  colorDescription: "Soft whites, pearl grays..."
}

Step 4: AI Floral Selection
   ↓
selectFloralsFromInventory(inventory, character, space) →
   ↓
Scores each floral:
- Emotional match (40 pts)
- Color match (30 pts)
- Season match (20 pts)
- Style match (10 pts)
   ↓
{
  selectedFlorals: [
    {sku: "QSL005GR", selectionScore: 85, selectionReasons: [...]},
    {sku: "PWW2330CR", selectionScore: 70, selectionReasons: [...]},
    ... (7 total)
  ]
}

Step 5: Generate Positioning
   ↓
generateWreathPositioning(selectedFlorals) →
   ↓
Uses floral.geometryV2, floral.spatialProperties →
   ↓
{
  wreathPositioning: [
    {
      floral: {...},
      position: {angle: 50, quantity: 2, depth: [2,4]},
      geometry: {anchorPoint: {x: 0.5, y: 0.95}, ...},
      rendering: {coverageArea: 140, opacity: 0.75, ...}
    },
    ... (7 positioned florals)
  ]
}

Step 6: Generate Wreath Image Prompt
   ↓
generateWreathImagePrompt(selectedFlorals, positioning, character, space) →
   ↓
{
  wreathImagePrompt: "Professional product photography of handmade luxury...",
  midjourneySettings: "--ar 4:3 --style raw --stylize 100",
  expectedColors: ["#F5F5DC", "#9DB2A0", ...]
}

Step 7: Generate Assembly Guide
   ↓
For each layer (1-5):
  generateAssemblyLayerPrompt(layer, positioning) →
   ↓
{
  assemblyGuide: {
    layers: [
      {
        number: 1,
        name: "Eucalyptus Base",
        imagePrompt: "Close-up instructional...",
        floralsUsed: ["Seeded Eucalyptus"],
        timeEstimate: "15 min"
      },
      ... (5 layers total)
    ]
  }
}

Step 8: Package for Sale
   ↓
{
  productPackage: {
    name: '"Winter\'s Patience" Complete Collection',
    characterStory: {...},
    livingSpace: {...},
    wreathDesign: {...},
    floralInventory: [...selected florals...],
    wreathImagePrompts: {...},
    assemblyGuide: {...},
    pricing: {
      digital: "$37",
      physicalKit: "$145",
      finished: "$215"
    },
    exportFormats: ["PDF", "JSON", "Images", "Text"]
  }
}
```

---

## Where Wreath Images Get Generated

### **Three Generation Points:**

#### 1. **Hero Wreath Shot** (End of Step 5 - Wreath Rendering)
```javascript
// After positioning is calculated
const heroPrompt = generateWreathImagePrompt(
  selectedFlorals, 
  positioning, 
  characterStory, 
  livingSpace
);

// Call to Midjourney/DALL-E
const wreathImage = await fetch('https://api.replicate.com/v1/predictions', {
  method: 'POST',
  body: JSON.stringify({
    version: "midjourney-v6",
    input: {
      prompt: heroPrompt,
      aspect_ratio: "4:3",
      style_preset: "raw"
    }
  })
});

// Save URL
pipelineData.wreathImagePrompts.hero = {
  prompt: heroPrompt,
  imageURL: wreathImage.output[0]
};
```

#### 2. **Assembly Layer Images** (Step 6 - Assembly Guide)
```javascript
// For each of 5 assembly layers
for (let i = 0; i < assemblyLayers.length; i++) {
  const layerPrompt = generateAssemblyLayerPrompt(
    assemblyLayers[i], 
    positioning
  );
  
  const layerImage = await generateImage(layerPrompt);
  
  assemblyLayers[i].imageURL = layerImage.output[0];
}
```

#### 3. **In-Context Scene Shot** (Optional - premium package)
```javascript
// Composite: Wreath placed in Eleanor's living space
const contextPrompt = `${livingSpace.scenePrompt} with "${wreathDesign.name}" wreath hanging on wall at focal point. Wreath features ${floralList} in ${characterStory.aesthetic} styling.`;

const contextImage = await generateImage(contextPrompt);
```

---

## Cost Analysis

### Per Complete Pipeline Run:

**AI Text Generation (Claude Sonnet 4):**
- Character story: ~1500 tokens → $0.003
- Living space: ~1000 tokens → $0.002
- Floral selection reasoning: ~2000 tokens → $0.004
- Assembly prompts: ~1500 tokens → $0.003
- **Total AI text**: ~$0.012

**Image Generation (Midjourney):**
- Hero wreath shot: 1 image → $0.04
- Assembly layers: 5 images → $0.20
- (Optional) Context scene: 1 image → $0.04
- **Total images**: ~$0.24-0.28

**Total cost per wreath design**: ~$0.26

**Sell digital blueprint for $37** → **14,100% markup**

---

## Next Steps

1. **Complete the React app** with Steps 4-6 (wreath rendering, assembly, package)
2. **Add actual Midjourney/DALL-E API integration** for image generation
3. **Build export system** (PDF, JSON, image ZIP)
4. **Create Etsy listing template** generator
5. **Add inventory management** (track which florals used, update quantities)

Your inventory structure is absolutely perfect for this. We can build something POWERFUL.

Want me to complete the React app with the image generation integration?

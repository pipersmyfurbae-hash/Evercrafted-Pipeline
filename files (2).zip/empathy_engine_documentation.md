# Empathy Engine: Complete Pipeline Documentation
## From Emotion → Character → Space → Wreath → Sellable Product

---

## System Overview

The **Empathy Engine** is a complete end-to-end system that transforms emotional input into sellable wreath products with rich storytelling and technical specifications. It bridges the gap between human emotion and physical manufacturing through AI-powered character development, scene generation, and design automation.

### Pipeline Flow

```
Step 1: Emotional Input
   ↓ (AI analyzes emotion + floral inventory images)
Step 2: Character Story ("Who Lives Here")
   ↓ (AI generates persona based on emotion)
Step 3: Living Space (Scene Generation)
   ↓ (Uses layered prompt architecture)
Step 4: Wreath Design (From Actual Inventory)
   ↓ (AI selects florals that match character/space)
Step 5: Assembly Guide (Layer-by-Layer Instructions)
   ↓ (Generates image prompts for each assembly step)
Step 6: Product Package (Complete Sellable Bundle)
   ↓ (Story + Blueprint + Images + Florals List)
Final Output: Ready-to-sell digital or physical product
```

---

## Step-by-Step Breakdown

### STEP 1: Emotional Input

**Purpose**: Capture the foundational emotion or aesthetic direction

**User Inputs:**
- Text description of emotional intent
  - Example: "A sense of quiet hope during late winter, the feeling of sun finally warming your face after months of cold"
- Optional: Upload floral inventory images
  - Photos of available flowers, stems, bases, ribbons
  - System will analyze and catalog these for later use

**What Happens:**
1. Emotional text is parsed for:
   - Mood descriptors (hopeful, melancholic, joyful, nostalgic)
   - Seasonal references (winter, spring, autumn)
   - Sensory details (warmth, cold, soft, bright)
   - Color associations (whites, grays, pinks, greens)
   
2. Uploaded images (if any) are processed:
   - Computer vision identifies floral types
   - Color palette extracted
   - Textures and materials cataloged
   - Creates "Universal Floral Inventory Profile" for each item

**Output:**
- Emotional profile object
- Cataloged floral inventory (if images uploaded)

---

### STEP 2: Character Story ("Who Lives Here")

**Purpose**: Create a rich persona that embodies the emotional input

**AI Generation Process:**

The system uses the emotional input to generate a complete character profile:

```javascript
{
  name: "Eleanor Hayes",
  age: "Early 60s",
  occupation: "Retired Botanical Illustrator",
  location: "Converted barn studio in rural Vermont",
  personality: "Contemplative, patient, deeply attuned to seasonal cycles",
  dailyLife: "Morning walks to collect specimens, afternoons documenting...",
  aesthetic: "Minimalist with intention, every object has meaning...",
  emotionalState: "Peaceful anticipation - watching winter loosen its grip...",
  narrative: [Full paragraph story about who this person is],
  emotionalColors: ["Soft white", "Pearl gray", "Pale blush pink"...],
  floralPreferences: ["Pussy willows", "Hellebores", "Eucalyptus"...],
  spaceRequirements: ["Abundant natural light", "Minimal furniture"...]
}
```

**Character Development Algorithm:**

1. **Name Generation**: Based on emotional tone
   - Hopeful/gentle → soft, flowing names (Eleanor, Clara, Stella)
   - Strong/bold → firm, distinct names (Margot, Beatrix, Sloane)
   - Nostalgic → classic, timeless names (Dorothy, Margaret, Ruth)

2. **Age & Life Stage**: Mapped to emotional maturity
   - Youthful exuberance → 20s-30s
   - Settled contemplation → 40s-60s
   - Wisdom/reflection → 60s+

3. **Occupation**: Aligns with aesthetic preferences
   - Botanical emotion → illustrator, herbalist, gardener
   - Artistic emotion → painter, writer, photographer
   - Intellectual emotion → librarian, professor, archivist

4. **Location**: Reflects emotional setting
   - Quiet/contemplative → rural, isolated, studio spaces
   - Social/warm → urban loft, café, communal workshop
   - Nostalgic → family home, inherited property, cottage

5. **Narrative Construction**:
   - Opening: Character's current state
   - Middle: Daily rituals and practices
   - Resolution: Philosophy and worldview
   - Connection: How wreath represents their essence

**Why This Matters:**

The character story does three critical things:

1. **Emotional Anchoring**: Gives abstract feelings a human face
2. **Design Constraints**: Provides specific guidance for space/wreath design
3. **Storytelling for Sales**: Creates narrative that customers connect with emotionally

**Example Flow:**

```
Input: "Quiet hope during late winter"
   ↓
Character Generated: Eleanor Hayes
   - Retired botanical illustrator
   - Lives in converted barn
   - Observes nature's cycles patiently
   - Values minimalism and restraint
   ↓
This informs everything downstream:
   - Space will be minimalist, light-filled
   - Wreath will be sparse, winter botanicals
   - Story will emphasize patience and renewal
```

---

### STEP 3: Living Space (Scene Generation with Layered Prompts)

**Purpose**: Visualize the physical environment where this wreath would live

**Integration with Scene Blueprint Composer:**

This step uses the **layered prompt architecture** from the Scene Blueprint Composer app, but now the layers are auto-populated based on the character story:

```javascript
// Character story feeds into layers:

Spatial Layer (from character.spaceRequirements):
"Converted barn studio, Vermont. Long weathered workbench centered. 
Built-in shelving. Gray-washed oak floors. Tall Crittall windows..."

Lighting Layer (from character.emotionalState + season):
"Soft overcast afternoon light (3-4pm). Even shadowless illumination. 
Cool temperature (5500K). Misty ethereal quality..."

Elements Layer (from character.floralPreferences):
"Sparse winter botanicals: pussy willows, hellebores, dried specimens. 
Forcing bulbs. Minimal styling, intentional negative space..."

Color Layer (from character.emotionalColors):
"Cool winter palette. Soft whites, pearl grays (70%). 
Pale pink hellebores, soft sage green accents (30%)..."

Camera Layer (standard photographic specs):
"50mm prime lens, f/4 aperture. Standing height, straight-on. 
Rule of thirds composition..."

Mood Layer (from character.aesthetic + personality):
"Minimalist, contemplative, ethereal, wabi-sabi. Scandinavian-Japanese. 
Botanical study, scholarly, peaceful, meditative..."
```

**Layer Weight Assignments (Automated):**

The system automatically assigns weights based on character priorities:

```javascript
function assignLayerWeights(character) {
  return {
    lighting: character.emotionalState.includes('hope') ? 1.4 : 1.2,
    spatial: character.aesthetic.includes('minimal') ? 1.2 : 1.0,
    elements: character.occupation.includes('botanical') ? 1.3 : 1.1,
    color: character.emotionalColors.length > 5 ? 1.2 : 1.0,
    camera: 1.0, // Standard unless specified
    mood: 1.1 // Always important for cohesion
  };
}
```

**Generated Outputs:**

1. **Master Scene Prompt**: Complete text prompt for Midjourney/DALL-E
2. **Individual Layer Prompts**: Can be modified independently
3. **Platform-Specific Settings**: Midjourney parameters, SD negative prompts
4. **JSON Export**: Entire scene configuration for reuse

**Why Scene Generation Matters:**

The living space serves multiple purposes:

1. **Product Photography Context**: Shows wreath in realistic setting
2. **Lifestyle Marketing**: "Aspirational living" for customers
3. **Design Validation**: Ensures wreath matches intended environment
4. **Story Continuity**: Visual proof that character exists

---

### STEP 4: Wreath Design (From Actual Floral Inventory)

**Purpose**: Design a wreath using real available florals that matches both character and space

**This is Where Magic Happens:**

The system bridges emotional storytelling with physical manufacturing constraints.

**Input Sources:**
1. Character story (emotional preferences, personality)
2. Living space palette (colors, textures, mood)
3. Actual floral inventory (uploaded images from Step 1)

**AI Selection Algorithm:**

```javascript
function selectFlorals(character, space, inventory) {
  const selectedFlorals = [];
  
  // Priority 1: Match character's stated floral preferences
  character.floralPreferences.forEach(preference => {
    const match = inventory.find(item => 
      item.name.toLowerCase().includes(preference.toLowerCase())
    );
    if (match) {
      selectedFlorals.push({
        ...match,
        reasoning: `Eleanor's stated preference: "${preference}"`,
        priority: 'high'
      });
    }
  });
  
  // Priority 2: Match space color palette
  space.layers.color.prompt.split(',').forEach(color => {
    const colorMatches = inventory.filter(item =>
      item.colorPalette.includes(color.trim())
    );
    colorMatches.forEach(match => {
      if (!selectedFlorals.find(f => f.id === match.id)) {
        selectedFlorals.push({
          ...match,
          reasoning: `Matches space palette: ${color}`,
          priority: 'medium'
        });
      }
    });
  });
  
  // Priority 3: Textural contrast for visual interest
  const textures = ['fuzzy', 'smooth', 'papery', 'feathery', 'layered'];
  textures.forEach(texture => {
    const match = inventory.find(item =>
      item.texture === texture && 
      !selectedFlorals.find(f => f.id === item.id)
    );
    if (match && selectedFlorals.length < 7) {
      selectedFlorals.push({
        ...match,
        reasoning: `Adds textural variety: ${texture}`,
        priority: 'low'
      });
    }
  });
  
  return selectedFlorals;
}
```

**Wreath Specification Generation:**

```javascript
{
  name: "Winter's Patience", // AI-generated from emotion
  specifications: {
    size: "20 inches diameter",
    depth: "5-6 inches",
    base: "Whitewashed grapevine wreath",
    style: "Minimalist, asymmetric, negative space intentional"
  },
  
  selectedFlorals: [
    {
      id: "inv_001",
      name: "Pussy Willow Stems",
      quantity: 5, // Calculated based on wreath size
      size: "8-10 inches",
      position: "Emerging from 45°, 140°, 225°, 310°", // Polar coordinates
      reasoning: "Eleanor's favorite - early awakening",
      inventoryImage: "actual-uploaded-photo.jpg"
    },
    // ... more florals
  ],
  
  assemblyLayers: [
    // Generated in Step 5
  ],
  
  emotionalStory: "This wreath captures Eleanor's philosophy...",
  
  manufacturingNotes: {
    totalTime: "50 minutes",
    wireGauge: "24-gauge for structure, 28-gauge for delicate stems",
    adhesive: "Minimal hot glue",
    finishing: "Light water misting",
    packaging: "24×24×8 inch box, kraft paper"
  },
  
  pricing: {
    materialCost: "$42-58",
    laborCost: "$20-30",
    suggestedRetail: "$185-225",
    digitalBlueprintOnly: "$37"
  }
}
```

**Positioning Algorithm (Polar Coordinates):**

The system uses golden ratio and asymmetric balance:

```javascript
function calculateFloralPositions(florals, wreathSize) {
  const goldenRatio = 1.618;
  const totalDegrees = 360;
  
  // Primary focal clusters at golden ratio divisions
  const focalPoints = [
    50,   // Upper right (360 / goldenRatio / 1.5)
    135,  // Right side  (golden ratio middle)
    220   // Lower left  (inverted golden section)
  ];
  
  // Assign highest-priority florals to focal points
  const highPriority = florals.filter(f => f.priority === 'high');
  const positions = {};
  
  highPriority.forEach((floral, index) => {
    positions[floral.id] = {
      angle: focalPoints[index % focalPoints.length],
      radiusSpread: [0, 30], // 0° to 30° spread from center point
      depth: [2, 4] // 2-4 inches projection
    };
  });
  
  // Fill remaining florals in supporting positions
  // ... more positioning logic
  
  return positions;
}
```

**Why This Step is Critical:**

1. **Manufacturing Feasibility**: Uses only available inventory
2. **Emotional Continuity**: Florals chosen for symbolic meaning, not just aesthetics
3. **Cost Transparency**: Exact materials list with sourcing
4. **Storytelling Integration**: Each floral has a "why" connected to character

---

### STEP 5: Assembly Guide (Layer-by-Layer Instructions)

**Purpose**: Create step-by-step assembly instructions with visual references

**Generated Assembly Layers:**

The system breaks wreath construction into discrete, photographable steps:

```javascript
assemblyLayers: [
  {
    layerNumber: 1,
    name: "Base Foundation",
    description: "Attach eucalyptus base layer using 24-gauge wire",
    floralsUsed: ["Silver Dollar Eucalyptus"],
    timeEstimate: "15 minutes",
    
    // AI-generated image prompt for this specific step:
    imagePrompt: "Close-up product photography of whitewashed grapevine 
    wreath with silver dollar eucalyptus stems being wired to base, 
    showing 60% coverage with intentional gaps, hands visible in frame 
    demonstrating technique, some stems angled 15-30° off perpendicular 
    for depth, natural lighting, overhead view, instructional clarity, 
    8K resolution, shallow depth of field on wreath base"
  },
  
  {
    layerNumber: 2,
    name: "Primary Focal Cluster (Upper Right)",
    description: "Build first focal point at 50° position",
    floralsUsed: ["White Ranunculus", "Pussy Willow Stems"],
    timeEstimate: "10 minutes",
    
    imagePrompt: "Detail macro photography of 2 white ranunculus flowers 
    (4 inch diameter) being positioned on wreath upper right cluster at 
    50° angle, pussy willow stems emerging behind them creating depth, 
    hands visible placing flowers, layered 2-4 inches deep creating 
    sculptural dimension, close-up showing floral wire attachment method, 
    soft natural light, photorealistic textures, tutorial aesthetic"
  },
  
  // ... layers 3, 4, 5
]
```

**Image Prompt Generation Strategy:**

Each assembly step gets a custom-tailored image generation prompt:

```javascript
function generateAssemblyImagePrompt(layer, wreath) {
  const prompts = {
    base: `Close-up of ${wreath.base} with ${layer.floralsUsed.join(', ')} 
           being attached, showing technique, hands visible, instructional`,
    
    cluster: `Detail shot of ${layer.floralsUsed.join(' and ')} positioned 
              at ${layer.position}, showing depth and layering, assembly in progress`,
    
    accent: `Macro photography of ${layer.floralsUsed[0]} being tucked into 
             existing arrangement, demonstrating placement precision`,
    
    final: `Full wreath view showing completed ${wreath.name}, all ${layer.floralsUsed.length} 
            floral types visible, demonstrating final composition`
  };
  
  // Select appropriate prompt type based on layer
  const type = determineLayerType(layer);
  
  return `${prompts[type]}. Professional product photography, 8K resolution, 
          clear instructional quality, natural lighting, photorealistic textures, 
          shallow depth of field, tutorial aesthetic for DIY guide.`;
}
```

**Why Layer-by-Layer Images Matter:**

1. **DIY Customers**: Can follow along with visual guide
2. **Quality Assurance**: Manufacturers can verify each step
3. **Marketing Content**: Beautiful progress shots for social media
4. **Value Perception**: Shows craftsmanship and complexity

**Progressive Assembly Visualization:**

The system ensures each layer builds logically:

```
Layer 1 (Foundation)
   ↓ Shows: Base + greenery framework
   
Layer 2 (First Focal Cluster)
   ↓ Shows: Foundation + first flower cluster
   
Layer 3 (Second Focal Cluster)  
   ↓ Shows: Foundation + both clusters
   
Layer 4 (Accent Elements)
   ↓ Shows: Nearly complete wreath + accents
   
Layer 5 (Final Polish)
   ↓ Shows: Finished wreath with all adjustments
```

Each image prompt builds on the previous, showing cumulative progress.

---

### STEP 6: Product Package (Complete Sellable Bundle)

**Purpose**: Assemble all components into ready-to-sell formats

**Package Contents:**

```javascript
productPackage: {
  name: '"Winter\'s Patience" Complete Collection',
  
  includes: [
    "Character Story: Who this wreath is for",
    "Living Space Scene (with layered prompts)",
    "Wreath Design Blueprint (polar coordinates, specifications)",
    "Complete Floral Inventory List (quantities and positioning)",
    "Layer-by-Layer Assembly Guide (5 steps with image prompts)",
    "Emotional Story & Meaning",
    "Manufacturing Notes & Cost Breakdown",
    "High-Resolution Scene Images",
    "Commercial License (if applicable)"
  ],
  
  formats: [
    "PDF Blueprint (print-ready)",
    "JSON Data (for developers/automation)",
    "Image Assets (scene + assembly layers)",
    "Text Files (story, prompts, instructions)"
  ],
  
  pricing: {
    digital: "$37 (blueprint + story + assembly guide)",
    physicalKit: "$145 (includes all florals from inventory)",
    finished: "$215 (hand-assembled wreath + story card)",
    commercial: "$97 (digital + commercial use license)"
  }
}
```

**Export Formats:**

1. **PDF Package** (for Etsy digital downloads)
   - Page 1: Cover with wreath name and character name
   - Page 2-3: Character story with emotional narrative
   - Page 4-5: Living space scene images and description
   - Page 6-8: Wreath blueprint with specifications
   - Page 9-10: Floral inventory list with photos
   - Page 11-15: Assembly guide (one page per layer)
   - Page 16: Manufacturing notes and pricing
   - Page 17: Commercial license terms (if applicable)

2. **JSON Package** (for automation/developers)
   ```json
   {
     "metadata": {
       "packageName": "Winter's Patience Complete Collection",
       "createdAt": "2025-01-03T10:30:00Z",
       "version": "1.0",
       "empathyEngineVersion": "1.0"
     },
     "characterStory": { ... },
     "livingSpace": { ... },
     "wreathDesign": { ... },
     "assemblyGuide": { ... },
     "productPackage": { ... }
   }
   ```

3. **Image Asset Bundle** (ZIP file)
   - `/scenes/living-space-full.jpg` (4K)
   - `/scenes/living-space-detail.jpg` (4K)
   - `/assembly/layer-01-foundation.jpg` (4K)
   - `/assembly/layer-02-cluster-1.jpg` (4K)
   - `/assembly/layer-03-cluster-2.jpg` (4K)
   - `/assembly/layer-04-accents.jpg` (4K)
   - `/assembly/layer-05-final.jpg` (4K)
   - `/inventory/floral-01-pussy-willow.jpg`
   - `/inventory/floral-02-ranunculus.jpg`
   - ... (one per floral)

4. **Story Text Files**
   - `character-story.txt` (narrative)
   - `emotional-intent.txt` (original input)
   - `wreath-meaning.txt` (symbolic story)
   - `assembly-instructions.txt` (step-by-step)

---

## Business Models Enabled

### Model 1: Digital Blueprint Marketplace (Passive Income)

**Product**: PDF + JSON blueprint packages
**Price**: $27-47 per blueprint
**Platform**: Etsy, Gumroad, own website
**Customer**: DIY crafters, small businesses, design enthusiasts

**Value Proposition:**
"Create this $215 luxury wreath yourself for under $70 in materials. Our AI-powered blueprint removes all guesswork—every flower placement is precisely mapped with emotional storytelling."

**Scalability**: Infinite (generate 100 unique blueprints, sell each unlimited times)

**Revenue Example:**
- 50 unique blueprint designs
- Average price: $37
- 10 sales per blueprint per month
- Revenue: 50 × $37 × 10 = $18,500/month

### Model 2: Physical Product + Story Card

**Product**: Hand-assembled wreath + character story card
**Price**: $185-295 per wreath
**Platform**: Etsy, own website, local boutiques
**Customer**: Gift buyers, home decorators, collectors

**Value Proposition:**
"Each wreath is designed for a specific person. When you purchase 'Winter's Patience,' you're buying Eleanor's story—a meditation on hope and renewal."

**Differentiation**: Every wreath has a name, a character, a narrative. Not just decoration—emotional art.

**Revenue Example:**
- 2 wreaths per week
- Average price: $225
- Revenue: 2 × $225 × 4 = $1,800/month per maker
- Commission 3 makers: $5,400/month

### Model 3: Commercial License for Makers

**Product**: Blueprint + commercial usage rights
**Price**: $97-147 per blueprint
**Platform**: Direct B2B sales, Shopify
**Customer**: Wreath makers, florists, event planners, Etsy sellers

**Value Proposition:**
"License our emotionally-designed blueprints to sell your own versions. We provide the design, story, and manufacturing specs—you provide the craftsmanship."

**Scalability**: Create blueprint once, license to dozens of makers

**Revenue Example:**
- 20 blueprints in catalog
- 15 active licensees per blueprint
- License fee: $97/year
- Revenue: 20 × 15 × $97 = $29,100/year recurring

### Model 4: Custom Emotional Commissions

**Product**: Fully custom pipeline run for client's specific emotion/occasion
**Price**: $297-497 for complete custom package
**Platform**: Direct sales, wedding planners, corporate gifts
**Customer**: Weddings, memorials, corporate events, special occasions

**Process:**
1. Client consultation (1 hour): Capture emotional intent
2. Run full Empathy Engine pipeline
3. Deliver: Character story + scene + wreath blueprint + assembly guide
4. Optional: Manufacture physical wreath for additional fee

**Value Proposition:**
"Your emotion, our system. We transform your feelings about your wedding/memorial/event into a one-of-a-kind wreath design with a story that means something."

**Revenue Example:**
- 4 custom commissions per month
- Average price: $397
- Revenue: 4 × $397 = $1,588/month

### Model 5: Subscription: "Wreath of the Month"

**Product**: Monthly blueprint + story delivered digitally
**Price**: $27-37/month
**Platform**: Patreon, Substack, own subscription site
**Customer**: DIY enthusiasts, seasonal decorators, wreath makers

**Value Proposition:**
"Every month, receive a new emotionally-designed wreath blueprint based on the current season, complete with character story, assembly guide, and floral recommendations."

**Scalability**: Create once, deliver to hundreds

**Revenue Example:**
- 200 subscribers
- Price: $37/month
- Revenue: 200 × $37 = $7,400/month recurring

---

## Integration with Existing Systems

### With Universal Floral Inventory Profiles

The Empathy Engine uses your existing floral cataloging system:

```javascript
// Floral inventory from your computer vision pipeline
const floralInventory = [
  {
    id: "inv_pussy_willow_001",
    universalProfile: {
      physicalSpecs: {
        stemLength: "8-10 inches",
        bloomSize: "0.5-0.75 inch catkins",
        color: "Silver-gray",
        texture: "Fuzzy, soft"
      },
      emotionalResonance: {
        keywords: ["Hopeful", "Early spring", "Gentle", "Transitional"],
        associations: ["Awakening", "Patience", "First signs"],
        colorPsychology: "Cool neutrals evoke calm anticipation"
      },
      manufacturingDetails: {
        wireGauge: "28-gauge (delicate)",
        attachmentMethod: "Stem wire wrap",
        positioning: "Projects outward, natural angles"
      }
    }
  }
];

// Empathy Engine queries this when selecting florals:
const selectedFlorals = floralInventory.filter(floral =>
  floral.universalProfile.emotionalResonance.keywords.some(keyword =>
    emotionalInput.includes(keyword.toLowerCase())
  )
);
```

### With Wreath Weaver Platform

The blueprint output from Empathy Engine can feed directly into manufacturing:

```javascript
// Empathy Engine outputs wreath specification
const wreathSpec = {
  name: "Winter's Patience",
  selectedFlorals: [...],
  polarCoordinates: {
    clusters: [
      { angle: 50, florals: ["ranunculus", "pussy_willow"] },
      { angle: 135, florals: ["hellebore", "eucalyptus"] },
      { angle: 220, florals: ["hydrangea"] }
    ]
  }
};

// Wreath Weaver manufacturing agent uses this:
async function manufacturWreath(spec) {
  // Step 1: Retrieve florals from inventory
  const florals = await retrieveFromInventory(spec.selectedFlorals);
  
  // Step 2: Position according to polar coordinates
  const positioned = await positionFlorals(florals, spec.polarCoordinates);
  
  // Step 3: Generate assembly instructions
  const instructions = await generateInstructions(positioned);
  
  return { florals, instructions, specification: spec };
}
```

### With EmpireOS Interior Design System

The living space scene can be expanded into full room designs:

```javascript
// Use Empathy Engine character as foundation for full interior
const interiorDesign = {
  character: empathyEngine.characterStory,
  
  // Expand living space into multiple rooms
  rooms: {
    studio: empathyEngine.livingSpace,
    bedroom: generateRoomFromCharacter(character, 'bedroom'),
    kitchen: generateRoomFromCharacter(character, 'kitchen')
  },
  
  // Use same layered prompt system for each room
  furnitureCuration: selectFurnitureBasedOn(character.aesthetic),
  
  // Wreaths placed throughout
  wreathPlacements: [
    { room: 'studio', position: 'main door', wreath: 'Winter\'s Patience' },
    { room: 'bedroom', position: 'above bed', wreath: generateSeasonalVariant() }
  ]
};
```

---

## Technical Implementation Details

### AI Model Requirements

**For Character Story Generation:**
- Model: Claude Sonnet 4 or GPT-4
- Token budget: ~1500 tokens for character generation
- Prompt structure:
  ```
  Given this emotional input: "{user input}"
  And these floral preferences: {extracted from inventory}
  
  Generate a character who would feel this emotion and prefer these florals.
  Include: name, age, occupation, location, personality, daily life, 
  aesthetic preferences, emotional state, narrative story (3 paragraphs),
  emotional color palette, floral preferences, space requirements.
  
  Output as JSON.
  ```

**For Living Space Scene Layers:**
- Model: Claude Sonnet 4 (for nuanced layer generation)
- Token budget: ~2000 tokens for all 6 layers
- Process:
  1. Extract character.spaceRequirements
  2. Map to 6 layer categories
  3. Generate weighted prompts
  4. Auto-assign weights based on character priorities

**For Wreath Design Selection:**
- Model: Claude Sonnet 4 (for reasoning about floral symbolism)
- Token budget: ~2500 tokens for selection + reasoning
- Process:
  1. Load floral inventory profiles
  2. Score each floral against character (0-100)
  3. Select top 5-7 florals
  4. Generate positioning using golden ratio
  5. Write emotional reasoning for each selection

**For Assembly Guide Image Prompts:**
- Model: Claude Sonnet 4
- Token budget: ~300 tokens per layer × 5 layers = 1500 tokens
- Process:
  1. For each assembly layer
  2. Describe what's being added
  3. Specify camera angle (overhead, detail, macro)
  4. Include instructional keywords
  5. Add technical specs (8K, lighting, etc.)

**Total Token Budget per Complete Pipeline Run:**
- ~7500 tokens (well within single API call limits)

### Image Generation Requirements

**For Living Space Scene:**
- Platform: Midjourney v6 or DALL-E 3
- Aspect ratio: 4:3 (interior standard)
- Quality: 8K preferred, 4K minimum
- Cost: ~$0.04-0.08 per image (Midjourney)

**For Assembly Layer Steps:**
- Platform: Midjourney v6 (better with instructional photography)
- Aspect ratio: 1:1 or 4:3
- Quality: 4K minimum (close-up detail)
- Quantity: 5 images per wreath
- Cost: ~$0.20-0.40 per wreath (all 5 images)

**For Floral Inventory (if generating, not uploading):**
- Platform: Stable Diffusion or DALL-E 3
- Style: Product photography, white background
- Quantity: One per floral type in catalog
- Cost: Can be pre-generated and reused

**Total Image Generation Cost per Pipeline Run:**
- Living space: 1-2 images × $0.04 = $0.04-0.08
- Assembly guide: 5 images × $0.04 = $0.20
- Total: ~$0.24-0.28 per complete package

### Storage Requirements

**Per Pipeline Output:**
- JSON data: ~50KB
- PDF blueprint: ~5-10MB (with images)
- Image assets (7-10 images): ~30-50MB total
- Text files: ~20KB

**For 100 Unique Products:**
- JSON database: 5MB
- PDF library: 500MB-1GB
- Image library: 3-5GB
- Total: ~4-6GB

(Very manageable with modern cloud storage)

### Processing Time

**AI Generation (sequential):**
- Character story: ~10 seconds
- Living space layers: ~15 seconds
- Wreath design: ~20 seconds
- Assembly guide: ~15 seconds
- Total AI time: ~60 seconds

**Image Generation (parallel if using multiple platforms):**
- Living space scene: ~30-60 seconds
- Assembly layers (5): ~2-5 minutes (if sequential)
- Total image time: ~3-6 minutes

**Export & Packaging:**
- PDF generation: ~10 seconds
- JSON export: instant
- Image optimization: ~30 seconds
- Total export: ~40 seconds

**Complete Pipeline: ~5-8 minutes end-to-end**

(Fast enough for interactive use; can be queued for batch processing)

---

## Quality Assurance Checklist

Before releasing a product package, verify:

**Character Story:**
- [ ] Name feels authentic to emotional tone
- [ ] Occupation aligns with aesthetic preferences
- [ ] Narrative is cohesive and emotionally resonant (3+ paragraphs)
- [ ] Floral preferences make symbolic sense
- [ ] Space requirements are specific and actionable

**Living Space:**
- [ ] All 6 layers are populated with specific details
- [ ] Lighting matches emotional tone (warm vs cool, bright vs dim)
- [ ] Color palette has percentages and specific names
- [ ] Scene can actually be generated (not impossible/contradictory)
- [ ] Mood keywords match character personality

**Wreath Design:**
- [ ] All selected florals exist in actual inventory
- [ ] Quantities are realistic for wreath size
- [ ] Polar coordinates don't create overlapping clusters
- [ ] Emotional reasoning for each floral is compelling
- [ ] Manufacturing time estimate is accurate

**Assembly Guide:**
- [ ] Layer progression is logical (foundation → details)
- [ ] Image prompts are specific enough to be generated
- [ ] Each layer has time estimate
- [ ] Florals used in each layer match overall design
- [ ] Final layer shows complete wreath

**Product Package:**
- [ ] All pricing tiers are calculated correctly
- [ ] Export formats are complete (PDF + JSON + images)
- [ ] Story flows from emotion → character → space → wreath
- [ ] Manufacturing notes include all necessary details
- [ ] Commercial license terms are clear (if applicable)

---

## Troubleshooting Common Issues

### Issue: Character feels generic or disconnected from emotion

**Cause**: Emotional input too vague or AI defaulting to common archetypes

**Solution**:
1. Refine emotional input with more sensory details
2. Add constraints: "Character should NOT be a teacher/artist/writer" (avoid clichés)
3. Specify age range or life circumstance
4. Regenerate 2-3 times and pick best

### Issue: Living space scene can't be generated (contradictory prompts)

**Cause**: Layers have conflicting requirements (e.g., "minimalist" + "maximalist clutter")

**Solution**:
1. Check layer weights - highest weight should dominate
2. Edit conflicting layers manually
3. Disable one of the conflicting layers temporarily
4. Use negative prompts to exclude unwanted elements

### Issue: Wreath design uses florals not in inventory

**Cause**: AI hallucinating florals or misunderstanding inventory

**Solution**:
1. Ensure floral inventory has clear, standard names
2. Add constraint: "ONLY use these exact florals: [list]"
3. Manual selection override in UI
4. Improve floral inventory image quality/labeling

### Issue: Assembly guide images don't match description

**Cause**: Image prompt not specific enough or AI misinterpreting

**Solution**:
1. Add more camera angle specificity ("overhead", "45-degree", "macro close-up")
2. Include color/material details ("white ceramic vase", "silver eucalyptus")
3. Add "tutorial photography" or "instructional guide" to style
4. Generate 2-3 variations and select best

### Issue: Emotional story feels forced or disconnected

**Cause**: Not enough context about why florals were chosen

**Solution**:
1. Strengthen floral reasoning (why this flower for this character?)
2. Add sensory details (texture, scent, seasonal timing)
3. Connect florals to character's biography/location
4. Have AI explain symbolism explicitly

---

## Future Enhancements

### Phase 2: Multi-Wreath Collections

Generate coordinated sets:
- Seasonal series (Spring Awakening, Summer Abundance, Autumn Reflection, Winter Rest)
- Room-specific (Kitchen, Bedroom, Entryway)
- Life event (Wedding, Memorial, New Baby, New Home)

**Technical**: Run pipeline with variations on base character, maintaining emotional continuity

### Phase 3: Interactive Character Builder

Allow users to customize generated character:
- Adjust age, occupation, location
- See how changes affect wreath design in real-time
- Save multiple character variations

**Technical**: React UI with live preview, debounced AI regeneration

### Phase 4: Floral Inventory ML Auto-Tagging

Upload floral photo → automatic complete profile:
- Computer vision identifies flower type
- Color extraction for palette
- AI generates emotional keywords
- Suggests positioning and usage

**Technical**: Custom vision model + Claude for emotional analysis

### Phase 5: Customer Emotion Input via Quiz

Guided questionnaire instead of free text:
- "How does this image make you feel?" (show seasonal photos)
- "Which color palette resonates?" (show swatches)
- "What's your ideal morning?" (lifestyle questions)

**Technical**: Weighted scoring algorithm → emotional profile → feed to pipeline

### Phase 6: Augmented Reality Wreath Preview

See wreath on your actual door via phone camera:
- Upload door photo
- System places wreath rendering
- Adjust size, position
- See in different lighting conditions

**Technical**: AR.js or WebXR for browser-based AR

### Phase 7: Community Sharing & Remix

Users share their blueprints:
- Browse community character library
- Remix existing characters with your florals
- Vote on best emotional stories
- Earn commissions on popular blueprints

**Technical**: Public/private blueprint database, remix tracking, revenue sharing

---

## Monetization Calculator

### Monthly Revenue Potential

**Digital Blueprints (Passive)**
```
50 designs × $37 average × 10 sales/month = $18,500/month
```

**Physical Wreaths**
```
2 wreaths/week × $225 average × 4 weeks = $1,800/month (solo)
3 commissioned makers × $1,800 = $5,400/month (team)
```

**Commercial Licenses**
```
20 blueprints × 15 licensees × $97/year ÷ 12 = $2,425/month
```

**Custom Commissions**
```
4 customs/month × $397 = $1,588/month
```

**Subscription**
```
200 subscribers × $37/month = $7,400/month
```

**Total Potential: $35,713/month** (with all models active)

**More Conservative Estimate:**
- Digital blueprints: $3,700/month (10 designs, 10 sales each)
- Physical wreaths: $1,800/month (solo maker)
- Commercial licenses: $500/month (early stage)
- Total: $6,000/month (sustainable solo operation)

---

## Conclusion

The Empathy Engine transforms abstract emotions into concrete, sellable products through a systematic pipeline that maintains emotional authenticity while meeting manufacturing constraints.

**Key Innovation:**
Most product design starts with aesthetics or trends. This system starts with feeling—and that feeling stays coherent through every step, from character to space to wreath to assembly to sale.

**Competitive Advantage:**
Anyone can sell a wreath. Few can sell a wreath that makes people cry because it captures exactly how they feel about their mother's memory, or their hope for a new beginning, or their quiet acceptance of winter's lessons.

**Scalability:**
The pipeline can generate infinite unique products. Each one emotionally distinct, each one technically manufacturable, each one ready to sell.

That's the power of turning empathy into engineering.

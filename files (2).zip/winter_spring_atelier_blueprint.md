# Winter's End Botanist Atelier - Complete Scene Blueprint
## "Between Dormancy and Awakening"

## Master Image Generation Prompt

```
High-resolution interior photography of a contemplative botanist's winter studio during late afternoon, captured in soft overcast light. Center composition features a long weathered wooden workbench (7 feet length, reclaimed pine with gray-white paint distressing, showing bare wood underneath) displaying a minimalist winter botanical arrangement. Centerpiece consists of bare branches, pussy willows with silvery catkins, early hellebore blooms, white ranunculus, and dried hydrangea heads arranged in a collection of frosted glass vessels and white ceramic containers (heights 8-16 inches). Arrangement emphasizes negative space and sculptural winter forms - sparse, elegant, Japanese wabi-sabi aesthetic.

Overhead, suspended from exposed whitewashed ceiling beams by thin wire, hangs a delicate mobile-style installation of bare birch branches (12-15 feet total span), silver dollar eucalyptus, dried lunaria (honesty plant with translucent seed pods), and paper-white narcissus stems, creating ethereal floating botanical sculpture with natural movement. Installation is asymmetric and airy, not dense - emphasizes empty space and light filtering through.

Room features transitional winter-spring character: soft pearl-gray painted walls (matte finish, slightly aged), large divided-light windows (Crittall-style steel frames in matte black) showing view of winter garden outside with patches of melting snow, bare tree branches, and emerging snowdrops. Late afternoon diffused light (3-4pm overcast day) creates soft, even illumination without harsh shadows - cool blue-gray ambient light with subtle warmth.

Work surface styled with curated restraint: small clusters of forcing bulbs in terracotta pots (paperwhites, hyacinths showing early green shoots), vintage botanical specimen jars with preserved moss and lichen, stack of pressed plant samples between glass plates, worn leather plant journal open showing watercolor studies of winter buds, collection of smooth river stones, white porcelain mortar and pestle, small pruning shears, spool of natural linen thread.

In corner: low-slung upholstered bench (linen fabric in oatmeal/natural, minimal tufting) with collection of earth-toned wool and linen cushions in cream, soft gray, and muted sage. Draped over bench is a chunky cable-knit throw blanket in undyed natural wool. Adjacent small side table (simple turned legs, painted in soft blue-gray) holds stack of vintage botanical reference books, white ceramic mug with residual tea stain, small brass candle holder with half-burned ivory taper candle.

Architectural details: Tall Crittall-style windows (10 feet high, black steel frames with minimal muntins creating large glass panes) along one wall, showing winter garden view - bare deciduous trees, patches of snow, emerging hellebores and snowdrops in garden beds, overcast sky with soft light. Opposite wall features floor-to-ceiling built-in shelving (painted same pearl-gray as walls) displaying organized collection of glass specimen jars, botanical books, white ceramic vessels, woven baskets, and small potted succulents. Wide plank oak flooring (light gray-washed finish, matte, showing natural wood grain). Ceiling has exposed beams painted in soft white-gray.

Color palette: Dominated by whites, soft grays, cool blue-grays, natural wood tones, with minimal color accents - pale pink hellebores, soft green emerging foliage, ivory whites, warm natural wool and linen textiles. Lighting: Soft, diffused overcast daylight creating even illumination, cool color temperature (5500-6000K) with subtle warmth from natural materials. No harsh shadows - gentle graduated tones. Misty, ethereal quality with soft focus on distant elements.

Atmosphere: Quiet contemplation, minimalist restraint, transitional season captured, botanical study during dormancy, Scandinavian-Japanese fusion aesthetic, serene and meditative, intellectual pursuit of plant dormancy and awakening, restrained elegance. Professional interior photography, 8K resolution, shot with 50mm lens, f/4 aperture for extended depth of field showing both foreground and background elements in soft focus, photorealistic textures showing linen weave, wood grain, glass transparency, delicate botanical details. Editorial magazine quality for Cereal magazine, Kinfolk, or Gardenista aesthetic - sophisticated, minimal, contemplative.
```

---

## Scene Architecture & Composition

### Spatial Layout (Bird's Eye View)

```
           WINDOWS (diffused overcast light →)
    ═════════════════════════════════════════════
    ║                                           ║
    ║  Hanging branch mobile suspended          ║
    ║  from ceiling (ethereal, sparse)          ║
    ║              ↓                            ║
    ║                                           ║
    ║      ┌─────────────────────┐             ║
    ║      │   WORKBENCH         │             ║
    ║  [Jar│  [Minimal winter    │  [Forcing   ║
    ║  coll]│   arrangement]      │   bulbs]    ║
BUILT║      │                     │             ║BUILT
-IN  ║      └─────────────────────┘             ║-IN
SHELV║                                          ║SHELV
-ING ║                          ┌─────────┐    ║-ING
    ║  [Plant specimens]       │ BENCH   │    ║
    ║   on shelves             │+cushions│    ║
    ║                          └─────────┘    ║
    ═════════════════════════════════════════════
          View: Winter garden, snow patches
```

### Lighting Diagram

**Primary Light Source**: Large Crittall windows (camera right, 2 o'clock position)
- Time: 3-4pm overcast winter afternoon
- Quality: Soft, diffused, even - no directional beams
- Color temperature: 5500-6000K (cool daylight, slight blue cast)
- Intensity: Medium-low, contemplative

**Light Behavior**:
- No harsh shadows - only gentle graduated tones
- Soft ambient fill from overcast sky
- Cool light wraps around objects evenly
- Slight warmth reflected from natural wood/linen materials
- Translucent elements (lunaria seed pods, glass vessels) catch light subtly
- Matte surfaces absorb light softly (no harsh specular highlights)
- Window view creates depth - lighter background, slightly darker interior

**Atmospheric Quality**:
- Misty, soft-focus feeling
- Gentle vignette naturally created by window light fall-off
- Ethereal, meditative mood
- Colors slightly desaturated (winter palette)
- No dust motes or dramatic light beams - just even, quiet illumination

---

## Detailed Element Specifications

### Central Workbench

**Dimensions**: 84" L × 30" W × 32" H
**Material**: Reclaimed pine with distressed paint finish
**Finish**: 
- Base color: Warm white/cream (70% coverage)
- Distressing: Gray-white dry brush over top
- Bare wood showing through at edges, corners, high-traffic areas
- Waxed finish (matte, not glossy)
**Legs**: Simple straight legs with stretcher support
**Surface**: Shows honest wear - watermarks, tool impressions, gentle aging

### Winter Botanical Centerpiece

**Philosophy**: Sparse, sculptural, emphasizing negative space and winter's stark beauty

**Container Collection** (5 vessels, asymmetric grouping):

1. **Tall frosted glass cylinder** (16" H × 4" dia)
   - Contents: 3 bare branches (pussy willow with emerging silver catkins)
   - Placement: Back left, tallest element

2. **White ceramic bottle vase** (12" H, narrow neck)
   - Contents: 5 stems early hellebores (pale pink-white, nodding blooms)
   - Placement: Front center-right

3. **Clear glass apothecary jar** (10" H, wide mouth)
   - Contents: 3 white ranunculus (4" blooms, lush petals), 2 dried hydrangea heads (faded taupe)
   - Placement: Mid-left

4. **Small white porcelain bowl** (4" H × 6" dia)
   - Contents: Cluster of pussy willow stems (short, 6-8" catkins displayed horizontally)
   - Placement: Front left

5. **Frosted glass bud vase** (8" H, narrow)
   - Contents: Single bare branch with lichen, 1 paper-white narcissus stem
   - Placement: Back right accent

**Arrangement Principles**:
- Intentional gaps between vessels (6-12" spacing)
- Asymmetric triangle composition with visual weight left-of-center
- Majority of surface remains bare/empty
- Height variation creates rhythm: tall (16"), medium-tall (12"), medium (10"), low (8"), very low (4")
- Color: 80% whites/grays, 15% pale pink, 5% soft green accents
- Texture emphasis: bare branches, fuzzy catkins, delicate petals, papery dried hydrangea

### Suspended Branch Installation

**Total Span**: 14 feet across two ceiling beams
**Suspension Method**: Thin silver wire (barely visible) at 6 attachment points
**Height**: Hangs 6-7 feet above floor, creating layer between ceiling and table

**Botanical Components**:
- 40% Bare birch branches (white bark, delicate twigs, natural curves)
- 25% Silver dollar eucalyptus (silvery-blue, creates soft mass)
- 20% Dried lunaria/honesty plant (translucent oval seed pods, catch light magically)
- 10% Paper-white narcissus stems (white blooms, delicate)
- 5% Thin trailing willow whips (add movement)

**Construction Technique**:
- Mobile-like construction - pieces balanced asymmetrically
- Airy, not dense - 60% of installation is empty space
- Some elements hang vertically, others angle
- Creates subtle movement with air currents
- Casts delicate shadows on walls and ceiling
- Translucent lunaria pods filter light when backlit by windows

**Spatial Distribution**:
- Concentration point left of center (above workbench edge)
- Elements disperse toward right, becoming sparser
- Lowest hanging point: 5.5 feet (over left side of bench)
- Highest elements: 7 feet (right side, near windows)

### Upholstered Bench

**Style**: Scandinavian minimal, mid-century inspired
**Dimensions**: 60" W × 24" D × 18" H (low seating)
**Frame**: Light oak wood, minimal tapering legs
**Upholstery**: Natural oatmeal linen (matte texture, slightly nubby)
**Details**:
- Simple rectangular form, no arms
- Subtle tufting (4 buttons, barely visible)
- Removable seat cushion
- Shows slight wear/softness from use

**Styling**:
- 3 cushions arranged casually:
  - 20" square pillow in soft gray wool
  - 16"×24" lumbar pillow in cream linen with texture
  - 18" round pillow in muted sage green linen
- Chunky cable-knit throw blanket (natural undyed wool, cream/ivory)
  - Draped over back and left arm area
  - Shows texture: braided cable patterns, chunky yarn (1" diameter)
  - One corner trailing to floor

**Side Table**:
- Small round pedestal table (18" diameter)
- Painted in soft blue-gray (Swedish paint finish)
- Turned pedestal leg with tripod base
- Contents:
  - Stack of 4 botanical books (varying sizes, worn cloth covers)
  - Simple white ceramic mug (empty, slight tea stain inside visible)
  - Small brass candle holder (3" H) with ivory taper candle (burned down halfway)
  - Folded linen napkin underneath mug

### Character Elements - Work Surface

**Grouped in three zones across bench:**

**Left Zone** (specimen study):
- 3 vintage glass specimen jars (various heights 6-10")
  - One containing preserved moss (bright green against glass)
  - One with dried lichen specimens
  - One with pressed fern fronds
- Antique brass hand lens (magnifying glass, 3" diameter)
- Small wooden box with botanical specimen labels (handwritten)

**Center Zone** (active work):
- Open leather plant journal (8×10", worn tan leather cover)
  - Showing watercolor studies of winter buds and catkins
  - Visible brush strokes in muted greens and browns
  - Handwritten notes in margins
- Set of pressed plant samples between glass plates (3 stacked sets)
- White porcelain mortar and pestle (small, 4" diameter, showing herb residue)
- Small ceramic bowl with collected catkins and seed pods

**Right Zone** (propagation):
- 4 terracotta pots (4-6" diameter) with forcing bulbs
  - 2 paperwhites showing green shoots (3-4" tall emerging)
  - 1 hyacinth with purple-pink bud just visible
  - 1 amaryllis with thick green stalk beginning
- Collection of 5-7 smooth river stones (various sizes, gray and white)
- Small copper watering can (vintage, dented, patina)
- Pruning shears (small Okatsune-style, lying open)
- Spool of natural linen thread

### Architectural Details

**Crittall-Style Windows**:
- **Type**: Steel casement with minimal muntins
- **Configuration**: 2 units side-by-side, each 60" W × 120" H
- **Frame**: Matte black steel (modern Crittall reproduction)
- **Pane Layout**: Large glass sections with thin dividers (6 panes per unit)
- **Glass**: Clear, slight ripple (modern float glass with subtle texture)
- **Hardware**: Simple black steel handles
- **View Through Windows**:
  - Winter garden in transitional state
  - Bare deciduous tree branches (detailed silhouettes)
  - Patches of melting snow on ground (80% coverage)
  - Emerging hellebores and snowdrops in garden beds
  - Stone garden path partially visible
  - Overcast sky (soft gray, no sun visible)

**Built-In Shelving** (opposite wall):
- **Dimensions**: 10 feet wide × 9 feet tall × 14" deep
- **Material**: Painted wood matching wall color (pearl gray)
- **Shelf Configuration**: 7 shelves with varying spacing
- **Styling** (organized by shelf, top to bottom):
  1. Glass specimen jars (uniform height, creates visual rhythm)
  2. Botanical reference books (vertical, spines showing)
  3. White ceramic vessels and bowls (varied shapes, clustered)
  4. Woven baskets (natural fiber, various sizes)
  5. Small potted succulents and cacti in terracotta
  6. Glass bell jars with preserved specimens
  7. Lower shelf: larger baskets with supplies (twine, tools)

**Flooring**:
- **Type**: Wide plank white oak
- **Plank Width**: 7-9 inches (random widths)
- **Finish**: Gray-washed with white lime wash, matte sealer
- **Effect**: Wood grain visible but subdued, soft gray-white tone
- **Condition**: Clean but showing gentle wear patterns

**Ceiling & Beams**:
- **Height**: 11 feet
- **Surface**: Painted plaster in soft white (not pure white, slightly warm)
- **Beams**: 3 exposed beams running perpendicular to windows
  - Material: Reclaimed wood painted soft white-gray
  - Dimensions: 6" × 8" × 12 feet
  - Spacing: 4 feet apart
  - Wire attachment points for hanging installation barely visible

**Walls**:
- **Color**: Pearl gray (Benjamin Moore "Gray Owl" equivalent)
- **Finish**: Matte, slightly chalky (lime paint aesthetic)
- **Condition**: Perfect but not sterile - shows subtle aging
- **Details**: Simple baseboards and crown molding painted same color

---

## Color Palette Breakdown

### Primary Colors (70%):
- **Whites & Grays**: Soft white #F8F8F6, Pearl gray #D9D9D6, Cool mid-gray #A8A8A3
- **Natural Woods**: Light gray-washed oak #C9C5BC, Weathered pine #D4D0C8

### Secondary Colors (20%):
- **Botanical Accents**: Pale pink hellebore #E8D4D8, Soft sage green #B8BFB3, Emerging green shoots #C5D4BC
- **Textiles**: Natural linen #E8E4DC, Undyed wool cream #F0EBE3, Muted sage cushion #A8B09E

### Accent Colors (10%):
- **Metal & Glass**: Matte black steel #2B2B2B, Brass candleholder #A68B5B, Copper patina #B87554
- **Earth Tones**: Terracotta #C9886B, River stone gray #8C8C8C, Dried hydrangea taupe #B09E94

### Lighting Tones:
- **Ambient Light**: Cool daylight #C8D5E0 (soft blue-gray cast from overcast sky)
- **Warm Reflections**: Subtle warmth from linen/wood #F5F3ED (barely perceptible)
- **Shadow Tones**: Soft graduated gray #B8B8B5 (no harsh blacks)

---

## Camera & Photography Specifications

**Camera Setup**:
- **Lens**: 50mm prime lens (full-frame equivalent)
- **Aperture**: f/4.0 for extended depth of field (front to back mostly in focus)
- **ISO**: 800-1000 (to compensate for lower overcast light)
- **Shutter Speed**: 1/80s
- **Focus Point**: On centerpiece arrangement, specifically white ceramic bottle vase
- **Depth of Field**: Gentle focus fall-off - workbench sharp, middle ground (bench) soft-sharp, background (shelving/windows) softly focused but visible

**Composition**:
- **Rule of Thirds**: Workbench on lower-third line, suspended installation in upper-third
- **Golden Ratio**: Main visual weight on left side of frame (70/30 split)
- **Negative Space**: Significant empty space in upper-right quadrant and across work surface
- **Leading Lines**: Table edge, floor planks, horizontal window muntins guide eye
- **Frame**: Shot from standing height (5.5 feet), straight-on with minimal angle
- **Perspective**: Slight wide view to include both suspended installation and full workbench

**Post-Processing Style**:
- Cool color grading (preserve overcast winter quality)
- Lifted blacks (no pure black, soften shadows to charcoal)
- Slight vignette (10-15% opacity, very subtle)
- Reduced saturation (-10 to -15% overall)
- Increased clarity on textures (+15) without over-sharpening
- Color toning: cool blue shadows (+8 blue), neutral highlights (no warming)
- Soft glow on highlights (5% opacity luminosity glow)

---

## Mood & Atmosphere Keywords

**Visual Descriptors**:
Minimalist, contemplative, transitional, ethereal, restrained, meditative, quiet, sparse, elegant, intellectual, serene, soft, muted, sophisticated, understated, wabi-sabi, Scandinavian, Japanese-inspired, winter awakening, botanical study, scholarly, peaceful

**Aesthetic References**:
- Cereal magazine minimalism
- Japanese wabi-sabi philosophy
- Scandinavian hygge restraint
- Monastic botanical study
- Winter poetry by Mary Oliver
- Films: "Ida" (Pawel Pawlikowski) - muted winter palette
- Photography: Beth Kirby, Donna Hay, Nicole Franzen
- Interiors: Studio Oink, Note Design Studio, Norm Architects

**Emotional Tone**:
Space for deep thought during winter's quiet, contemplation of dormancy and renewal, intellectual pursuit of botanical knowledge, comfort in restraint, beauty in simplicity, patient waiting for spring, meditative solitude, gentle productivity, philosophical observation of seasonal cycles

**Sensory Impressions**:
- Visual: Soft focus, muted colors, gentle light, spaciousness
- Tactile: Cool linen, soft wool, smooth glass, weathered wood
- Temperature: Cool but not cold, insulated warmth
- Sound: Quiet, perhaps subtle wind outside, pages turning
- Scent: Dried herbs, paper, wool, subtle floral from bulbs

---

## Alternative Prompt Variations

### Variation 1: Close-Up - Workbench Vignette
```
Intimate close-up interior photography of minimalist winter botanical arrangement on distressed white-painted workbench. Five vessels containing sparse winter botanicals: frosted glass cylinder with pussy willow branches showing silver catkins, white ceramic bottle vase with pale pink hellebores, clear glass jar with white ranunculus and dried taupe hydrangea, small white bowl with catkins, frosted bud vase with bare lichen-covered branch. Arranged with intentional negative space showing bare weathered wood surface. Soft overcast window light from right creates even, shadowless illumination. Background softly blurred showing forcing bulbs in terracotta pots, open plant journal with watercolors, built-in gray shelving. Cool winter palette: whites, soft grays, pale pink, natural wood. Professional still life photography, 8K resolution, f/2.8 aperture, photorealistic textures showing weathered paint, glass transparency, delicate petal details. Serene wabi-sabi aesthetic, contemplative winter minimalism, editorial quality for Cereal or Kinfolk magazine.
```

### Variation 2: Atmospheric - Suspended Installation Focus
```
Ethereal interior photography focusing on delicate suspended botanical installation hanging from whitewashed ceiling beams. Bare birch branches with white bark, silver dollar eucalyptus, translucent lunaria seed pods (honesty plant), paper-white narcissus blooms create floating sculpture suspended by thin invisible wires. Mobile-style asymmetric composition with 60% empty space, emphasizing winter's spare beauty. Soft overcast light from tall Crittall windows (camera right) filters through translucent lunaria pods creating magical glow. Below, partially visible weathered workbench with minimal winter arrangement. Pearl gray walls, gray-washed oak floors. Misty, soft-focus quality throughout. High key exposure, cool color temperature (5500K), no harsh shadows. Professional architectural photography, 8K resolution, f/4, photorealistic rendering of delicate botanical forms and glass-like seed pods. Contemplative, meditative, transitional winter-spring atmosphere, Scandinavian-Japanese fusion aesthetic.
```

### Variation 3: Wide Environmental - Full Studio Context
```
Wide angle interior architectural photography of complete minimalist botanist's winter studio space, 50mm lens perspective. Tall Crittall-style windows (matte black steel frames) along right wall showing winter garden view: bare trees, melting snow patches, emerging hellebores. Soft overcast afternoon light (3-4pm) creates even, cool illumination throughout pearl-gray painted room. Center: weathered white-painted workbench with sparse botanical arrangement (pussy willows, hellebores, ranunculus in frosted glass and white ceramic vessels). Overhead: suspended installation of bare branches, eucalyptus, translucent lunaria pods creating ethereal floating layer. Left: floor-to-ceiling built-in shelving (gray-painted) organized with specimen jars, botanical books, white ceramics, woven baskets. Corner: low linen-upholstered bench with wool cushions and cable-knit throw blanket. Gray-washed wide plank oak floors. Minimal, contemplative atmosphere with emphasis on negative space and restraint. Color palette: 70% whites and soft grays, minimal color accents. Professional interior design photography, 8K resolution, f/5.6 for depth, photorealistic textures. Sophisticated winter minimalism, scholarly botanical study aesthetic, Cereal magazine editorial quality.
```

### Variation 4: Detail Study - Forcing Bulbs & Specimens
```
Macro detail photography of winter propagation station on distressed workbench. Four terracotta pots (4-6 inch diameter) with forcing bulbs showing early growth: paperwhites with 3-4 inch green shoots emerging, hyacinth with purple-pink bud barely visible, amaryllis with thick pale green stalk beginning. Arranged with collection of smooth gray and white river stones, vintage glass specimen jars containing preserved moss and lichen, white porcelain mortar and pestle, small copper watering can with patina, pruning shears. Open leather plant journal visible at edge showing watercolor studies. Soft overcast window light from left creates even illumination, cool color temperature. Background softly blurred showing pearl gray wall and built-in shelving. Professional botanical still life photography, 8K resolution, f/2.8 aperture, sharp focus on emerging green shoots, photorealistic textures showing terracotta grain, glass transparency, plant detail. Quiet, contemplative mood capturing winter dormancy breaking into spring awakening, scholarly documentation aesthetic.
```

### Variation 5: Through the Window - Exterior View Looking In
```
Exterior perspective looking through tall Crittall-style window into minimalist botanist's winter studio. Shot from garden side showing interior through black steel window frames. Inside visible: weathered white workbench with sparse botanical arrangement (pussy willows, hellebores in frosted glass vessels), suspended branch installation overhead, pearl gray walls, built-in shelving. Soft interior illumination from overcast daylight. Foreground: winter garden in transition - patches of melting snow on ground, bare deciduous tree branch framing top of shot, emerging snowdrops and hellebores in garden bed at bottom edge. Glass creates subtle reflections and distortions. Cool winter palette throughout. Late afternoon overcast light, even and soft. Professional architectural photography from exterior, 8K resolution, f/5.6 showing both exterior garden detail and interior space, photorealistic rendering of glass, reflections, winter botanicals. Contemplative mood showing relationship between interior study and exterior natural world, transitional season, scholarly observation of dormancy and awakening.
```

---

## Styling Checklist for Recreation

### Essential Props:

**Workbench & Centerpiece**:
- [ ] Long wooden table/workbench (7 feet minimum, distressed white/cream finish)
- [ ] 5 vessels: frosted glass cylinder, white ceramic vase, clear glass jar, white bowl, small bud vase
- [ ] Pussy willow branches (with catkins, 3-5 stems)
- [ ] Hellebores (pale pink or white, 3-5 stems)
- [ ] White ranunculus (2-3 stems)
- [ ] Dried hydrangea heads (taupe/faded, 2)
- [ ] Few bare branches (birch or similar with interesting form)

**Suspended Installation**:
- [ ] Bare branches (birch preferred for white bark)
- [ ] Silver dollar eucalyptus (dried or preserved)
- [ ] Lunaria/honesty plant seed pods (translucent, critical for magic effect)
- [ ] Thin wire for suspension (silver or clear fishing line)

**Forcing Station**:
- [ ] 4 terracotta pots (4-6" diameter)
- [ ] Paperwhite and/or hyacinth bulbs (showing early shoots)
- [ ] River stones (5-7 smooth gray/white stones)
- [ ] Small copper or brass watering can

**Study Elements**:
- [ ] Glass specimen jars (3-5 vintage or apothecary style)
- [ ] Pressed plants or moss specimens
- [ ] Leather or cloth journal (weathered appearance)
- [ ] Vintage botanical books (3-5 with worn covers)

**Seating Area**:
- [ ] Low bench or settee (linen or natural fabric)
- [ ] Cushions in cream, gray, sage (3 mixed sizes)
- [ ] Chunky cable-knit throw blanket (natural wool)
- [ ] Small side table (painted gray or natural wood)
- [ ] Simple white ceramic mug
- [ ] Candle holder with taper candle

### Architectural Requirements:
- [ ] Large windows (overcast day shooting essential for soft light)
- [ ] Pearl gray or soft white painted walls (matte finish)
- [ ] Light-colored flooring (gray-washed or whitewashed wood ideal)
- [ ] Exposed beams or ability to suspend installation from ceiling
- [ ] Built-in shelving or bookcase (optional but adds depth)

### Lighting Essentials:
- [ ] **CRITICAL**: Shoot on overcast day (no direct sun)
- [ ] Time: 3-5pm for soft afternoon quality
- [ ] Windows should provide even, diffused light (north-facing ideal)
- [ ] Avoid any artificial lighting (preserve natural cool tone)
- [ ] Optional: White bounce card to fill extreme shadows (minimal use)

### Styling Priorities:
1. **Most Critical**: Overcast natural light (makes or breaks the mood)
2. **Very Important**: Restraint and negative space (less is more)
3. **Important**: Cool color palette (whites, grays, minimal color)
4. **Nice to Have**: Suspended installation (adds ethereal quality)
5. **Final Touch**: Translucent lunaria pods (create magic with backlight)

### Color Discipline:
- Remove any warm browns, oranges, bright colors
- Stick to: whites, grays, pale pink, minimal sage green
- Desaturate during editing if needed
- Preserve cool overcast quality (don't warm up in post)

---

## AI Generation Settings (Platform-Specific)

### Midjourney:
```
/imagine prompt: [insert master prompt above] --ar 4:3 --style raw --stylize 100 --v 6
```
**Parameters**:
- `--ar 4:3`: Slightly vertical orientation suits interior architecture
- `--style raw`: Maximum photorealism, minimal artistic interpretation
- `--stylize 100`: Lower stylization for authentic photography feel
- `--chaos 0`: No variation - we want precision and restraint

### DALL-E 3:
Use master prompt as-is with emphasis on:
"This must look like professional interior photography from Cereal magazine - soft, muted, minimal, contemplative. Overcast winter light is essential. Cool color palette with desaturated tones. Photorealistic textures but ethereal mood."

### Stable Diffusion XL:
**Recommended Checkpoint**: Realistic Vision V6.0 or SDXL Base with Photorealism LoRA
**Sampling Steps**: 50-70 (higher for subtle detail)
**CFG Scale**: 6-7 (lower for more natural, less forced results)
**Negative Prompt**: 
```
direct sunlight, harsh shadows, warm lighting, orange tones, saturated colors, cluttered, busy composition, modern minimalist sterile aesthetic, bright white walls, colorful flowers, artificial plants, 3d render, illustration, cartoon, oversaturated, high contrast, messy, disorganized, plastic materials, glossy finishes, contemporary decor, trending on artstation
```

**Positive Emphasis** (increase weight):
```
overcast natural light (1.3), soft diffused illumination (1.2), cool color palette (1.2), muted tones (1.2), minimalist restraint (1.2), negative space (1.1), wabi-sabi aesthetic (1.1), photorealistic textures (1.3)
```

---

## Scene Story & Context

This is the studio of a botanist-philosopher who studies plant dormancy and the mechanisms of winter survival. The space reflects this intellectual pursuit: sparse, contemplative, designed for observation rather than production.

The centerpiece isn't decoration—it's this week's specimens. Pussy willows collected from a February walk, brought inside to observe catkin development. Early hellebores dug from beneath melting snow, placed in water to study petal structure. The arrangement is documentary, not aesthetic, though beauty emerges from the honest observation.

The suspended installation began as a single branch found during a winter walk. Over months, it grew—adding eucalyptus from a friend's garden, lunaria seed pods saved from last year's growth, narcissus forced indoors. It hangs as a three-dimensional herbarium, a catalog of winter's sparse offerings.

The forcing bulbs represent an experiment in acceleration—can awareness of spring's coming be hastened? The paperwhites respond first, green shoots emerging while snow still covers the garden. The hyacinth is slower, more cautious. The amaryllis will be magnificent but demands patience.

This isn't a space designed for Instagram. It's a workspace for someone who finds intellectual satisfaction in understanding how life persists through apparent death. The restraint isn't aesthetic choice—it's philosophical conviction. Winter teaches subtraction, and this room respects that lesson.

The bench serves its purpose late at night when observation becomes meditation. The botanist sits with tea gone cold, watching how moonlight changes the suspended installation's shadows, considering the mathematics of dormancy, writing notes about cellular processes that allow freezing and thawing without death.

This is a room for asking questions winter poses: How does life know when to wait? What signals the breaking of dormancy? Can hope be studied scientifically, or is it merely another name for biological inevitability?

---

## Seasonal Transition Notes

This scene specifically captures **late February through early March** - that liminal moment when winter loosens its grip but spring hasn't yet arrived:

**Visual Markers**:
- Melting snow (patches, not complete coverage)
- Emerging early bloomers (hellebores, snowdrops) but NO full spring flowers
- Bare branches still dominant (no leaf buds visible)
- Forcing bulbs showing shoots but not yet flowering
- Pussy willows in catkin stage (not leafing out)
- Cool overcast light (winter quality, not spring brightness)

**Mood Alignment**:
- Contemplative, not celebratory
- Quiet anticipation, not exuberant awakening
- Intellectual observation, not emotional reaction
- Patience embodied, not urgency

**Color Discipline for Season**:
- Avoid bright spring colors (no yellows, bright pinks, vibrant greens)
- Maintain winter's muted palette with subtle warmth emerging
- Cool dominates (70%), warm accents minimal (30%)
- Whites and grays are primary, color is accent only

This ensures the scene authentically represents the transitional season rather than jumping prematurely into spring.

---

## Technical Execution Tips

**For AI Generation**:
1. Generate multiple variations focusing on light quality
2. Look for soft, even illumination (reject harsh shadows)
3. Verify cool color temperature (reject warm golden tones)
4. Check for restraint (reject overly styled or cluttered results)
5. Ensure negative space is preserved (reject filling every area)

**For Physical Photography**:
1. Scout location on overcast days (timing is everything)
2. Remove all warm-toned objects from scene
3. Under-style rather than over-style (edit down)
4. Use longer exposure to soften any remaining shadows
5. Cool white balance in camera (5500-6000K)
6. Slight underexposure in camera (protect highlights, lift shadows in post)

**Post-Processing Workflow**:
1. White balance: Shift cooler by 300-500K
2. Exposure: Lift shadows significantly, slightly reduce highlights
3. Saturation: Reduce by 10-15% globally
4. Individual color HSL adjustments:
   - Desaturate oranges/yellows completely
   - Shift greens toward blue-green (away from yellow-green)
   - Desaturate reds/pinks to soft pastels
5. Add subtle blue to shadows (split toning)
6. Vignette: Very subtle, 10-15% opacity
7. Grain: Optional fine grain for film aesthetic (2-3% opacity)
8. Clarity: +10 to +15 for texture without over-sharpening
9. Final check: View at low brightness to ensure maintained mood


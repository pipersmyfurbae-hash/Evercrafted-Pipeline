# Botanist's Atelier - Complete Scene Blueprint

## Master Image Generation Prompt

```
High-resolution interior photography of a sun-drenched botanist's atelier workshop, captured during golden hour. Center composition features a long rustic wooden trestle table (8 feet length, weathered oak with visible grain and patina) displaying an elaborate wildflower centerpiece arrangement in vintage glass bottles and apothecary jars of varying heights (12-18 inches tall). Wildflower arrangement includes: tall dried grasses, delicate Queen Anne's lace, burgundy astilbe plumes, wild ferns with unfurling fronds, dusty pink yarrow clusters, purple statice, wheat stalks, and trailing eucalyptus. Bottles are mismatched antique glass in amber, clear, and soft green tones, clustered asymmetrically across table center.

Overhead, draped across exposed wooden ceiling beams (dark walnut, aged with character) is a lush, sprawling botanical garland (12-15 feet length) made of dried seeded eucalyptus branches, hop vines with cone clusters, willow branches, and wisps of dried baby's breath, hung loosely with natural draping movement and organic asymmetry.

Room filled with lived-in character and creative clutter: stacks of botanical sketches and watercolor studies on aged paper scattered across table edges, clusters of terracotta pots in various sizes (some containing soil and small seedlings, others empty and stacked), vintage botanical reference books with worn leather spines, glass specimen jars, antique brass magnifying glass, wooden plant labels, bundle of dried lavender hanging from beam, ceramic bowls with collected seed pods and dried flowers.

In corner: deep green velvet armchair (tufted back, brass nail head trim, slightly worn fabric showing character) with cream linen throw blanket draped over arm, small side table with stacked books and tea cup.

Architectural details: Large industrial steel-framed windows (floor-to-ceiling, 10+ feet tall, divided into 12-pane grid sections) along entire wall, warm afternoon sunlight streaming through at 45-degree angle creating dramatic directional lighting. Visible dust motes and pollen particles suspended in volumetric light beams. Exposed brick wall opposite windows (aged red brick with white mortar, slightly crumbling texture). Wide plank hardwood flooring (reclaimed pine, honey-toned with wear patterns). Exposed ceiling beams create architectural interest overhead.

Color palette: Warm honey and amber tones, sage greens, dusty pinks, burgundy accents, cream and natural linen, weathered wood browns, terracotta oranges. Lighting: Warm, natural golden hour sunlight from right side, creating high contrast with deep shadows on left side of room, soft bounce light illuminating shadow areas. Cinematic depth of field with sharp focus on centerpiece arrangement, gentle bokeh on background elements.

Atmosphere: Cozy, lived-in creative workspace, romantic yet practical, botanical academia aesthetic, artisan craftsmanship, European countryside cottage meets urban industrial loft. Professional interior photography, 8K resolution, shot with 35mm lens, f/2.8 aperture, shallow depth of field, photorealistic textures showing fabric weave, wood grain, glass reflections, botanical details. Editorial magazine quality for kinfolk, cereal magazine, or domino magazine aesthetic.
```

---

## Scene Architecture & Composition

### Spatial Layout (Bird's Eye View)

```
                    WINDOWS (light source →)
    ═══════════════════════════════════════════════
    ║                                             ║
    ║    [Dried herbs    Garland overhead         ║
    ║     hanging]       draped on beams          ║
    ║         ↓                                   ║
    ║                                             ║
    ║         ┌─────────────────────┐            ║
    ║         │   TRESTLE TABLE     │            ║
    ║  Stacks │  [Wildflower        │  Scattered ║
    ║  of pots│   centerpiece]      │  sketches  ║
BRICK║         │                     │            ║BRICK
WALL ║         └─────────────────────┘            ║WALL
    ║                                             ║
    ║                                   ┌───┐    ║
    ║    [Plant shelving]              │ARM│    ║
    ║                                   │CHR│    ║
    ║                                   └───┘    ║
    ═══════════════════════════════════════════════
```

### Lighting Diagram

**Primary Light Source**: Large industrial windows (camera right, 3 o'clock position)
- Time: 4-5pm golden hour, late afternoon
- Angle: 45° downward trajectory
- Quality: Warm, diffused through slightly dusty glass
- Color temperature: 4500K (warm golden)

**Light Behavior**:
- Direct beams hit table at 45° creating long shadows stretching left
- Volumetric god rays visible due to dust/pollen particles
- Backlit garland creates silhouette with edge lighting on eucalyptus leaves
- Specular highlights on glass bottles (bright catchlights)
- Subsurface scattering through flower petals (translucent glow)
- Warm bounce light from honey-toned floor fills shadows

**Shadow Map**:
- Deep shadows: Left side of room, under table, behind armchair
- Mid-tones: Center table area with indirect light
- Highlights: Right edge of table, glass bottles, window-facing surfaces

---

## Detailed Element Specifications

### Central Trestle Table

**Dimensions**: 96" L × 36" W × 30" H
**Material**: Reclaimed oak with mortise-and-tenon joinery
**Finish**: Natural oil finish, heavily worn with water rings and tool marks
**Legs**: Sturdy X-frame trestle base, connected by central stretcher beam
**Surface**: Shows years of creative use - paint splatters, knife marks, ink stains

### Wildflower Centerpiece Composition

**Container Strategy**: Asymmetric clustering following odd-number rule (7 total bottles)

**Bottles Inventory**:
1. Tall amber apothecary jar (18" H) - anchoring back left
2. Clear vintage medicine bottle (14" H) - front center
3. Seafoam green glass vase (16" H) - back right
4. Short clear ribbed bottle (10" H) - front left
5. Amber square poison bottle (12" H) - mid-right
6. Clear laboratory beaker (15" H) - back center
7. Green glass ink well (8" H) - front right accent

**Botanical Fill** (by bottle):
- Tall amber: 5 stems wheat grass, 3 wild fern fronds
- Clear medicine: Queen Anne's lace cluster (9 stems), purple statice
- Seafoam green: Burgundy astilbe (4 plumes), dusty pink yarrow
- Short ribbed: Single dramatic fern frond, trailing eucalyptus
- Amber square: Wild grass mix, dried thistle
- Laboratory beaker: Mixed wildflowers - cosmos, bachelor buttons, wild carrot
- Green inkwell: Delicate baby's breath, single poppy pod

**Arrangement Principles**:
- Heights vary 8-18 inches creating dynamic skyline
- Asymmetric triangle composition (tallest elements back/left)
- Negative space between bottles allows visual breathing room
- Some stems droop naturally over bottle edges
- Color gradient: warm tones (amber/burgundy) left, cool tones (purple/green) right

### Overhead Garland Construction

**Total Length**: 14 feet spanning two ceiling beams
**Attachment**: Natural fiber twine at 5 connection points
**Draping Pattern**: Loose swags with 8-12 inch depth in curves

**Botanical Components** (by percentage):
- 50% Seeded eucalyptus branches (silvery-green, cascading)
- 25% Hop vines with cone clusters (trailing, adds movement)
- 15% Willow branches (structural backbone, creates curves)
- 10% Accent botanicals (baby's breath wisps, dried hydrangea, ribbon grass)

**Construction Technique**:
- Wire armature base (18-gauge floral wire)
- Botanicals wired in overlapping sections
- Natural taper at ends (fuller in center, sparse at terminals)
- Some elements hang below garland creating dimension
- Visible natural movement as if slightly affected by air current

### Green Velvet Armchair

**Style**: English club chair, circa 1940s aesthetic
**Dimensions**: 32" W × 34" D × 38" H (seat height 18")
**Upholstery**: Deep emerald green cotton velvet with slight sheen
**Details**: 
- Rolled arms with brass nail head trim (oxidized patina)
- Tufted back with 9 buttons (fabric-covered)
- Turned wooden legs in mahogany (front legs visible)
- Slight wear on arms showing lighter green undertones
- One decorative pillow: cream linen with botanical embroidery

**Styling**:
- Cream chunky knit throw blanket casually draped over left arm
- Natural linen cushion (slightly rumpled, lived-in)
- Small wooden side table (16" diameter) next to chair with:
  - Stack of 3 botanical books (largest to smallest)
  - White ceramic tea cup with saucer
  - Reading glasses

### Character Elements (Scattered Throughout)

**On Table Surface**:
- Stack of 15-20 botanical sketches (loose paper, some curling edges)
- Vintage botanical prints in sepia tones showing plant anatomy
- Watercolor paint palette (wooden, showing dried paint residue)
- Bundle of natural bristle paintbrushes in ceramic jar
- Antique brass magnifying glass (4" diameter lens)
- Scattered wooden plant labels with handwritten Latin names
- Roll of natural jute twine
- Small ceramic bowls containing:
  - Collected acorns and seed pods
  - Dried flower petals
  - River stones
- Open leather-bound journal with pressed flowers

**Floor & Shelving**:
- Cluster of 9-12 terracotta pots (4-10" diameters) stacked organically
- 3-4 pots contain small seedlings or herbs
- Woven wicker basket with dried wheat bundles
- Vintage wooden plant crate (stamped with faded lettering)
- Small wooden step stool (paint-splattered)

**Walls & Hanging**:
- Bundle of dried lavender (12 stems) tied with twine, hanging from beam
- Small macramé plant hanger (empty, decorative)
- Antique botanical chart (paper, aged and yellowed)
- Wooden peg rail with hanging tools: pruning shears, hand trowel

### Architectural Details

**Windows**:
- **Type**: Industrial steel casement, factory-style
- **Configuration**: 3 window units, each divided into 12 panes (4×3 grid)
- **Dimensions**: Each unit 48" W × 120" H
- **Frame**: Black painted steel with slight rust patina at corners
- **Glass**: Slightly wavy vintage glass with minimal distortion
- **Hardware**: Original cremone bolts and handles
- **Condition**: Well-maintained but showing age, some paint chips

**Ceiling Beams**:
- **Material**: Reclaimed Douglas fir or oak
- **Dimensions**: 8" × 8" × 20 feet long
- **Spacing**: 6 feet apart (parallel to windows)
- **Finish**: Dark walnut stain, hand-hewn texture visible
- **Details**: Visible adze marks, old mortise holes, metal brackets

**Flooring**:
- **Type**: Wide plank reclaimed pine
- **Plank Width**: 8-12 inches (random widths)
- **Finish**: Natural oil with amber honey tone
- **Character**: Knots, nail holes, wear patterns showing foot traffic
- **Layout**: Running perpendicular to windows

**Brick Wall**:
- **Type**: Exposed structural brick
- **Color**: Aged red-orange with white mortar
- **Pattern**: Running bond (standard offset)
- **Condition**: Slightly crumbling mortar, efflorescence in spots, shows authentic age
- **Treatment**: Unsealed, raw texture visible

---

## Color Palette Breakdown

### Primary Colors (60%):
- **Warm Wood Tones**: Honey oak #D4A574, Walnut #5C4033, Reclaimed pine #C19A6B
- **Natural Greens**: Sage eucalyptus #A8AF8E, Emerald velvet #2D5F3F, Fern green #4F7942

### Secondary Colors (25%):
- **Botanical Accents**: Dusty rose #C9A9A6, Burgundy astilbe #6B3E3E, Lavender purple #9D8EC1
- **Earth Tones**: Terracotta #C15B3A, Cream linen #F5F1E8, Wheat gold #E8C78F

### Accent Colors (15%):
- **Metal & Glass**: Oxidized brass #9C7E4E, Amber glass #D4A05E, Steel window frames #2B2B2B
- **Light Colors**: Warm white sunlight #FFF8E7, Shadow blue-gray #6B7280

---

## Camera & Photography Specifications

**Camera Setup**:
- **Lens**: 35mm prime lens (full-frame equivalent)
- **Aperture**: f/2.8 for shallow depth of field
- **ISO**: 400-640 (to handle indoor natural light)
- **Shutter Speed**: 1/125s
- **Focus Point**: Centered on wildflower arrangement, specifically the clear medicine bottle
- **Depth of Field**: Sharp focus on table centerpiece, gentle bokeh on background elements (armchair, walls, garland softly out of focus)

**Composition**:
- **Rule of Thirds**: Table centerpiece on lower-third horizontal line, offset right of vertical center
- **Leading Lines**: Table edges and floor planks lead eye to focal point
- **Negative Space**: Upper left quadrant shows garland and ceiling architecture
- **Frame**: Shot from standing eye-level (5.5 feet high), slight downward angle (10-15°)

**Post-Processing Style**:
- Warm color grading (lifted shadows, golden highlights)
- Slight vignette darkening corners (15-20% opacity)
- Increased clarity on textures without over-sharpening
- Film grain overlay (subtle, 5-8% opacity for organic feel)
- Color toning: warm highlights (+10 orange/yellow), cool shadows (+5 blue)

---

## Mood & Atmosphere Keywords

**Visual Descriptors**:
Lived-in, sun-drenched, botanical, artisan, romantic, creative, nostalgic, European countryside, organic, curated clutter, warm, inviting, contemplative, peaceful, inspirational, handcrafted, vintage, timeless, rustic elegance

**Aesthetic References**:
- Kinfolk magazine editorial spreads
- Dutch still life paintings (light quality)
- Anthropologie catalog styling
- English cottage herbalist workshop
- Wes Anderson color palette warmth
- Nancy Meyers film interior design
- Studio Ghibli warmth and detail

**Emotional Tone**:
Cozy refuge for creative work, space that invites lingering and daydreaming, sanctuary for botanical study and artistic practice, lived-in wisdom and accumulated knowledge, gentle productivity, romantic solitude

---

## Alternative Prompt Variations

### Variation 1: Tighter Crop - Table Detail
```
Intimate close-up view of botanical centerpiece on weathered oak trestle table. Seven vintage glass bottles (amber, clear, seafoam green) filled with wildflower arrangement: wheat grass, fern fronds, Queen Anne's lace, burgundy astilbe, dusty pink yarrow, purple statice. Scattered around bottles: botanical sketches on aged paper, terracotta pots, brass magnifying glass, ceramic bowl with acorns. Warm golden hour sunlight from right creates dramatic side-lighting with volumetric dust motes visible. Background softly blurred showing green velvet armchair and industrial windows. Cinematic shallow depth of field, photorealistic textures, editorial still life photography, 8K resolution, cozy botanist's atelier aesthetic.
```

### Variation 2: Wide Angle - Full Room
```
Wide angle interior architectural photography of complete botanist's atelier workspace, shot with 24mm lens. Entire room visible: floor-to-ceiling industrial windows along right wall flooding space with golden afternoon light, long wooden trestle table center with elaborate wildflower centerpiece, overhead eucalyptus and hop garland draped on ceiling beams, green velvet armchair in corner with throw blanket, exposed brick wall opposite windows, wide plank floors. Creative clutter throughout: stacked terracotta pots, botanical sketches, vintage books, hanging dried herbs. Warm cinematic lighting, high dynamic range showing detail in both highlights and shadows, photorealistic, 8K resolution, lived-in creative space with character.
```

### Variation 3: Atmospheric Mood - Backlit Garland
```
Dramatic backlit interior photography focusing on overhead botanical garland silhouetted against bright industrial windows. Lush eucalyptus, hop vines, and willow branches draped across dark wooden ceiling beams create organic sculptural forms. Strong contre-jour lighting from behind creates glowing edge-lit rim light on botanical elements, visible dust particles suspended in volumetric light beams. Below, partially visible wooden table with wildflower bottles, suggestion of creative workspace. High contrast between bright windows and shadowed interior, cinematic atmospheric lighting, photorealistic, 8K resolution, romantic botanical atelier aesthetic.
```

---

## Styling Checklist for Recreation

### Essential Props:
- [ ] Long wooden trestle table (8 feet minimum)
- [ ] 7 vintage glass bottles/jars (varying heights and colors)
- [ ] Dried/silk wildflowers and ferns
- [ ] Eucalyptus and hop garland materials
- [ ] Green velvet armchair or similar upholstered seating
- [ ] Terracotta pots (assorted sizes, 10+ pieces)
- [ ] Botanical sketches/prints (can be printed reproductions)
- [ ] Cream throw blanket
- [ ] Vintage books (botanical reference aesthetic)

### Architectural Requirements:
- [ ] Large windows (natural light source essential)
- [ ] Exposed ceiling beams or method to hang garland
- [ ] Hardwood or wood-look flooring
- [ ] Neutral/warm wall color (exposed brick ideal but not required)

### Lighting Essentials:
- [ ] Shoot during golden hour (4-6pm or 8-10am depending on window orientation)
- [ ] Windows should face direction that receives direct sun at shoot time
- [ ] Optional: Subtle fill light for shadow areas (bounce card or soft lamp)

### Styling Priorities:
1. **Most Important**: Window light quality and direction
2. **Very Important**: Central table centerpiece arrangement
3. **Important**: Overhead garland creating visual interest
4. **Nice to Have**: Character details (books, pots, sketches)
5. **Final Touch**: Dust/atmosphere for light beams

---

## AI Generation Settings (Platform-Specific)

### Midjourney:
```
/imagine prompt: [insert master prompt above] --ar 3:2 --style raw --stylize 150 --v 6
```
**Parameters**:
- `--ar 3:2`: Landscape aspect ratio ideal for editorial interiors
- `--style raw`: More photographic, less artistic interpretation
- `--stylize 150`: Moderate stylization, maintains realism
- `--chaos 15`: Slight variation for organic feel (optional)

### DALL-E 3:
Use master prompt as-is. DALL-E 3 naturally handles detailed prompts well. Consider adding:
"This should look like a professional interior design photograph from Kinfolk or Cereal magazine, with authentic textures and realistic lighting."

### Stable Diffusion:
**Recommended Checkpoint**: Realistic Vision V5.1 or DreamShaper
**Sampling Steps**: 40-60
**CFG Scale**: 7-9
**Negative Prompt**: 
```
cartoon, anime, 3d render, oversaturated colors, artificial lighting, cluttered, messy, clean modern aesthetic, minimalist, white walls, fluorescent lighting, plastic flowers, fake plants, digital art
```

---

## Scene Story & Context

This atelier belongs to a botanical illustrator who splits time between field work collecting specimens and studio time documenting findings. The space reflects decades of accumulated knowledge—not arranged for show, but naturally organized through daily use.

The centerpiece isn't styled; it's this week's collection from a meadow walk, placed in whatever vessels were clean. The overhead garland started as a single eucalyptus branch and grew organically as new findings were added. The sketches scattered across the table represent ongoing work studying local wildflower species.

The armchair serves as thinking space—where the botanist sits with tea and reference books, reviewing the day's sketches. The throw blanket suggests late nights working past sunset, when the work becomes too compelling to abandon.

This isn't a curated Instagram moment. It's a working creative space that happens to be beautiful because it's *used* with intention and love.


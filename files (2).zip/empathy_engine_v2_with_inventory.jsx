import React, { useState, useRef } from 'react';
import { Heart, Home, Flower2, Image, Package, Sparkles, User, Camera, Wand2, Upload, ChevronRight, Download } from 'lucide-react';

/**
 * EMPATHY ENGINE V2: Enhanced with Real Inventory Integration
 * 
 * Now uses actual floral catalog structure with:
 * - Emotional attributes
 * - Complete geometry (anchor points, bloom centers, principal axis)
 * - Color palettes (hex codes, percentages)
 * - Spatial intelligence (coverage, density, recommended quantities)
 * - Design intelligence (layer assignment, style compatibility)
 * - Visual descriptions and rendering logic
 */

// REAL FLORAL SELECTION ENGINE
function selectFloralsFromInventory(inventory, characterProfile, spaceProfile) {
  const scored = inventory.map(floral => {
    let score = 0;
    const reasons = [];
    
    // Score 1: Emotional Attribute Matching (40 points max)
    if (floral.visualIntelligence?.designIntelligence?.emotionalAttributes) {
      const floralEmotions = floral.visualIntelligence.designIntelligence.emotionalAttributes;
      const characterEmotions = characterProfile.emotionalKeywords || [];
      
      floralEmotions.forEach(emotion => {
        if (characterEmotions.some(ce => ce.toLowerCase().includes(emotion.toLowerCase()))) {
          score += 10;
          reasons.push(`Emotional match: "${emotion}" aligns with character`);
        }
      });
    }
    
    // Score 2: Color Palette Matching (30 points max)
    if (floral.visualIntelligence?.visualProperties?.colorProfile) {
      const floralColors = [
        floral.visualIntelligence.visualProperties.colorProfile.primary,
        ...(floral.visualIntelligence.visualProperties.colorProfile.secondary || [])
      ];
      
      const spaceColors = spaceProfile.emotionalColors || [];
      
      floralColors.forEach(colorObj => {
        if (spaceColors.some(sc => 
          sc.toLowerCase().includes(colorObj.name.toLowerCase()) ||
          colorObj.name.toLowerCase().includes(sc.toLowerCase())
        )) {
          score += 10;
          reasons.push(`Color match: ${colorObj.name} in palette`);
        }
      });
    }
    
    // Score 3: Seasonality Match (20 points max)
    if (floral.visualIntelligence?.designIntelligence?.seasonality) {
      const floralSeasons = floral.visualIntelligence.designIntelligence.seasonality;
      const characterSeason = characterProfile.season || 'all-season';
      
      if (floralSeasons.includes(characterSeason) || floralSeasons.includes('all-season')) {
        score += 20;
        reasons.push(`Seasonal fit: ${floralSeasons.join(', ')}`);
      }
    }
    
    // Score 4: Style Compatibility (10 points max)
    if (floral.visualIntelligence?.designIntelligence?.styleCompatibility) {
      const floralStyles = floral.visualIntelligence.designIntelligence.styleCompatibility;
      const characterStyle = characterProfile.aesthetic || '';
      
      floralStyles.forEach(style => {
        if (characterStyle.toLowerCase().includes(style.toLowerCase())) {
          score += 5;
          reasons.push(`Style match: ${style}`);
        }
      });
    }
    
    return {
      ...floral,
      selectionScore: score,
      selectionReasons: reasons
    };
  });
  
  // Sort by score and return top selections
  return scored
    .filter(f => f.selectionScore > 15) // Minimum threshold
    .sort((a, b) => b.selectionScore - a.selectionScore)
    .slice(0, 7); // Top 7 florals for wreath
}

// WREATH POSITIONING ENGINE using actual geometry
function generateWreathPositioning(selectedFlorals, wreathSize = 20) {
  const goldenRatio = 1.618;
  const focalPoints = [50, 135, 220]; // Golden ratio divisions
  
  return selectedFlorals.map((floral, index) => {
    const designRole = floral.visualIntelligence?.designIntelligence?.designRole || 'accent';
    
    // Focal elements get primary positions
    if (designRole === 'focal' && index < 3) {
      const angle = focalPoints[index];
      const geometry = floral.visualIntelligence?.geometryV2;
      
      return {
        floral,
        position: {
          angle: angle,
          radiusSpread: [0, 30],
          depth: [2, 4],
          quantity: Math.ceil(floral.visualIntelligence?.spatialProperties?.recommendedQuantity24in / 2) || 1
        },
        geometry: {
          anchorPoint: geometry?.anchorPoint?.normalized,
          bloomCenter: geometry?.bloomCenter?.normalized,
          principalAxis: geometry?.principalAxis?.degrees || 0
        },
        reasoning: `${designRole} element positioned at golden ratio point (${angle}°)`
      };
    }
    
    // Accent/filler elements distributed around
    const baseAngle = (index * 360 / selectedFlorals.length) + 25;
    return {
      floral,
      position: {
        angle: baseAngle,
        radiusSpread: [0, 20],
        depth: [1, 2],
        quantity: floral.visualIntelligence?.spatialProperties?.recommendedQuantity24in || 3
      },
      geometry: {
        anchorPoint: floral.visualIntelligence?.geometryV2?.anchorPoint?.normalized,
        bloomCenter: floral.visualIntelligence?.geometryV2?.bloomCenter?.normalized,
        principalAxis: floral.visualIntelligence?.geometryV2?.principalAxis?.degrees || 0
      },
      reasoning: `${designRole} element distributed for balance`
    };
  });
}

// WREATH IMAGE PROMPT GENERATOR using actual floral data
function generateWreathImagePrompt(selectedFlorals, positioning, characterStory, livingSpace) {
  // Extract all floral names and colors
  const floralList = positioning.map(p => {
    const floral = p.floral;
    const qty = p.position.quantity;
    const color = floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name || floral.productSpecs?.color;
    return `${qty}x ${floral.name} (${color})`;
  }).join(', ');
  
  // Get dominant colors from florals
  const colorHexes = positioning
    .map(p => p.floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.hex)
    .filter(Boolean)
    .slice(0, 3);
  
  // Build prompt
  return `Professional product photography of handmade luxury faux floral wreath, 20 inches diameter, hanging centered on ${livingSpace.wallColor || 'soft gray'} wall backdrop. 
  
${characterStory.aesthetic} style wreath featuring: ${floralList}.

Base: Whitewashed grapevine wreath, 5-6 inches depth projection. Three distinct focal clusters positioned asymmetrically at ${positioning.filter(p => p.floral.visualIntelligence?.designIntelligence?.designRole === 'focal').map(p => p.position.angle + '°').join(', ')} following golden ratio composition.

Color palette: ${colorHexes.join(', ')} as primary colors. ${livingSpace.colorDescription || 'Soft, muted tones with natural materials'}.

${livingSpace.lightingDescription || 'Soft overcast natural light from right, even shadowless illumination, cool color temperature (5500K)'}.

Styling: ${characterStory.wreathCharacteristics || 'Minimalist restraint, intentional negative space, asymmetric balance'}. Shows depth and dimension with layered florals.

Professional florist craftsmanship, photorealistic silk and fabric textures, 8K resolution, shallow depth of field on background, ${characterStory.mood || 'contemplative and elegant'} mood. Shot with 50mm lens, f/2.8, editorial quality for Cereal magazine or Kinfolk aesthetic.`;
}

// ASSEMBLY LAYER IMAGE PROMPTS using actual geometry
function generateAssemblyLayerPrompts(positioning, layer) {
  const relevantFlorals = positioning.filter(p => 
    layer.floralsUsed.includes(p.floral.name) || 
    layer.floralsUsed.includes(p.floral.visualIntelligence?.designIntelligence?.designRole)
  );
  
  const floralDescriptions = relevantFlorals.map(p => {
    const floral = p.floral;
    const color = floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name || floral.productSpecs?.color;
    const visualDesc = floral.visualIntelligence?.description?.substring(0, 200) || floral.description;
    
    return `${p.position.quantity}x ${floral.name} (${color}, ${floral.dimensions.length}") positioned at ${p.position.angle}° with ${p.position.depth[0]}-${p.position.depth[1]}" depth`;
  }).join('; ');
  
  return `Close-up instructional product photography showing wreath assembly step ${layer.layerNumber}: ${layer.name}. 

Florals being added: ${floralDescriptions}.

Hands visible demonstrating ${layer.technique || 'wire attachment technique'} with ${layer.tools || '24-gauge floral wire'}. ${layer.description}.

Clear detail on ${relevantFlorals[0]?.floral.visualIntelligence?.visualProperties?.texture || 'floral texture'}, natural positioning following plant growth patterns. Shot with macro lens, f/4 aperture, soft natural light from upper left, professional tutorial aesthetic, 8K resolution, instructional clarity.`;
}

export default function EmpathyEngineV2() {
  const [currentStep, setCurrentStep] = useState(0);
  const [floralInventory, setFloralInventory] = useState([]);
  const [pipelineData, setPipelineData] = useState({
    emotionalInput: '',
    characterStory: null,
    livingSpace: null,
    selectedFlorals: [],
    wreathPositioning: [],
    wreathImagePrompts: {},
    assemblyGuide: null
  });

  // Load actual inventory JSON
  const handleInventoryUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    const text = await file.text();
    const inventory = JSON.parse(text);
    setFloralInventory(inventory);
    
    console.log(`Loaded ${inventory.length} florals from inventory`);
  };

  const steps = [
    { id: 'input', name: 'Load Inventory + Emotion', icon: Heart },
    { id: 'character', name: 'Character Story', icon: User },
    { id: 'space', name: 'Living Space', icon: Home },
    { id: 'selection', name: 'AI Floral Selection', icon: Sparkles },
    { id: 'wreath', name: 'Wreath Rendering', icon: Flower2 },
    { id: 'assembly', name: 'Assembly Guide', icon: Camera },
    { id: 'package', name: 'Product Package', icon: Package }
  ];

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '2rem'
    }}>
      {/* Header */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto 2rem',
        textAlign: 'center'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '1rem',
          marginBottom: '1rem'
        }}>
          <Sparkles size={40} color="white" />
          <h1 style={{
            fontSize: '3.5rem',
            fontWeight: '900',
            color: 'white',
            margin: 0,
            letterSpacing: '-0.02em'
          }}>
            Empathy Engine V2
          </h1>
        </div>
        <p style={{
          fontSize: '1.25rem',
          color: 'rgba(255,255,255,0.95)',
          margin: 0,
          fontWeight: '500'
        }}>
          Using Your Real Floral Inventory with Emotional Intelligence
        </p>
      </div>

      {/* Progress Stepper */}
      <div style={{
        maxWidth: '1400px',
        margin: '0 auto 2rem',
        background: 'white',
        borderRadius: '20px',
        padding: '2rem',
        boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          position: 'relative'
        }}>
          {/* Progress Line */}
          <div style={{
            position: 'absolute',
            top: '20px',
            left: '40px',
            right: '40px',
            height: '4px',
            background: '#e5e7eb',
            zIndex: 0
          }}>
            <div style={{
              height: '100%',
              background: 'linear-gradient(90deg, #667eea, #764ba2)',
              width: `${(currentStep / (steps.length - 1)) * 100}%`,
              transition: 'width 0.5s ease'
            }} />
          </div>

          {/* Steps */}
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isComplete = index < currentStep;
            const isCurrent = index === currentStep;
            
            return (
              <div
                key={step.id}
                onClick={() => index <= currentStep && setCurrentStep(index)}
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  gap: '0.5rem',
                  cursor: index <= currentStep ? 'pointer' : 'default',
                  position: 'relative',
                  zIndex: 1,
                  opacity: index > currentStep ? 0.5 : 1
                }}
              >
                <div style={{
                  width: '48px',
                  height: '48px',
                  borderRadius: '50%',
                  background: isComplete || isCurrent 
                    ? 'linear-gradient(135deg, #667eea, #764ba2)'
                    : '#e5e7eb',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.3s',
                  transform: isCurrent ? 'scale(1.1)' : 'scale(1)',
                  boxShadow: isCurrent ? '0 8px 20px rgba(102,126,234,0.4)' : 'none'
                }}>
                  <Icon size={24} color={isComplete || isCurrent ? 'white' : '#9ca3af'} />
                </div>
                <span style={{
                  fontSize: '0.75rem',
                  fontWeight: isCurrent ? '700' : '600',
                  color: isCurrent ? '#667eea' : '#6b7280',
                  textAlign: 'center',
                  maxWidth: '90px'
                }}>
                  {step.name}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
        {currentStep === 0 && (
          <StepInventoryLoad 
            floralInventory={floralInventory}
            handleInventoryUpload={handleInventoryUpload}
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(1)}
          />
        )}
        
        {currentStep === 1 && (
          <StepCharacterV2
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(2)}
            onBack={() => setCurrentStep(0)}
          />
        )}
        
        {currentStep === 2 && (
          <StepLivingSpaceV2
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(3)}
            onBack={() => setCurrentStep(1)}
          />
        )}
        
        {currentStep === 3 && (
          <StepFloralSelection
            floralInventory={floralInventory}
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(4)}
            onBack={() => setCurrentStep(2)}
          />
        )}
        
        {currentStep === 4 && (
          <StepWreathRendering
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(5)}
            onBack={() => setCurrentStep(3)}
          />
        )}
        
        {currentStep === 5 && (
          <StepAssemblyV2
            pipelineData={pipelineData}
            setPipelineData={setPipelineData}
            onNext={() => setCurrentStep(6)}
            onBack={() => setCurrentStep(4)}
          />
        )}
        
        {currentStep === 6 && (
          <StepPackageV2
            pipelineData={pipelineData}
            onBack={() => setCurrentStep(5)}
          />
        )}
      </div>
    </div>
  );
}

// ============================================
// STEP 0: INVENTORY LOAD + EMOTIONAL INPUT
// ============================================

function StepInventoryLoad({ floralInventory, handleInventoryUpload, pipelineData, setPipelineData, onNext }) {
  const [emotionalInput, setEmotionalInput] = useState(pipelineData.emotionalInput || '');
  const fileInputRef = useRef(null);

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, emotionalInput }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Load Your Floral Inventory JSON
      </h2>

      {/* Inventory Upload */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{
          display: 'block',
          fontSize: '1rem',
          fontWeight: '700',
          marginBottom: '0.5rem',
          color: '#1f2937'
        }}>
          Upload enhanced_catalog_v2.json
        </label>
        
        <div
          onClick={() => fileInputRef.current?.click()}
          style={{
            border: floralInventory.length > 0 ? '2px solid #10b981' : '2px dashed #d1d5db',
            borderRadius: '12px',
            padding: '2rem',
            textAlign: 'center',
            cursor: 'pointer',
            background: floralInventory.length > 0 ? '#f0fdf4' : '#f9fafb',
            transition: 'all 0.2s'
          }}
        >
          <Upload size={48} color={floralInventory.length > 0 ? '#10b981' : '#9ca3af'} style={{ margin: '0 auto 1rem' }} />
          {floralInventory.length > 0 ? (
            <>
              <p style={{ fontSize: '1.125rem', fontWeight: '600', color: '#166534', margin: '0 0 0.5rem' }}>
                ✓ {floralInventory.length} florals loaded
              </p>
              <p style={{ fontSize: '0.875rem', color: '#15803d', margin: 0 }}>
                With emotions, geometry, colors, and spatial intelligence
              </p>
            </>
          ) : (
            <>
              <p style={{ fontSize: '1.125rem', fontWeight: '600', color: '#374151', margin: '0 0 0.5rem' }}>
                Click to upload floral inventory
              </p>
              <p style={{ fontSize: '0.875rem', color: '#6b7280', margin: 0 }}>
                JSON format with emotional attributes
              </p>
            </>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleInventoryUpload}
          style={{ display: 'none' }}
        />
      </div>

      {/* Emotional Input */}
      <div style={{ marginBottom: '2rem' }}>
        <label style={{
          display: 'block',
          fontSize: '1rem',
          fontWeight: '700',
          marginBottom: '0.5rem',
          color: '#1f2937'
        }}>
          Emotional Intent
        </label>
        <textarea
          value={emotionalInput}
          onChange={(e) => setEmotionalInput(e.target.value)}
          placeholder="Example: Quiet hope during late winter, anticipation of spring's renewal, patient observation of nature's cycles..."
          style={{
            width: '100%',
            minHeight: '120px',
            padding: '1rem',
            border: '2px solid #e5e7eb',
            borderRadius: '12px',
            fontSize: '1rem',
            fontFamily: 'inherit',
            resize: 'vertical'
          }}
        />
      </div>

      {/* Next Button */}
      <button
        onClick={handleNext}
        disabled={floralInventory.length === 0 || !emotionalInput}
        style={{
          width: '100%',
          padding: '1.25rem',
          background: (floralInventory.length > 0 && emotionalInput)
            ? 'linear-gradient(135deg, #667eea, #764ba2)'
            : '#e5e7eb',
          color: 'white',
          border: 'none',
          borderRadius: '12px',
          fontSize: '1.125rem',
          fontWeight: '700',
          cursor: (floralInventory.length > 0 && emotionalInput) ? 'pointer' : 'not-allowed',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem'
        }}
      >
        Generate Character Story
        <ChevronRight size={24} />
      </button>
    </div>
  );
}

// ============================================
// STEP 1: CHARACTER STORY (Enhanced)
// ============================================

function StepCharacterV2({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [characterStory, setCharacterStory] = useState(pipelineData.characterStory);

  const generateCharacter = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // This would call Claude API with emotional input
    const story = {
      name: "Eleanor Hayes",
      age: "Early 60s",
      occupation: "Retired Botanical Illustrator",
      location: "Converted barn studio in rural Vermont",
      personality: "Contemplative, patient, deeply attuned to seasonal cycles",
      aesthetic: "Minimalist with intention, wabi-sabi restraint",
      emotionalKeywords: ["contemplative", "hopeful", "patient", "natural", "elegant", "sophisticated"],
      season: "winter",
      mood: "contemplative and quietly hopeful",
      wreathCharacteristics: "Sparse, asymmetric, intentional negative space, winter botanicals",
      emotionalColors: ["Soft white", "Pearl gray", "Pale blush pink", "Cool blue-gray"],
      narrative: `Eleanor lives alone in a converted barn at the edge of a forest. She spent 40 years illustrating botanical reference books before retiring to focus on observational art. Her studio is sparse not from lack of resources but from decades of refining what truly matters.

She rises early, walks the same paths each morning, noting the exact moment when buds swell, when snow melts from specific stones. Her work is slow, deliberate, meditative.

The late winter months are her favorite. Others see dormancy; she sees preparation. The pussy willows represent her philosophy: patience rewarded, life emerging from apparent emptiness.`
    };
    
    setCharacterStory(story);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, characterStory }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        Character Story: Who Lives Here?
      </h2>

      {!characterStory ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <User size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <p style={{ fontSize: '1.125rem', color: '#6b7280', marginBottom: '2rem' }}>
            Generate character based on: "{pipelineData.emotionalInput?.substring(0, 100)}..."
          </p>
          <button
            onClick={generateCharacter}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'inline-flex',
              alignItems: 'center',
              gap: '0.5rem'
            }}
          >
            <Wand2 size={20} />
            {isGenerating ? 'Generating...' : 'Generate Character'}
          </button>
        </div>
      ) : (
        <div>
          <div style={{
            background: '#f0fdf4',
            borderRadius: '16px',
            padding: '2rem',
            marginBottom: '2rem'
          }}>
            <h3 style={{ fontSize: '1.75rem', fontWeight: '800', marginBottom: '0.5rem', color: '#166534' }}>
              {characterStory.name}
            </h3>
            <p style={{ fontSize: '1rem', color: '#15803d', marginBottom: '1.5rem' }}>
              {characterStory.age} • {characterStory.occupation}
            </p>
            
            <div style={{
              background: 'white',
              padding: '1.5rem',
              borderRadius: '12px',
              marginBottom: '1rem'
            }}>
              <p style={{ fontSize: '0.9375rem', lineHeight: '1.7', color: '#374151', whiteSpace: 'pre-line', margin: 0 }}>
                {characterStory.narrative}
              </p>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', marginTop: '1rem' }}>
              <strong style={{ width: '100%', fontSize: '0.875rem', color: '#166534' }}>Emotional Keywords:</strong>
              {characterStory.emotionalKeywords.map((keyword, i) => (
                <span key={i} style={{
                  padding: '0.375rem 0.75rem',
                  background: '#dcfce7',
                  color: '#166534',
                  borderRadius: '6px',
                  fontSize: '0.8125rem',
                  fontWeight: '600'
                }}>
                  {keyword}
                </span>
              ))}
            </div>
          </div>

          <div style={{ display: 'flex', gap: '1rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Generate Living Space
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// STEP 2: LIVING SPACE (Enhanced with character data)
// ============================================

function StepLivingSpaceV2({ pipelineData, setPipelineData, onNext, onBack }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [livingSpace, setLivingSpace] = useState(pipelineData.livingSpace);

  const generateSpace = async () => {
    setIsGenerating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const character = pipelineData.characterStory;
    
    const space = {
      wallColor: 'soft pearl gray',
      lightingDescription: 'Soft overcast afternoon light from tall windows, even shadowless illumination, cool temperature (5500K)',
      colorDescription: `${character.emotionalColors.join(', ')} as primary palette with natural materials`,
      scenePrompt: `Minimalist ${character.location}, ${character.aesthetic} design. ${character.mood} atmosphere. ${character.wreathCharacteristics} styling throughout.`
    };
    
    setLivingSpace(space);
    setIsGenerating(false);
  };

  const handleNext = () => {
    setPipelineData(prev => ({ ...prev, livingSpace }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        {pipelineData.characterStory?.name}'s Living Space
      </h2>

      {!livingSpace ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Home size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <button
            onClick={generateSpace}
            disabled={isGenerating}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}
          >
            {isGenerating ? 'Generating Space...' : 'Generate Living Space'}
          </button>
        </div>
      ) : (
        <div>
          <div style={{
            background: '#f3f4f6',
            borderRadius: '16px',
            padding: '1.5rem',
            marginBottom: '2rem'
          }}>
            <p style={{ fontSize: '1rem', lineHeight: '1.7', color: '#374151', margin: 0 }}>
              {livingSpace.scenePrompt}
            </p>
          </div>

          <div style={{ display: 'flex', gap: '1rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Select Florals from Inventory
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================
// STEP 3: AI FLORAL SELECTION (Using Real Inventory!)
// ============================================

function StepFloralSelection({ floralInventory, pipelineData, setPipelineData, onNext, onBack }) {
  const [isSelecting, setIsSelecting] = useState(false);
  const [selectedFlorals, setSelectedFlorals] = useState(pipelineData.selectedFlorals || []);

  const runSelection = async () => {
    setIsSelecting(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Run actual selection algorithm
    const selected = selectFloralsFromInventory(
      floralInventory,
      pipelineData.characterStory,
      pipelineData.livingSpace
    );
    
    setSelectedFlorals(selected);
    setIsSelecting(false);
  };

  const handleNext = () => {
    // Generate positioning
    const positioning = generateWreathPositioning(selectedFlorals);
    
    setPipelineData(prev => ({
      ...prev,
      selectedFlorals,
      wreathPositioning: positioning
    }));
    onNext();
  };

  return (
    <div style={{
      background: 'white',
      borderRadius: '20px',
      padding: '3rem',
      boxShadow: '0 20px 60px rgba(0,0,0,0.2)',
      maxHeight: '80vh',
      overflowY: 'auto'
    }}>
      <h2 style={{
        fontSize: '2rem',
        fontWeight: '800',
        marginBottom: '1rem',
        background: 'linear-gradient(135deg, #667eea, #764ba2)',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent'
      }}>
        AI Floral Selection from Your Inventory
      </h2>

      <p style={{ fontSize: '1rem', color: '#6b7280', marginBottom: '2rem' }}>
        Analyzing {floralInventory.length} florals against {pipelineData.characterStory?.name}'s emotional profile...
      </p>

      {selectedFlorals.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '3rem 0' }}>
          <Sparkles size={64} color="#d1d5db" style={{ margin: '0 auto 1.5rem' }} />
          <button
            onClick={runSelection}
            disabled={isSelecting}
            style={{
              padding: '1rem 2rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1.125rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}
          >
            {isSelecting ? 'Analyzing Inventory...' : 'Run AI Selection'}
          </button>
        </div>
      ) : (
        <div>
          <div style={{
            background: '#f0fdf4',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '2rem'
          }}>
            <div style={{ fontSize: '1.125rem', fontWeight: '700', color: '#166534', marginBottom: '0.5rem' }}>
              ✓ Selected {selectedFlorals.length} florals with {selectedFlorals.reduce((sum, f) => sum + f.selectionScore, 0)} total match score
            </div>
          </div>

          {/* Selected Florals Display */}
          <div style={{ display: 'grid', gap: '1rem', marginBottom: '2rem' }}>
            {selectedFlorals.map((floral, index) => (
              <div key={floral.sku} style={{
                background: '#f9fafb',
                borderRadius: '12px',
                padding: '1rem',
                display: 'grid',
                gridTemplateColumns: '100px 1fr auto',
                gap: '1rem',
                alignItems: 'start'
              }}>
                {/* Image */}
                <div style={{
                  width: '100px',
                  height: '100px',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  background: '#e5e7eb'
                }}>
                  {floral.images?.main ? (
                    <img 
                      src={floral.images.main} 
                      alt={floral.name}
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                  ) : (
                    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <Flower2 size={32} color="#9ca3af" />
                    </div>
                  )}
                </div>

                {/* Info */}
                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: '700', margin: '0 0 0.5rem', color: '#1f2937' }}>
                    {floral.name}
                  </h4>
                  
                  <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.75rem', flexWrap: 'wrap' }}>
                    {floral.visualIntelligence?.designIntelligence?.emotionalAttributes?.map((attr, i) => (
                      <span key={i} style={{
                        padding: '0.25rem 0.5rem',
                        background: '#ede9fe',
                        color: '#5b21b6',
                        borderRadius: '4px',
                        fontSize: '0.75rem',
                        fontWeight: '600'
                      }}>
                        {attr}
                      </span>
                    ))}
                  </div>

                  <div style={{ fontSize: '0.8125rem', color: '#6b7280', marginBottom: '0.5rem' }}>
                    <strong>Color:</strong> {floral.visualIntelligence?.visualProperties?.colorProfile?.primary?.name || floral.productSpecs?.color}
                    {' • '}
                    <strong>Role:</strong> {floral.visualIntelligence?.designIntelligence?.designRole}
                    {' • '}
                    <strong>Size:</strong> {floral.dimensions?.length}"
                  </div>

                  {floral.selectionReasons?.length > 0 && (
                    <div style={{ fontSize: '0.75rem', color: '#16a34a', fontStyle: 'italic' }}>
                      {floral.selectionReasons[0]}
                    </div>
                  )}
                </div>

                {/* Score */}
                <div style={{
                  background: '#667eea',
                  color: 'white',
                  padding: '0.5rem 1rem',
                  borderRadius: '8px',
                  textAlign: 'center',
                  minWidth: '70px'
                }}>
                  <div style={{ fontSize: '1.5rem', fontWeight: '900' }}>{floral.selectionScore}</div>
                  <div style={{ fontSize: '0.625rem', opacity: 0.9 }}>MATCH</div>
                </div>
              </div>
            ))}
          </div>

          {/* Navigation */}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button onClick={onBack} style={{
              flex: 1,
              padding: '1rem',
              background: '#f3f4f6',
              color: '#374151',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer'
            }}>
              Back
            </button>
            <button onClick={handleNext} style={{
              flex: 2,
              padding: '1rem',
              background: 'linear-gradient(135deg, #667eea, #764ba2)',
              color: 'white',
              border: 'none',
              borderRadius: '12px',
              fontSize: '1rem',
              fontWeight: '700',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem'
            }}>
              Generate Wreath Rendering
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// Continue with remaining steps in next response...
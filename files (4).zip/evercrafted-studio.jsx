import { useState, useEffect, useRef } from "react";

// ─────────────────────────────────────────────────────────────
// CSS
// ─────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=DM+Sans:wght@300;400;500&family=DM+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;}
.intent{min-height:100vh;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 22px;}
.intent-mark{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:#8A7142;margin-bottom:34px;}
.intent-title{font-family:'Cormorant Garamond',serif;font-size:46px;font-weight:400;font-style:italic;color:#1A1814;text-align:center;line-height:1.08;margin-bottom:14px;max-width:580px;}
.intent-sub{font-size:13.5px;color:#5A5240;text-align:center;margin-bottom:48px;max-width:480px;line-height:1.7;}
.intent-form{width:100%;max-width:600px;display:flex;flex-direction:column;gap:12px;}
.intent-ta{width:100%;background:#fff;border:1px solid #E2DACB;border-radius:5px;padding:20px 22px;color:#1A1814;font-family:'Cormorant Garamond',serif;font-size:18px;font-style:italic;line-height:1.65;resize:vertical;min-height:100px;outline:none;transition:border-color .15s;}
.intent-ta:focus{border-color:#B08D45;box-shadow:0 0 0 3px rgba(176,141,69,.08);}
.intent-ta::placeholder{color:#C8B888;}
.intent-btn{background:#b5703a;color:white;border:none;border-radius:5px;padding:14px 28px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:500;letter-spacing:.06em;cursor:pointer;transition:background .14s;align-self:flex-end;}
.intent-btn:hover:not(:disabled){background:#a06035;}
.intent-btn:disabled{opacity:.38;cursor:not-allowed;}
.intent-err{background:rgba(180,55,55,.07);border:.5px solid rgba(180,55,55,.2);border-radius:4px;padding:13px 16px;color:#943030;font-size:12.5px;line-height:1.6;}
.intent-hint{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;color:#C8B888;text-align:center;}
.intent-saved-link{background:none;border:.5px solid #D8C8A0;border-radius:4px;padding:10px 18px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;cursor:pointer;transition:all .18s;align-self:center;}
.intent-saved-link:hover{border-color:#B08D45;color:#B08D45;}
.loading{min-height:100vh;background:#F7F4EE;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:24px;}
.loading-g{font-family:'Cormorant Garamond',serif;font-size:52px;color:#B08D45;animation:breathe 2.6s ease-in-out infinite;}
@keyframes breathe{0%,100%{opacity:.3;transform:scale(1);}50%{opacity:1;transform:scale(1.07);}}
.loading-m{font-size:13px;color:#8A7142;letter-spacing:.04em;text-align:center;min-height:20px;}
.loading-i{font-family:'Cormorant Garamond',serif;font-size:15px;font-style:italic;color:#C8B888;max-width:460px;text-align:center;line-height:1.55;}
.dash{background:#F7F4EE;color:#1A1814;min-height:100vh;}
.dash-hdr{padding:28px 32px 0;border-bottom:1px solid #E2DACB;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);}
.dash-hdr-top{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;}
.dash-eye{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.dash-name{font-family:'Cormorant Garamond',serif;font-size:32px;font-weight:500;line-height:1.1;margin-bottom:4px;}
.dash-sub{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:15px;color:#8A7142;margin-bottom:18px;}
.dash-hdr-actions{display:flex;gap:8px;flex-shrink:0;margin-top:4px;flex-wrap:wrap;justify-content:flex-end;}
.reset-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;padding:6px 13px;background:none;border:.5px solid #C8B888;color:#8A7142;cursor:pointer;border-radius:2px;transition:all .18s;white-space:nowrap;}
.reset-btn:hover{border-color:#B08D45;color:#B08D45;}
.save-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;padding:6px 14px;background:none;border:.5px solid #B08D45;color:#B08D45;cursor:pointer;border-radius:2px;transition:all .18s;white-space:nowrap;}
.save-btn:hover:not(:disabled){background:rgba(176,141,69,.08);}
.save-btn.saved{border-color:#3D7A4A;color:#3D7A4A;}
.save-btn:disabled{opacity:.5;cursor:not-allowed;}
.tabs{display:flex;gap:0;overflow-x:auto;scrollbar-width:none;}
.tabs::-webkit-scrollbar{display:none;}
.tab-btn{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.1em;text-transform:uppercase;padding:10px 14px;background:none;border:none;cursor:pointer;color:#8A7142;border-bottom:2px solid transparent;white-space:nowrap;transition:all .18s;}
.tab-btn:hover{color:#1A1814;}
.tab-btn.active{color:#1A1814;border-bottom-color:#B08D45;}
.dash-body{padding:30px 32px;max-width:1100px;}
.saved-screen{min-height:100vh;background:#F7F4EE;}
.saved-hdr{padding:28px 32px;border-bottom:1px solid #E2DACB;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);display:flex;align-items:flex-start;justify-content:space-between;gap:16px;}
.saved-hdr-eye{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.saved-hdr-title{font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:500;color:#1A1814;line-height:1.1;}
.saved-body{padding:30px 32px;max-width:980px;}
.saved-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.saved-card{background:#fff;border:.5px solid #E2DACB;border-radius:5px;padding:18px 20px;}
.saved-card-name{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:3px;color:#1A1814;}
.saved-card-tag{font-size:11px;color:#8A7142;margin-bottom:10px;font-family:'Cormorant Garamond',serif;font-style:italic;}
.saved-card-dots{display:flex;gap:5px;margin-bottom:10px;}
.saved-card-dot{width:13px;height:13px;border-radius:50%;border:.5px solid rgba(0,0,0,.07);}
.saved-card-meta{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:#C8B888;margin-bottom:14px;}
.saved-card-actions{display:flex;gap:8px;}
.saved-load-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;padding:6px 14px;background:#b5703a;color:white;border:none;border-radius:2px;cursor:pointer;transition:background .14s;}
.saved-load-btn:hover{background:#a06035;}
.saved-load-btn:disabled{opacity:.5;cursor:not-allowed;}
.saved-del-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;padding:6px 12px;background:none;border:.5px solid #E2DACB;color:#C8B888;border-radius:2px;cursor:pointer;transition:all .14s;}
.saved-del-btn:hover{border-color:rgba(180,55,55,.3);color:#943030;}
.saved-empty{text-align:center;padding:70px 20px;}
.saved-empty-g{font-family:'Cormorant Garamond',serif;font-size:34px;font-style:italic;color:#C8B888;margin-bottom:10px;}
.saved-empty-t{font-size:13px;color:#8A7142;line-height:1.6;}
.eyebrow{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:14px;}
.pull{background:#EFE9D8;border-left:3px solid #B08D45;padding:18px 22px;margin-bottom:26px;}
.pull p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:18px;line-height:1.62;color:#332B1A;}
.hr{border:none;border-top:1px solid #E2DACB;margin:24px 0;}
.note{background:#FFFBF0;border:.5px solid #E8D49C;border-radius:4px;padding:12px 15px;margin-bottom:18px;font-size:12px;color:#4A3E20;line-height:1.65;}
.note strong{font-weight:500;}
.sec-title{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;margin-bottom:12px;}
.swatch-row{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;}
.swatch{flex:1;min-width:90px;border-radius:4px;overflow:hidden;border:.5px solid #E2DACB;}
.swatch-color{height:48px;}
.swatch-label{background:#fff;padding:7px 9px;}
.swatch-name{font-size:11px;font-weight:500;margin-bottom:1px;}
.swatch-hex{font-family:'DM Mono',monospace;font-size:9px;color:#8A7142;}
.profile-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:24px;}
.profile-card{background:#fff;border:.5px solid #E2DACB;padding:12px 14px;border-radius:4px;}
.profile-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;margin-bottom:4px;}
.profile-val{font-size:12.5px;line-height:1.5;color:#1A1814;}
.sig-block{background:#1A1814;border-radius:5px;padding:20px 24px;margin-bottom:24px;}
.sig-row{display:flex;gap:12px;padding:7px 0;border-bottom:.5px solid #2E2A22;}
.sig-row:last-child{border-bottom:none;}
.sig-lbl{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.08em;text-transform:uppercase;color:#B08D45;min-width:150px;flex-shrink:0;padding-top:2px;}
.sig-val{color:#E0D8C4;line-height:1.55;font-family:'Cormorant Garamond',serif;font-size:14px;}
.price-bar{background:#1A1814;border-radius:5px;padding:16px 20px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:24px;}
.pb-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.pb-val{font-family:'DM Mono',monospace;font-size:17px;color:#E0D8C4;}
.role-list{display:flex;flex-direction:column;gap:9px;margin-bottom:24px;}
.role-card{background:#fff;border:.5px solid #E2DACB;border-left:4px solid;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap;}
.role-left{flex:1;min-width:200px;}
.role-tag{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.role-name{font-family:'Cormorant Garamond',serif;font-size:17px;font-weight:600;margin-bottom:3px;}
.role-form{font-size:11px;color:#5A5240;margin-bottom:5px;}
.role-meta{font-size:11px;color:#5A5240;line-height:1.55;}
.role-price{font-family:'DM Mono',monospace;font-size:21px;font-weight:500;color:#1A1814;white-space:nowrap;flex-shrink:0;}
.score-strip{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.score-card{flex:1;min-width:80px;background:#1A1814;border-radius:4px;padding:12px 14px;text-align:center;}
.score-val{font-family:'DM Mono',monospace;font-size:18px;color:#B08D45;margin-bottom:3px;}
.score-val.big{font-family:'Cormorant Garamond',serif;font-size:14px;font-style:italic;}
.score-lbl-sm{font-family:'DM Mono',monospace;font-size:7.5px;letter-spacing:.1em;text-transform:uppercase;color:#5A5248;}
.thread-card{background:#fff;border:.5px solid #E2DACB;padding:13px 16px;border-radius:4px;margin-bottom:9px;}
.thread-verdict{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;padding:2px 8px;border-radius:2px;display:inline-block;margin-bottom:5px;}
.thread-verdict.strong{background:rgba(61,122,74,.1);color:#3D7A4A;}
.thread-verdict.needs-attention{background:rgba(180,140,40,.1);color:#8A6A10;}
.thread-verdict.critical{background:rgba(180,55,55,.1);color:#943030;}
.thread-name{font-family:'Cormorant Garamond',serif;font-weight:600;font-size:15px;margin-bottom:4px;}
.thread-body{font-size:11.5px;color:#5A5240;line-height:1.62;}
.chk-list{display:flex;flex-direction:column;gap:7px;margin-bottom:20px;}
.chk-row{display:flex;align-items:center;gap:9px;font-size:12px;color:#332B1A;}
.chk-icon{font-size:13px;flex-shrink:0;}
.chk-icon.ok{color:#3D7A4A;}
.chk-icon.fail{color:#943030;}
.timeline{display:flex;flex-direction:column;gap:0;margin-bottom:24px;}
.phase-card{border-left:3px solid #B08D45;padding:4px 0 24px 20px;position:relative;}
.phase-card::before{content:'';position:absolute;left:-7px;top:5px;width:11px;height:11px;border-radius:50%;background:#B08D45;}
.phase-card:last-child{padding-bottom:0;}
.phase-num{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.phase-title{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:7px;}
.phase-row{font-size:12px;color:#5A5240;line-height:1.65;margin-bottom:2px;}
.phase-row b{color:#332B1A;font-weight:500;}
.system-card{background:#fff;border:.5px solid #E2DACB;padding:14px 18px;border-radius:4px;margin-bottom:10px;}
.system-name{font-family:'Cormorant Garamond',serif;font-size:16px;font-weight:600;margin-bottom:7px;color:#B08D45;}
.system-flow{font-size:12px;color:#332B1A;line-height:1.7;}
.bundle-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:24px;}
.bundle-card{background:#fff;border:.5px solid #E2DACB;border-radius:4px;padding:14px 16px;}
.bundle-name{font-family:'Cormorant Garamond',serif;font-size:15px;font-weight:600;margin-bottom:3px;}
.bundle-type{font-family:'DM Mono',monospace;font-size:7.5px;letter-spacing:.1em;text-transform:uppercase;color:#8A7142;margin-bottom:7px;}
.bundle-contents{font-size:11px;color:#5A5240;line-height:1.55;margin-bottom:9px;}
.bundle-pr{display:flex;align-items:baseline;gap:7px;margin-bottom:3px;}
.bundle-was{font-family:'DM Mono',monospace;font-size:10px;color:#A89878;text-decoration:line-through;}
.bundle-now{font-family:'DM Mono',monospace;font-size:16px;color:#B08D45;font-weight:500;}
.bundle-save{font-family:'DM Mono',monospace;font-size:8.5px;color:#3D7A4A;}
.merch-block{margin-bottom:20px;}
.merch-title{font-family:'Cormorant Garamond',serif;font-size:15px;font-weight:600;margin-bottom:5px;}
.merch-body{font-size:12px;color:#5A5240;line-height:1.65;}
.flow-list{list-style:none;counter-reset:fl;margin-bottom:24px;}
.flow-list li{counter-increment:fl;padding:8px 0 8px 30px;border-bottom:.5px solid #EDE6D4;position:relative;font-size:12px;color:#332B1A;line-height:1.55;}
.flow-list li::before{content:counter(fl);position:absolute;left:0;top:8px;font-family:'DM Mono',monospace;font-size:9px;color:#B08D45;border:.5px solid #B08D45;border-radius:50%;width:17px;height:17px;display:flex;align-items:center;justify-content:center;}
.genome{background:#EFE9D8;border:.5px solid #D8C8A0;border-radius:4px;padding:12px 15px;margin-bottom:13px;}
.genome-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.genome-str{font-family:'DM Mono',monospace;font-size:9.5px;color:#6A5420;word-break:break-all;line-height:1.6;}
.prompt-block{background:#1A1814;border-radius:5px;margin-bottom:14px;overflow:hidden;}
.prompt-hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #2E2A24;gap:10px;}
.prompt-lbl{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:#9A8860;flex:1;}
.copy-btn{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.08em;text-transform:uppercase;padding:4px 10px;background:none;border:.5px solid #3A3428;color:#9A8860;cursor:pointer;border-radius:2px;transition:all .18s;}
.copy-btn:hover,.copy-btn.ok{border-color:#B08D45;color:#B08D45;}
.prompt-txt{font-family:'DM Mono',monospace;font-size:10px;color:#D4C8B0;padding:14px;line-height:1.72;white-space:pre-wrap;word-break:break-word;}
.render-hdr{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:4px;}
.render-sub{font-size:11.5px;color:#8A7142;margin-bottom:13px;}
.condensed-card{background:#fff;border:.5px solid #E2DACB;padding:12px 16px;border-radius:4px;margin-bottom:9px;}
.condensed-name{font-weight:500;font-size:12.5px;margin-bottom:4px;}
.condensed-note{font-size:11px;color:#5A5240;line-height:1.55;}
.guide-thesis{background:#EFE9D8;border-left:3px solid #B08D45;padding:18px 22px;margin-bottom:28px;}
.guide-thesis p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:17px;line-height:1.62;color:#332B1A;}
.guide-section{margin-bottom:32px;}
.guide-h2{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;margin-bottom:10px;padding-bottom:8px;border-bottom:.5px solid #E2DACB;color:#1A1814;}
.guide-h3{font-family:'DM Sans',sans-serif;font-size:12px;font-weight:500;color:#1A1814;margin:14px 0 6px;}
.guide-p{font-size:12.5px;color:#332B1A;line-height:1.72;margin-bottom:10px;}
.guide-ul{padding-left:18px;margin-bottom:12px;}
.guide-ul li{font-size:12px;color:#332B1A;line-height:1.65;margin-bottom:4px;}
.guide-code{background:#1A1814;border-radius:4px;padding:13px 16px;margin:6px 0 14px;font-family:'DM Mono',monospace;font-size:10px;color:#D4C8B0;line-height:1.7;white-space:pre-wrap;word-break:break-word;}
.guide-wrong{background:rgba(180,55,55,.06);border:.5px solid rgba(180,55,55,.15);border-radius:4px;padding:10px 14px;margin-bottom:6px;font-family:'DM Mono',monospace;font-size:10px;color:#7A3A36;line-height:1.6;}
.guide-right{background:rgba(61,122,74,.06);border:.5px solid rgba(61,122,74,.18);border-radius:4px;padding:10px 14px;margin-bottom:14px;font-family:'DM Mono',monospace;font-size:10px;color:#2A5A34;line-height:1.6;}
.guide-label{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:4px;}
.ref-table{width:100%;border-collapse:collapse;margin-bottom:24px;}
.ref-table th{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;padding:8px 12px;border-bottom:1.5px solid #E2DACB;text-align:left;background:#F7F4EE;}
.ref-table td{padding:9px 12px;border-bottom:.5px solid #EDE6D4;font-size:11.5px;color:#332B1A;vertical-align:top;line-height:1.55;}
.ref-table tr:last-child td{border-bottom:none;}
.ref-table td:first-child{font-family:'DM Mono',monospace;font-size:10px;color:#1A1814;white-space:nowrap;}
.ref-table td:nth-child(2){color:#5A5240;}
.ref-table td:nth-child(3){color:#3A4A3A;}
.params-grid{display:grid;grid-template-columns:auto 1fr;gap:6px 16px;margin-bottom:16px;font-size:12px;}
.params-key{font-family:'DM Mono',monospace;font-size:10px;color:#B08D45;white-space:nowrap;}
.params-val{color:#332B1A;line-height:1.55;}
.layout-prod-pills{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:20px;}
.lpill{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;padding:5px 12px;border-radius:3px;border:.5px solid #E2DACB;background:none;color:#8A7142;cursor:pointer;transition:all .18s;}
.lpill.active{background:#1A1814;color:#E0D8C4;border-color:#1A1814;}
.layout-controls{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px;align-items:flex-end;}
.lctrl{display:flex;flex-direction:column;gap:5px;}
.lctrl-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;}
.lctrl select,.lctrl input[type=number]{background:#fff;border:.5px solid #E2DACB;border-radius:4px;padding:7px 10px;font-size:12.5px;color:#1A1814;outline:none;font-family:'DM Sans',sans-serif;}
.lctrl select:focus,.lctrl input:focus{border-color:#B08D45;}
.layout-canvas-wrap{display:flex;justify-content:center;margin:16px 0;background:#F6F2EB;border-radius:8px;border:.5px solid #E2DACB;overflow:hidden;}
.vbadge-row{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;}
.vbadge{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.08em;padding:3px 9px;border-radius:3px;display:inline-flex;align-items:center;gap:4px;}
.vbadge.pass{background:rgba(61,122,74,.1);color:#3D7A4A;}
.vbadge.warn{background:rgba(180,140,40,.1);color:#8A6A10;}
.vbadge.flag{background:rgba(180,55,55,.1);color:#943030;}
.vbadge.info{background:rgba(176,141,69,.08);color:#8A6A10;border:.5px solid rgba(176,141,69,.25);}
.design-note-block{background:#EFE9D8;border:.5px solid #D8C8A0;border-radius:4px;padding:12px 15px;margin-bottom:14px;font-family:'DM Mono',monospace;font-size:10px;color:#6A5420;line-height:1.6;}
.activate-btn{background:#1A1814;color:#E0D8C4;border:none;border-radius:4px;padding:9px 20px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;cursor:pointer;transition:background .14s;white-space:nowrap;}
.activate-btn:hover{background:#2E2820;}
.activate-btn.on{background:#1F3326;color:#9FE1CB;}
.ptab-row{display:flex;gap:5px;margin-bottom:10px;flex-wrap:wrap;}
.ptab{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.08em;text-transform:uppercase;padding:5px 12px;border-radius:3px;border:.5px solid #E2DACB;background:none;color:#8A7142;cursor:pointer;transition:all .18s;}
.ptab.active{background:#1A1814;color:#E0D8C4;border-color:#1A1814;}
.bp-status{display:inline-flex;align-items:center;gap:5px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.08em;text-transform:uppercase;padding:2px 9px;border-radius:3px;}
.bp-status.auto{background:rgba(176,141,69,.08);color:#8A6A10;border:.5px solid rgba(176,141,69,.2);}
.bp-status.custom{background:rgba(61,122,74,.08);color:#3D7A4A;border:.5px solid rgba(61,122,74,.2);}
`;

// ─────────────────────────────────────────────────────────────
// TABS & CONSTANTS
// ─────────────────────────────────────────────────────────────
const TABS = [
  { id:"foundation", label:"Foundation"    },
  { id:"hierarchy",  label:"Hierarchy"     },
  { id:"continuity", label:"Continuity"    },
  { id:"release",    label:"Release"       },
  { id:"crosssell",  label:"Cross-Sell"    },
  { id:"merch",      label:"Merchandising" },
  { id:"layout",     label:"Layout"        },
  { id:"render",     label:"Render"        },
  { id:"guide",      label:"Render Guide"  },
];

const MSGS = [
  "Reading your intent…","Mapping emotional architecture…",
  "Assigning hierarchy roles and botanicals…","Threading continuity logic…",
  "Building release strategy…","Composing cross-sell systems…",
  "Building visual merchandising plan…","Finalising the collection package…",
];

// ─────────────────────────────────────────────────────────────
// CIE SYSTEM PROMPT
// ─────────────────────────────────────────────────────────────
const SYSTEM = `You are the Evercrafted Collection Intelligence Engine. Transform any creative intent into a complete luxury faux botanical wreath collection system.

Return ONLY valid JSON. No backticks, no markdown, no preamble, no trailing text. First character must be { and last must be }. All string values must be on a single line — no literal newlines inside values.

=== HARD RULES ===
- NEVER use cherry blossoms or pussy willow
- Every wreath/garland product MUST include integrated warm LED lights
- Composition formulas from ONLY these 12: Crescent, Side Sweep, Bottom Heavy, Diagonal Flow, Twin Cluster, Corner Cluster, Wild Asymmetry, Half Ring, Top Cluster, Spiral Flow, Classic Balanced, Garden Scatter
- Hero product is always a 24-inch door wreath
- Palette: exactly 5 swatches with evocative names
- All product names include the collection name as a prefix

=== HIERARCHY ROLES ===
Premium Anchor (#1F3326): Most complex. Garland or large statement piece.
Hero (#B08D45): 24-inch door wreath. Emotional centerpiece.
Supporting (#5C1A2E): Medium scale. Expands without competing.
Gateway (#8A7142): Entry price. Simpler version of signature form.
Atmospheric Filler (#B8C4BE): Small scale. Candle ring or small swag.
Accent (#F0E8D8): Impulse add. Lowest price.

=== WGS SILENCE ARC NOTE ===
For the silenceArc field on each product, use clock-position language: e.g. "5 to 7 o'clock warm grapevine exposed"

=== JSON SCHEMA ===
{
  "meta":{"name":"Collection Name","tagline":"Season · Atmosphere · N-Product Collection System","pullQuote":"2-3 sentence editorial positioning","season":"season string","atmosphere":"atmosphere name"},
  "palette":[{"name":"Evocative Name","hex":"#XXXXXX"}],
  "foundation":{
    "profile":[["Collection name","value"],["Atmosphere archetype","value"],["Season / timing","value"],["Palette identity","value"],["Movement archetype","value"],["Texture language","value"],["Emotional purchase trigger","value"],["Hero formula","value"],["Variation formulas","value"],["Collection ambition","value"]],
    "signature":[["Emotional Atmosphere","value"],["Structural Movement","value"],["Palette Language","value"],["Density Profile","value"],["Asymmetry Direction","value"],["Texture Language","value"],["Composition Formula","value"],["Silence Arc","value"],["Seasonal Resonance","value"],["Emotion Tags","[\"tag1\", \"tag2\", \"tag3\", \"tag4\", \"tag5\", \"tag6\"]"]]
  },
  "hierarchy":[{
    "role":"Premium Anchor","color":"#1F3326","name":"Full Product Name","form":"6ft mantel garland","formula":"Crescent","scale":"72-inch","price":295,"meta":"2-3 sentence commercial rationale",
    "heroFloral":"exact species, finish, size in inches, count","secondaryFloral":"exact species, finish, size, count","accentMaterials":"all accent elements with size and count","greeneryMix":"specific greenery species","silenceArc":"exact clock range of exposed base"
  }],
  "continuity":{
    "threads":[{"name":"Atmosphere","analysis":"specific analysis","verdict":"strong"},{"name":"Palette","analysis":"analysis","verdict":"strong"},{"name":"Movement","analysis":"analysis","verdict":"strong"},{"name":"Texture","analysis":"analysis","verdict":"strong"}],
    "overallScore":"Excellent","scoreRationale":"one sentence",
    "qualityGates":[{"label":"Atmosphere archetype consistent across all products","pass":true},{"label":"All six hierarchy roles assigned","pass":true},{"label":"No continuity flags unresolved","pass":true},{"label":"Release strategy assigns each product to a phase","pass":true},{"label":"Cross-sell operates at room level","pass":true},{"label":"Photography direction consistent","pass":true}]
  },
  "release":[
    {"phase":"Phase 1","title":"Anticipation","timing":"4-6 weeks before peak","products":"which products","copyHook":"hook","buyerPsychology":"who and why","emotionalArc":"beat"},
    {"phase":"Phase 2","title":"Hero Launch","timing":"2-3 weeks before peak","products":"which products","copyHook":"hook","buyerPsychology":"highest-intent window","emotionalArc":"peak beat"},
    {"phase":"Phase 3","title":"Full Collection","timing":"At season peak","products":"remaining","copyHook":"completion narrative","buyerPsychology":"re-engaging earlier buyers","emotionalArc":"ecosystem completion"},
    {"phase":"Late Season","title":"Sustain","timing":"2-3 weeks post-peak","products":"bundle focus","copyHook":"transition","buyerPsychology":"late-season buyer","emotionalArc":"closing arc"}
  ],
  "crossSell":{
    "systems":[{"name":"Entry System (Door / Porch)","flow":"products and how"},{"name":"Mantel System","flow":"products and how"},{"name":"Living Room / Table System","flow":"products and how"}],
    "bundles":[{"name":"Bundle Name","type":"Room Completion Bundle","contents":"product list","sum":400,"final":360,"pct":0.1}]
  },
  "merch":{"heroShot":"direction","familyGroupings":"direction","individualShots":"direction","detailShots":"direction","shopFrontFlow":["step 1","step 2","step 3","step 4","step 5","step 6"],"displayPrinciples":"principles"}
}

Generate a commercially sophisticated, emotionally intelligent collection. Every section must be specific to this collection. Pull Quote must feel worthy of a luxury brand.`;

// ─────────────────────────────────────────────────────────────
// PIE ENGINE — ported from PIE-App.jsx
// ─────────────────────────────────────────────────────────────
const BASE_WIDTHS = {16:3, 22:4, 24:4.5, 26:5};
const FOOTPRINTS  = {focal:3.5, secondary:2.5, filler:1.5, greenery:2.5};
const ROLE_W      = {focal:1.0, secondary:0.7, filler:0.4, greenery:0.3};
const YIELD_R     = {focal:0.85, secondary:0.90, filler:0.95, greenery:0.90};
const COV_RANGE   = {minimal:[0.25,0.35], classic:[0.33,0.60], lush:[0.55,0.75]};

const PIE_COLORS  = {focal:"#B8784A", secondary:"#9A7040", filler:"#5A8050", greenery:"#3A5E30"};

const FORMULAS = {
  "Crescent":       {start:195,span:120,primary:225,desc:"7:30 mass · exposed vine 12→4 o'clock"},
  "Side Sweep":     {start:195,span:150,primary:255,desc:"Left arc sweeping toward 12 o'clock"},
  "Bottom Heavy":   {start:150,span:180,primary:210,desc:"Full bottom half · strong ground weight"},
  "Diagonal Flow":  {start:195,span:210,primary:240,desc:"Southwest-to-northeast diagonal thrust"},
  "Twin Cluster":   {start:195,span:120,primary:225,twin:30,desc:"Dual focal masses 180° opposed"},
  "Corner Cluster": {start:210,span:90, primary:240,desc:"Severe corner concentration"},
  "Wild Asymmetry": {start:150,span:180,primary:220,desc:"Intentionally broken arc rhythm"},
  "Half Ring":      {start:120,span:180,primary:210,desc:"Clean half ring · open negative crown"},
  "Top Cluster":    {start:300,span:120,primary:0,  desc:"Crown mass · cascading downward flow"},
  "Spiral Flow":    {start:180,span:240,primary:225,desc:"Progressive density spiraling clockwise"},
  "Classic Balanced":{start:60,span:270,primary:180,desc:"Near-complete ring · subtle rest zone"},
  "Garden Scatter": {start:0, span:360,primary:270,scatter:true,desc:"Full 360° organic abundance"},
};

function mulberry32(seed) {
  let a = seed >>> 0;
  return () => { a=(a+0x6D2B79F5)>>>0; let t=Math.imul(a^(a>>>15),1|a); t=Math.imul(t^(t>>>7),61|t)^t; return((t^(t>>>14))>>>0)/4294967296; };
}
function toXY(deg,r,cx,cy) { const rad=deg*Math.PI/180; return {x:cx+r*Math.sin(rad),y:cy-r*Math.cos(rad)}; }
function toClock(deg) { const h=Math.round(((deg%360)+360)%360/30)%12; return h===0?12:h; }

function generateLayout({formula,diameter,coverageClass,seed}) {
  const rng=mulberry32(seed); const bw=BASE_WIDTHS[diameter]||4.5; const rWork=diameter/2-bw/2;
  const dpi=360/(2*Math.PI*rWork); const covR=COV_RANGE[coverageClass]||COV_RANGE.classic;
  const tCov=covR[0]+rng()*(covR[1]-covR[0]); const fc=FORMULAS[formula]||FORMULAS["Crescent"];
  const {start,span,primary}=fc;
  const P=[]; let pid=0; const nxt=()=>`P${++pid}`;
  const ang=t=>((start+span*t)+720)%360;
  P.push({id:nxt(),angle:primary,radius:rWork*(0.90+rng()*0.08),role:"focal",size:diameter<=16?2.5:diameter<=22?3.0:3.5,zone:"mid",layer:"front",slot:"anchor"});
  const dDir=rng()>0.5?1:-1;
  P.push({id:nxt(),angle:(primary+dDir*(18+rng()*22)+360)%360,radius:rWork*(0.82+rng()*0.14),role:"focal",size:diameter<=22?2.0:2.75,zone:"mid",layer:"front",slot:"drama"});
  P.push({id:nxt(),angle:ang(0.72),radius:rWork*(0.74+rng()*0.20),role:"secondary",size:1.8+rng()*0.4,zone:"outer",layer:"mid",slot:"pole"});
  if(fc.twin!==undefined) P.push({id:nxt(),angle:(fc.twin+(rng()-0.5)*20+360)%360,radius:rWork*(0.84+rng()*0.10),role:"focal",size:diameter<=22?2.5:3.0,zone:"mid",layer:"front",slot:"twin"});
  const nSec=fc.scatter?5:3;
  for(let i=0;i<nSec;i++){const a=fc.scatter?rng()*360:ang(0.1+(i/(nSec-1))*0.8); P.push({id:nxt(),angle:(a+(rng()-0.5)*18+360)%360,radius:rWork*(0.68+rng()*0.28),role:"secondary",size:1.4+rng()*0.6,zone:rng()>0.5?"mid":"outer",layer:rng()>0.4?"mid":"back",slot:`sec_${i}`});}
  const nFill=4+Math.floor(rng()*4);
  for(let i=0;i<nFill;i++){const a=fc.scatter?rng()*360:ang(0.05+rng()*0.90); P.push({id:nxt(),angle:(a+(rng()-0.5)*12+360)%360,radius:rWork*(0.55+rng()*0.40),role:"filler",size:0.7+rng()*0.6,zone:"outer",layer:"mid",slot:`fill_${i}`});}
  const nGrn=5+Math.floor(rng()*7);
  for(let i=0;i<nGrn;i++){const a=fc.scatter?rng()*360:ang(rng()); P.push({id:nxt(),angle:(a+(rng()-0.5)*30+360)%360,radius:rWork*(0.50+rng()*0.50),role:"greenery",size:1.2+rng()*1.2,zone:rng()>0.4?"outer":"edge",layer:"back",slot:`green_${i}`});}
  const mf=Object.values(FOOTPRINTS).reduce((a,b)=>a+b,0)/4; const minG=0.7*mf*dpi;
  const kept=[P[0]];
  for(let i=1;i<P.length;i++){const p=P[i];let clash=false;for(const q of kept){let d=Math.abs(p.angle-q.angle);if(d>180)d=360-d;if(d<minG*0.4&&Math.abs(p.radius-q.radius)<0.8&&p.role===q.role){clash=true;break;}}if(!clash)kept.push(p);}
  return {placements:kept,meta:{rWork,dpi,tCov,start,span,primary,formula,diameter,seed}};
}

function validate(placements,meta) {
  const {rWork,dpi,start,span}=meta; const fD={};
  Object.keys(FOOTPRINTS).forEach(r=>{fD[r]=FOOTPRINTS[r]*dpi;});
  const V={};
  const cov=Math.min(placements.reduce((s,p)=>s+(fD[p.role]||8),0)/360,1.0);
  V.R1={label:"R1 Coverage",value:`${(cov*100).toFixed(1)}%`,status:cov>=0.22&&cov<=0.82?"pass":cov<0.18?"flag":"warn",note:`${(cov*100).toFixed(1)}% — minimal 25–35 · classic 33–60 · lush 55–75`};
  const rc={focal:0,secondary:0,filler:0,greenery:0};
  placements.forEach(p=>{if(rc[p.role]!==undefined)rc[p.role]++;});
  const tot=placements.length||1; const fR=rc.focal/tot; const gR=rc.greenery/tot;
  V.R5={label:"R5 Ratios",value:`F:${rc.focal} S:${rc.secondary} Fi:${rc.filler} G:${rc.greenery}`,status:fR>=0.08&&fR<=0.22&&gR>=0.25?"pass":"warn",note:`Focal ${(fR*100).toFixed(0)}% (8–22%) · Greenery ${(gR*100).toFixed(0)}% (≥25%)`};
  const mfD=Object.values(fD).reduce((a,b)=>a+b,0)/4; let gv=0;
  const srt=[...placements].sort((a,b)=>a.angle-b.angle);
  for(let i=0;i<srt.length-1;i++) if(srt[i+1].angle-srt[i].angle<0.7*mfD&&srt[i].role!=="greenery")gv++;
  V.R7={label:"R7 Spacing",value:gv===0?"Clean":`${gv} clash${gv>1?"es":""}`,status:gv===0?"pass":gv<=2?"warn":"flag",note:`${gv} crowding violation${gv!==1?"s":""}`};
  let wx=0,wy=0,wt=0;
  placements.forEach(p=>{const w=(ROLE_W[p.role]||0.3)*Math.min(p.radius/rWork,1.2);wx+=w*Math.sin(p.angle*Math.PI/180);wy+=w*(-Math.cos(p.angle*Math.PI/180));wt+=w;});
  const cX=wx/(wt||1),cY=wy/(wt||1),asym=Math.sqrt(cX*cX+cY*cY);
  const cAng=((Math.atan2(cX,-cY)*180/Math.PI)+360)%360;
  V.R10={label:"R10 Asymmetry",value:asym.toFixed(3),status:asym>=0.40&&asym<=0.80?"pass":asym<0.28||asym>0.92?"flag":"warn",note:`Score ${asym.toFixed(3)} (0.40–0.80) · centroid at ${toClock(cAng)} o'clock`,centX:cX,centY:cY,centAngle:cAng};
  const ly={back:0,mid:0,front:0};
  placements.forEach(p=>{if(ly[p.layer]!==undefined)ly[p.layer]++;});
  V.R17={label:"R17 Depth",value:ly.back>0&&ly.mid>0&&ly.front>0?"3-Layer":"Flat",status:ly.back>0&&ly.mid>0&&ly.front>0?"pass":"flag",note:`Back ${ly.back} · Mid ${ly.mid} · Front ${ly.front}`};
  const pur={}; Object.entries(rc).forEach(([r,c])=>{pur[r]=Math.ceil(c/(YIELD_R[r]||0.9));});
  V.R4={label:"R4 Purchase",value:`${Object.values(pur).reduce((a,b)=>a+b,0)} stems`,status:"pass",note:Object.entries(pur).map(([r,c])=>`${r[0].toUpperCase()}:${c}`).join(" · "),counts:rc,purchase:pur};
  return V;
}

function studioNotes(placements,V,meta) {
  const N=[]; const {rWork,start,span}=meta;
  const score=V.R10?parseFloat(V.R10.value):0.5; const cAng=V.R10?.centAngle||0;
  if(score<0.40) N.push(`Centroid too near center (${score.toFixed(2)}) — add focal bloom at ${toClock((cAng+30)%360)} o'clock to pull mass off-axis.`);
  else if(score>0.80) N.push(`Over-committed centroid (${score.toFixed(2)}) — insert back-layer sprig at ${toClock((cAng+180)%360)} o'clock to counterbalance.`);
  if(V.R17?.status!=="pass") N.push("Depth is collapsed — add back-layer greenery beneath focal stems for dimensional hierarchy.");
  if(V.R7?.status!=="pass") N.push("Crowding in cluster band — rotate fillers 8–12° outward from the r_work line.");
  const extG=placements.filter(p=>p.role==="greenery"&&p.radius>rWork*0.88);
  if(extG.length<2) N.push("Silhouette reads rigid — let 2+ greenery stems break the outer ring boundary.");
  if(N.length===0) N.push("All R-rules validate cleanly. Centroid tension calibrated, arc composition holds, depth layers present.");
  return N;
}

function layoutToBlueprint(layout,formula,diameter,seed) {
  const {placements,meta}=layout; const fc=FORMULAS[formula]||FORMULAS["Crescent"];
  const silenceArcs=fc.span<350?[{from_deg:(fc.start+fc.span)%360,to_deg:fc.start,enforcement:"hard",label:"bare_grapevine"}]:[];
  const foliageSweeps=[{sweep_id:"F1",arc_from:fc.start,arc_to:(fc.start+fc.span+360)%360,arc_hard_stop_deg:silenceArcs[0]?.from_deg,step_deg:14,radius_norm:0.80,flow:"cw"}];
  const clusters=placements.filter(p=>p.role!=="greenery").map((p,i)=>({
    cluster_id:`C${i+1}`,type:p.role,angle_deg:Math.round(p.angle),
    radius_norm:Math.round(p.radius/meta.rWork*100)/100,
    depth_plane:p.layer==="front"?"foreground":p.layer==="mid"?"midground":"base"
  }));
  return {blueprint_id:`EC_PIE_${seed}`,formula,seed,canvas:{type:"polar",diameter_in:diameter},silence_arcs:silenceArcs,foliage_sweeps:foliageSweeps,clusters};
}

// ─────────────────────────────────────────────────────────────
// CONVERTER ENGINE
// ─────────────────────────────────────────────────────────────
const FRAMING_PARAMS = {
  door_wreath:{camera:"complete wreath circle photographed flat against pale dove-gray painted wall, front-facing, 85mm, soft studio daylight from upper left",params:"--style raw --s 100 --ar 1:1 --v 7"},
  mantel_garland:{camera:"garland draped end-to-end along white painted wood mantel — white only not gray not sage, front-facing slight elevation, 50mm, firebox opening in soft focus below",params:"--style raw --s 40 --ar 16:9 --v 7"},
  stair_garland:{camera:"4 to 5 feet of garland in frame only — remainder trails off-frame — 3/4 angle looking up staircase, 35-50mm, painted white balusters and handrail as scale anchors, each bloom proportionally smaller than the newel post cap",params:"--style raw --s 30 --ar 4:5 --v 7"},
  door_garland:{camera:"garland draped over exterior door top, door frame and hardware visible as architectural anchor, slight 3/4 angle, 35-50mm",params:"--style raw --s 40 --ar 4:5 --v 7"},
  small_accent:{camera:"small form tabletop product against neutral pale background, slight elevation angle, 85mm, clean studio lighting",params:"--style raw --s 80 --ar 1:1 --v 7"},
  garland:{camera:"4-5 feet of garland visible in frame, natural drape, slight angle showing dimensional depth, 50mm",params:"--style raw --s 40 --ar 16:9 --v 7"},
};

function degToClock(deg) {
  deg=((deg%360)+360)%360;
  const tot=(deg/360)*720; const h=Math.floor(tot/60)||12; const m=Math.round(tot%60);
  return `${h}:${m.toString().padStart(2,"0")}`;
}

function detectFormType(form) {
  const f=(form||"").toLowerCase();
  if(f.includes("stair")) return "stair_garland";
  if(f.includes("mantel")||f.includes("mantle")) return "mantel_garland";
  if((f.includes("door")||f.includes("swag"))&&f.includes("garland")) return "door_garland";
  if(f.includes("garland")) return "garland";
  if(f.includes("candle")||f.includes("small")||f.includes("ring")) return "small_accent";
  return "door_wreath";
}

function parseDiameter(form) {
  const m=(form||"").match(/(\d+)\s*[-–]?\s*(?:inch|in|")/i);
  return m?parseInt(m[1]):24;
}

function autoBlueprint(product,collection) {
  const diameter=parseDiameter(product.form||"");
  const layout=generateLayout({formula:product.formula||"Crescent",diameter,coverageClass:"classic",seed:42});
  return layoutToBlueprint(layout,product.formula||"Crescent",diameter,42);
}

function buildPhasesHybrid(blueprint,product,collection) {
  const formType=detectFormType(product.form||"");
  const fr=FRAMING_PARAMS[formType]||FRAMING_PARAMS.door_wreath;
  const {formula,canvas,silence_arcs=[],foliage_sweeps=[],clusters=[]}=blueprint;
  const diameter=canvas?.diameter_in||24;
  const isGarland=["mantel_garland","stair_garland","door_garland","garland"].includes(formType);

  const noBlock="--no fresh flowers, real plants, live botanicals, organic, dew, wilting, drooping florals, dewy petals, fresh-cut, florist arrangement, fresh branch arrangement, fresh bough, spring branch, botanical bough, illustrated, painted, digital art, flat lay, overhead shot, bird's eye view, elements merging, overlapping florals, symmetrical bow, tied bow";
  const LED="integrated warm white LED micro-strand lights threaded through interior construction, visible as soft warm glow points between foliage layers, not prominent string lights, not visible wire or cord";

  // Palette direction from collection
  const paletteNames=(collection?.palette||[]).slice(0,3).map(p=>p.name).filter(Boolean);
  const paletteDir=paletteNames.length>0?`palette register: ${paletteNames.join(", ")} -- these tones dominate, no deviation toward silver or gray-blue defaults`:"";

  const greenery=product.greeneryMix||"mixed premium faux botanical greenery";
  const heroFloral=product.heroFloral||"premium faux botanical focal blooms";
  const secFloral=product.secondaryFloral||"premium faux botanical secondary blooms";
  const accentMats=product.accentMaterials||"faux botanical accent materials";

  // GARLAND PATH
  if(isGarland) {
    const SECTIONS=["at the dominant focal cluster positioned center-left along the garland length, projecting 3 to 4 inches forward and downward from the greenery plane -- this is the visual apex of the entire composition","stepping back slightly to the right of the primary cluster, projecting 2 to 3 inches forward -- secondary focal position","filling the left-of-center zone between the focal cluster and the left terminal -- diminishing in scale toward the end","filling the right-of-center zone between the focal cluster and the right terminal -- diminishing in scale toward the end","at the left terminal, a single trailing accent dissolving the composition end","at the right terminal, a single trailing accent balancing the left"];
    const focalClusters=clusters.filter(c=>c.type==="focal");
    const secClusters=clusters.filter(c=>c.type==="secondary");
    const accentClusters=clusters.filter(c=>c.type==="accent"||c.type==="filler");

    const focalDesc=focalClusters.map((c,i)=>`${heroFloral} -- ${SECTIONS[i]||SECTIONS[0]}`).join(", ");
    const secDesc=secClusters.map((c,i)=>`${secFloral} -- ${SECTIONS[2+i]||"cascading from focal mass, diminishing toward terminal"}`).join(", ");
    const accentDesc=accentClusters.length>0?`${accentMats} distributed through the mid-layer between florals -- never overlapping any bloom face -- tucked behind focal elements, flush against the greenery base`:`${accentMats} as texture fill in negative space between florals`;

    const garlandBase=`Luxury handcrafted faux botanical ${product.form||"garland"}, premium artificial silk and polyester florals layered stem-on-stem on a flexible wire armature, natural cascading drape with dimensional depth, home decor product photography,`;
    const garlandGreenery=`${greenery} -- layered full length from terminal to terminal -- density heaviest in the center third where it supports the focal cluster -- cascading lighter and more trailing toward both ends -- outer greenery boundary extends below the garland edge for natural draping movement -- no single greenery species reads as dominant, they layer and nest into each other,`;
    const depthRule=`three-plane depth construction -- outermost trailing greenery defines the back boundary plane -- mid-layer secondary florals and dense greenery fill the body -- hero florals and focal cluster project prominently forward of all greenery by a minimum 3 inches,`;

    const p1=[garlandBase,`${formula} cluster distribution -- botanical mass concentrated in the center-left third with natural tapering cascade toward both terminals,`,garlandGreenery,LED+",",paletteDir?paletteDir+",":"",fr.camera+",",`${noBlock}, ${fr.params}`].filter(Boolean).join(" ");
    const p2=["Use Phase 1 render as --iw 1.8-2.2 image reference.",garlandBase,"photorealistic commercial product photography, florals added in precise cluster positions --",focalDesc?focalDesc+",":"",secDesc?secDesc+",":"",depthRule,fr.camera+",",`${noBlock}, ${fr.params}`].filter(Boolean).join(" ");
    const p3=["Use Phase 2 render as --iw 1.4-1.8 image reference.",accentDesc+",",fr.params].filter(Boolean).join(" ");
    const note=[`${formula} garland -- ${product.form} -- ${clusters.length} clusters`,`Form: ${formType}`,`Blueprint: ${blueprint.blueprint_id||"auto"} seed ${blueprint.seed||42}`,collection?.meta?.atmosphere?`Atmosphere: ${collection.meta.atmosphere}`:""].filter(Boolean).join(" | ");
    return [{label:"Phase 1 -- Greenery base",content:p1},{label:"Phase 2 -- Focal florals",content:p2},{label:"Phase 3 -- Accents",content:p3},{label:"Design note",content:note}];
  }

  // WREATH PATH
  const silenceText=silence_arcs.map(s=>`silence arc from ${degToClock(s.from_deg)} through ${degToClock(s.to_deg)} -- raw exposed grapevine only, zero botanicals in this zone, intentional structural feature`).join("; ");
  const foliageLines=foliage_sweeps.map(s=>{
    const from=degToClock(((s.arc_from||0)%360+360)%360);
    const to=degToClock(((s.arc_to||360)%360+360)%360);
    const stop=s.arc_hard_stop_deg?`, terminating before ${degToClock(((s.arc_hard_stop_deg)%360+360)%360)} -- hard stop enforced`:"";
    return `${greenery} sweeping from ${from} through ${to}${stop}`;
  }).join("; ")||`${greenery} distributed across the active arc`;

  const focalClusters=clusters.filter(c=>c.type==="focal");
  const secClusters=clusters.filter(c=>c.type==="secondary");
  const accentClusters=clusters.filter(c=>c.type==="accent"||c.type==="filler");
  const depthRule="three-plane depth -- greenery and filler at base plane, secondaries at midground, focal elements projecting forward at foreground plane -- minimum 2 inches of depth separation between planes visible in render,";
  const focalLines=focalClusters.map((c,i)=>`${heroFloral} at ${degToClock(c.angle_deg)} as dominant focal element -- foreground plane, projects forward of all greenery${i>0?" -- secondary focal position":""}`).join(", ");
  const secLines=secClusters.map(c=>`${secFloral} at ${degToClock(c.angle_deg)} as supporting secondary accent -- midground plane, nested behind focal element`).join(", ");
  const accentLines=accentClusters.length>0?accentClusters.map(c=>`${accentMats} at ${degToClock(c.angle_deg)} -- base plane, tucked into foliage behind florals, never overlapping any bloom face`).join(", "):`${accentMats} distributed in negative space between florals, never overlapping any bloom face`;

  const p1=[`Luxury handcrafted faux botanical ${product.form||"wreath"}, premium artificial silk and polyester florals, home decor product photography, complete circular grapevine ring base forming a full unbroken ${diameter}-inch loop, ${formula} formula composition,`,foliageLines+",",silenceText?silenceText+",":"",paletteDir?paletteDir+",":"",LED+",",fr.camera+",",`${noBlock}, ${fr.params}`].filter(Boolean).join(" ");
  const p2=["Use Phase 1 render as --iw 1.8-2.2 image reference.",`Luxury handcrafted faux botanical ${product.form||"wreath"}, premium artificial silk florals, photorealistic commercial product photography,`,focalLines?focalLines+",":"",secLines?secLines+",":"",depthRule,silenceText?silenceText+",":"",fr.camera+",",`${noBlock}, ${fr.params}`].filter(Boolean).join(" ");
  const p3=["Use Phase 2 render as --iw 1.4-1.8 image reference.",accentLines+",",silenceText?silenceText+",":"",fr.params].filter(Boolean).join(" ");

  const fc=FORMULAS[formula]||FORMULAS["Crescent"];
  const silenceNote=silence_arcs.map(s=>`silence ${degToClock(s.from_deg)}-${degToClock(s.to_deg)}`).join(", ");
  const atm=collection?.meta?.atmosphere||"";
  const note=[`${formula} -- ${diameter}" -- ${clusters.length} clusters`,`Mass: ${degToClock(fc.start)} to ${degToClock((fc.start+fc.span+360)%360)}`,silenceNote?`Silence: ${silenceNote}`:"",`Blueprint: ${blueprint.blueprint_id||"auto"} seed ${blueprint.seed||42}`,atm?`Atmosphere: ${atm}`:""].filter(Boolean).join(" | ");

  return [{label:"Phase 1 -- Greenery",content:p1},{label:"Phase 2 -- Florals",content:p2},{label:"Phase 3 -- Accents",content:p3},{label:"Design note",content:note}];
}
// ─────────────────────────────────────────────────────────────
// STORAGE
// ─────────────────────────────────────────────────────────────
const MK="ec-manifest"; const CP="ec-col:";
async function getManifest(){try{const m=await window.storage.get(MK,false);return m?JSON.parse(m.value):[]}catch{return [];}}
async function saveToStorage(data){const id=Date.now().toString();await window.storage.set(CP+id,JSON.stringify(data),false);const manifest=await getManifest();manifest.unshift({id,savedAt:new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}),name:data.meta?.name||"Untitled",tagline:data.meta?.tagline||"",palette:(data.palette||[]).slice(0,5).map(p=>p.hex)});await window.storage.set(MK,JSON.stringify(manifest),false);}
async function loadFromStorage(id){try{const c=await window.storage.get(CP+id,false);return c?JSON.parse(c.value):null}catch{return null;}}
async function deleteFromStorage(id){try{await window.storage.delete(CP+id,false)}catch{}const manifest=await getManifest();await window.storage.set(MK,JSON.stringify(manifest.filter(m=>m.id!==id)),false);}

// ─────────────────────────────────────────────────────────────
// CIE API
// ─────────────────────────────────────────────────────────────
async function generate(intent) {
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({model:"claude-sonnet-4-6",max_tokens:8000,system:SYSTEM,messages:[{role:"user",content:`COLLECTION INTENT: ${intent}`}]})});
  const d=await r.json(); if(d.error)throw new Error(d.error.message);
  const raw=d.content[0].text; const clean=raw.replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/i,"").trim();
  try{return JSON.parse(clean);}catch{throw new Error("Couldn't parse the response — try again.");}
}

// ─────────────────────────────────────────────────────────────
// SMALL COMPONENTS
// ─────────────────────────────────────────────────────────────
function CopyBtn({text,label="Copy"}) {
  const [ok,setOk]=useState(false);
  return <button className={`copy-btn${ok?" ok":""}`} onClick={()=>{navigator.clipboard.writeText(text).catch(()=>{});setOk(true);setTimeout(()=>setOk(false),2400);}}>{ok?"Copied ✓":label}</button>;
}

function VBadge({status,label}) {
  return <span className={`vbadge ${status}`}>{label}</span>;
}

// ─────────────────────────────────────────────────────────────
// WREATH CANVAS — ported from PIE-App.jsx
// ─────────────────────────────────────────────────────────────
function WreathCanvas({placements,meta,V,onClusterMove}) {
  const [draggingId,setDraggingId]=useState(null);
  const svgRef=useRef(null);
  const SZ=380,cx=SZ/2,cy=SZ/2,mg=28;
  const scale=(SZ/2-mg)/(meta.diameter/2);
  const outerPx=(meta.diameter/2)*scale;
  const bw=BASE_WIDTHS[meta.diameter]||4.5;
  const innerPx=(meta.diameter/2-bw)*scale;
  const rwPx=meta.rWork*scale;
  const sv=p=>{const r=p.radius*scale;return toXY(p.angle,r,cx,cy);};
  const bp=p=>Math.max(3,p.size*scale*0.43);
  const silStart=(meta.start+meta.span+15)%360;
  const silSpan=360-meta.span-30;

  // Global mouseup to end drag even if cursor leaves SVG
  useEffect(()=>{
    const up=()=>setDraggingId(null);
    document.addEventListener('mouseup',up);
    return ()=>document.removeEventListener('mouseup',up);
  },[]);

  function getAngleFromEvent(e) {
    if(!svgRef.current)return 0;
    const rect=svgRef.current.getBoundingClientRect();
    const svgX=(e.clientX-rect.left)*(SZ/rect.width);
    const svgY=(e.clientY-rect.top)*(SZ/rect.height);
    return((Math.atan2(svgX-cx,-(svgY-cy))*180/Math.PI)+360)%360;
  }

  function handleMouseMove(e) {
    if(!draggingId||!onClusterMove)return;
    onClusterMove(draggingId,getAngleFromEvent(e));
  }

  function arcPath(as,sp,r1,r2){
    if(sp>=358||sp<=2)return null;
    const ae=as+sp; const p1=toXY(as,r1,cx,cy),p2=toXY(ae,r1,cx,cy);
    const p3=toXY(ae,r2,cx,cy),p4=toXY(as,r2,cx,cy); const lg=sp>180?1:0;
    return `M${p1.x.toFixed(1)},${p1.y.toFixed(1)} A${r1},${r1} 0 ${lg} 1 ${p2.x.toFixed(1)},${p2.y.toFixed(1)} L${p3.x.toFixed(1)},${p3.y.toFixed(1)} A${r2},${r2} 0 ${lg} 0 ${p4.x.toFixed(1)},${p4.y.toFixed(1)} Z`;
  }
  const silPath=silSpan>2?arcPath(silStart,silSpan,outerPx+3,innerPx-3):null;
  const centVX=V.R10?cx+V.R10.centX*rwPx*0.52:cx;
  const centVY=V.R10?cy+V.R10.centY*rwPx*0.52:cy;
  const canDrag=p=>!!onClusterMove&&p.role!=='greenery';

  return (
    <svg ref={svgRef} width={SZ} height={SZ} viewBox={`0 0 ${SZ} ${SZ}`}
         style={{display:'block',cursor:draggingId?'grabbing':'default'}}
         onMouseMove={handleMouseMove} onMouseUp={()=>setDraggingId(null)}>
      <rect width={SZ} height={SZ} fill="#F6F2EB" rx={8} stroke="#DDD4C0" strokeWidth={1}/>
      <circle cx={cx} cy={cy} r={(outerPx+innerPx)/2} fill="none" stroke="#C8B898" strokeWidth={outerPx-innerPx} opacity={0.55}/>
      <circle cx={cx} cy={cy} r={outerPx} fill="none" stroke="#A89870" strokeWidth={0.8}/>
      <circle cx={cx} cy={cy} r={innerPx} fill="none" stroke="#A89870" strokeWidth={0.8}/>
      <circle cx={cx} cy={cy} r={rwPx} fill="none" stroke="#8A7850" strokeWidth={0.9} strokeDasharray="5,5" opacity={0.55}/>
      {silPath&&<path d={silPath} fill="#EDE8DF" opacity={0.65}/>}
      {[0,90,180,270].map(a=>{const isMaj=a===0;const t=toXY(a,outerPx-5,cx,cy),lb=toXY(a,outerPx+14,cx,cy);return <g key={a}><line x1={t.x} y1={t.y} x2={toXY(a,outerPx,cx,cy).x} y2={toXY(a,outerPx,cx,cy).y} stroke={isMaj?"#7A7060":"#AAA090"} strokeWidth={isMaj?1.5:0.8}/><text x={lb.x} y={lb.y} fill={isMaj?"#5A5040":"#9A9080"} fontSize={isMaj?9:7.5} textAnchor="middle" dominantBaseline="middle" fontFamily="'DM Sans',sans-serif" fontWeight={isMaj?"600":"400"}>{a===0?12:a===90?3:a===180?6:9}</text></g>;})}
      <circle cx={cx} cy={cy} r={2.5} fill="#9A9080"/>

      {/* Render layers: back → mid → front */}
      {['back','mid','front'].map(layer=>placements.filter(p=>p.layer===layer).map(p=>{
        const pos=sv(p); const bpx=bp(p); const opacity=layer==='back'?0.45:layer==='mid'?0.70:1.0;
        const gc=PIE_COLORS.greenery;

        // ── GREENERY: directional leaf sprig ──────────────────
        if(p.role==='greenery') {
          const sz=Math.max(5,bpx*1.4);
          const rot=p.angle-90; // rotate sprite outward from center
          const op=layer==='back'?0.38:0.62;
          return (
            <g key={p.id} transform={`translate(${pos.x},${pos.y}) rotate(${rot})`} opacity={op}>
              {/* Stem */}
              <line x1={-sz} y1={0} x2={sz*0.72} y2={0} stroke={gc} strokeWidth={0.9} strokeLinecap="round"/>
              {/* Directional arrowhead at outer tip */}
              <polygon points={`${sz*0.88},0 ${sz*0.5},-${sz*0.28} ${sz*0.5},${sz*0.28}`} fill={gc} opacity={0.82}/>
              {/* Leaf pair 1 — base */}
              <ellipse cx={-sz*0.52} cy={-sz*0.42} rx={sz*0.48} ry={sz*0.19} fill={gc} opacity={0.72} transform={`rotate(-38,${-sz*0.52},${-sz*0.42})`}/>
              <ellipse cx={-sz*0.52} cy={sz*0.42} rx={sz*0.48} ry={sz*0.19} fill={gc} opacity={0.72} transform={`rotate(38,${-sz*0.52},${sz*0.42})`}/>
              {/* Leaf pair 2 — mid */}
              <ellipse cx={-sz*0.1} cy={-sz*0.48} rx={sz*0.52} ry={sz*0.19} fill={gc} opacity={0.72} transform={`rotate(-28,${-sz*0.1},${-sz*0.48})`}/>
              <ellipse cx={-sz*0.1} cy={sz*0.48} rx={sz*0.52} ry={sz*0.19} fill={gc} opacity={0.72} transform={`rotate(28,${-sz*0.1},${sz*0.48})`}/>
              {/* Leaf pair 3 — tip */}
              <ellipse cx={sz*0.26} cy={-sz*0.38} rx={sz*0.4} ry={sz*0.17} fill={gc} opacity={0.65} transform={`rotate(-18,${sz*0.26},${-sz*0.38})`}/>
              <ellipse cx={sz*0.26} cy={sz*0.38} rx={sz*0.4} ry={sz*0.17} fill={gc} opacity={0.65} transform={`rotate(18,${sz*0.26},${sz*0.38})`}/>
            </g>
          );
        }

        // ── BLOOM CLUSTERS: draggable dots ────────────────────
        const isDragging=draggingId===p.id;
        const draggable=canDrag(p);
        return (
          <g key={p.id} style={{cursor:draggable?'grab':'default'}}
             onMouseDown={e=>{if(!draggable)return;e.preventDefault();e.stopPropagation();setDraggingId(p.id);}}>
            {isDragging&&<circle cx={pos.x} cy={pos.y} r={bpx+6} fill="none" stroke="#B08D45" strokeWidth={1.5} strokeDasharray="3,3" opacity={0.7}/>}
            <circle cx={pos.x} cy={pos.y} r={bpx} fill={PIE_COLORS[p.role]} opacity={isDragging?1:opacity}
                    stroke={isDragging?"#B08D45":"#F6F2EB"} strokeWidth={isDragging?1.5:layer==='front'?1.2:0.4}/>
            {p.role==='focal'&&layer==='front'&&<circle cx={pos.x} cy={pos.y} r={bpx*0.42} fill="none" stroke="#F6F2EB" strokeWidth={0.7} opacity={0.5}/>}
          </g>
        );
      }))}

      {/* Centroid indicator */}
      {V.R10&&<g opacity={0.85}><line x1={cx} y1={cy} x2={centVX} y2={centVY} stroke="#9A7038" strokeWidth={1.2} strokeDasharray="3,3"/><circle cx={centVX} cy={centVY} r={5} fill="none" stroke="#9A7038" strokeWidth={1.5}/><circle cx={centVX} cy={centVY} r={2} fill="#9A7038"/></g>}
      {/* Anchor marker */}
      {placements[0]&&(()=>{const pos=sv(placements[0]);return <text x={pos.x} y={pos.y-bp(placements[0])-5} fill="#9A7038" fontSize={9} textAnchor="middle" fontFamily="'DM Sans',sans-serif">⊕</text>;})()}

      {/* Drag hint */}
      {onClusterMove&&!draggingId&&<text x={cx} y={SZ-10} textAnchor="middle" fontSize={8} fill="#A89870" fontFamily="'DM Mono',sans-serif" letterSpacing="0.08em">drag focal + secondary clusters to reposition</text>}
    </svg>
  );
}
// ─────────────────────────────────────────────────────────────
// CIE TAB COMPONENTS
// ─────────────────────────────────────────────────────────────
function FoundationTab({d}) {
  return <div>
    <div className="eyebrow">Collection Foundation Profile</div>
    <div className="pull"><p>{d.meta?.pullQuote}</p></div>
    <div className="sec-title">Palette Identity</div>
    <div className="swatch-row">{(d.palette||[]).map((p,i)=><div key={i} className="swatch"><div className="swatch-color" style={{background:p.hex}}/><div className="swatch-label"><div className="swatch-name">{p.name}</div><div className="swatch-hex">{p.hex}</div></div></div>)}</div>
    <div className="sec-title">Foundation Profile</div>
    <div className="profile-grid">{(d.foundation?.profile||[]).map(([l,v],i)=><div key={i} className="profile-card"><div className="profile-lbl">{l}</div><div className="profile-val">{v}</div></div>)}</div>
    <div className="sec-title">Signature Spec Block</div>
    <div className="sig-block">{(d.foundation?.signature||[]).map(([l,v],i)=><div key={i} className="sig-row"><span className="sig-lbl">{l}</span><span className="sig-val">{v}</span></div>)}</div>
  </div>;
}

function HierarchyTab({d}) {
  const prices=(d.hierarchy||[]).map(h=>h.price).filter(p=>p>0);
  const total=prices.reduce((s,p)=>s+p,0);
  return <div>
    <div className="eyebrow">Collection Hierarchy Map</div>
    {prices.length>0&&<div className="price-bar">
      <div><div className="pb-lbl">Entry</div><div className="pb-val">${Math.min(...prices)}</div></div>
      <div><div className="pb-lbl">Average</div><div className="pb-val">${Math.round(total/prices.length)}</div></div>
      <div><div className="pb-lbl">Premium Ceiling</div><div className="pb-val">${Math.max(...prices)}</div></div>
      <div><div className="pb-lbl">Collection Total</div><div className="pb-val">${total}</div></div>
      <div><div className="pb-lbl">Products</div><div className="pb-val">{d.hierarchy.length}</div></div>
    </div>}
    <div className="role-list">{(d.hierarchy||[]).map((h,i)=><div key={i} className="role-card" style={{borderLeftColor:h.color}}>
      <div className="role-left"><div className="role-tag">{h.role}</div><div className="role-name">{h.name}</div><div className="role-form"><strong>{h.form}</strong> · {h.formula} · {h.scale}</div><div className="role-meta">{h.meta}</div></div>
      <div className="role-price">${h.price}</div>
    </div>)}</div>
  </div>;
}

function ContinuityTab({d}) {
  const c=d.continuity||{};
  const vc=v=>v==="strong"?"strong":v==="critical"?"critical":"needs-attention";
  const vi=v=>v==="strong"?"✓":v==="critical"?"✗":"⚠";
  return <div>
    <div className="eyebrow">Emotional Continuity Audit</div>
    <div className="score-strip">
      <div className="score-card"><div className="score-val big">{c.overallScore}</div><div className="score-lbl-sm">Overall Score</div></div>
      {(c.threads||[]).map((t,i)=><div key={i} className="score-card"><div className="score-val" style={{color:t.verdict==="strong"?"#B08D45":t.verdict==="critical"?"#943030":"#8A6A10"}}>{vi(t.verdict)}</div><div className="score-lbl-sm">{t.name}</div></div>)}
    </div>
    {c.scoreRationale&&<div className="note">{c.scoreRationale}</div>}
    {(c.threads||[]).map((t,i)=><div key={i} className="thread-card"><div className={`thread-verdict ${vc(t.verdict)}`}>{t.verdict}</div><div className="thread-name">{t.name}</div><div className="thread-body">{t.analysis}</div></div>)}
    <div className="hr"/><div className="sec-title">Quality Gate Checklist</div>
    <div className="chk-list">{(c.qualityGates||[]).map((g,i)=><div key={i} className="chk-row"><span className={`chk-icon ${g.pass?"ok":"fail"}`}>{g.pass?"✓":"✗"}</span>{g.label}</div>)}</div>
  </div>;
}

function ReleaseTab({d}) {
  return <div>
    <div className="eyebrow">Phased Release Strategy</div>
    <div className="timeline">{(d.release||[]).map((ph,i)=><div key={i} className="phase-card">
      <div className="phase-num">{ph.phase}</div><div className="phase-title">{ph.title}</div>
      <div className="phase-row"><b>Timing:</b> {ph.timing}</div><div className="phase-row"><b>Products:</b> {ph.products}</div>
      <div className="phase-row"><b>Copy Hook:</b> {ph.copyHook}</div><div className="phase-row"><b>Buyer Psychology:</b> {ph.buyerPsychology}</div>
      <div className="phase-row"><b>Emotional Arc:</b> {ph.emotionalArc}</div>
    </div>)}</div>
  </div>;
}

function CrossSellTab({d}) {
  const cs=d.crossSell||{};
  return <div>
    <div className="eyebrow">Cross-Sell Architecture</div>
    <div className="sec-title">Room Systems</div>
    {(cs.systems||[]).map((s,i)=><div key={i} className="system-card"><div className="system-name">{s.name}</div><div className="system-flow">{s.flow}</div></div>)}
    <div className="hr"/><div className="sec-title">Bundle Opportunities</div>
    <div className="bundle-grid">{(cs.bundles||[]).map((b,i)=><div key={i} className="bundle-card">
      <div className="bundle-name">{b.name}</div><div className="bundle-type">{b.type}</div><div className="bundle-contents">{b.contents}</div>
      <div className="bundle-pr">{b.pct>0&&<span className="bundle-was">${b.sum}</span>}<span className="bundle-now">${b.final}</span></div>
      {b.pct>0?<div className="bundle-save">Save ${(b.sum||0)-(b.final||0)} ({Math.round((b.pct||0)*100)}%)</div>:<div className="bundle-save">Premium presentation — full price</div>}
    </div>)}</div>
  </div>;
}

function MerchTab({d}) {
  const m=d.merch||{};
  const blocks=[{t:"Collection hero shot",b:m.heroShot},{t:"Product family groupings",b:m.familyGroupings},{t:"Individual product shots",b:m.individualShots},{t:"Detail shots",b:m.detailShots}];
  return <div>
    <div className="eyebrow">Visual Merchandising Plan</div>
    {blocks.map((b,i)=>b.b&&<div key={i} className="merch-block"><div className="merch-title">{b.t}</div><div className="merch-body">{b.b}</div></div>)}
    <div className="hr"/><div className="eyebrow">Shop Front Flow</div>
    <ol className="flow-list">{(m.shopFrontFlow||[]).map((s,i)=><li key={i}>{s}</li>)}</ol>
    <div className="eyebrow">Display Grouping Principles</div><div className="note">{m.displayPrinciples}</div>
  </div>;
}

// ─────────────────────────────────────────────────────────────
// LAYOUT TAB — PIE engine
// ─────────────────────────────────────────────────────────────
function LayoutTab({d,blueprints,onActivate}) {
  const products=d.hierarchy||[];
  const [selected,setSelected]=useState(products[0]?.name||'');
  const [formula,setFormula]=useState('');
  const [coverage,setCoverage]=useState('classic');
  const [seed,setSeed]=useState(42);
  const [layout,setLayout]=useState(null);
  const [activated,setActivated]=useState({});
  const [modified,setModified]=useState(false);

  const product=products.find(p=>p.name===selected);

  useEffect(()=>{
    if(product?.formula)setFormula(product.formula);
    setLayout(null);setModified(false);
  },[selected]);

  const diameter=parseDiameter(product?.form||'');

  function handleGenerate() {
    if(!formula)return;
    const result=generateLayout({formula,diameter,coverageClass:coverage,seed:parseInt(seed)||42});
    const V=validate(result.placements,result.meta);
    const N=studioNotes(result.placements,V,result.meta);
    const bp=layoutToBlueprint(result,formula,diameter,parseInt(seed)||42);
    setLayout({...result,V,N,blueprint:bp});
    setModified(false);
  }

  function handleClusterMove(clusterId,newAngle) {
    if(!layout)return;
    const updated=layout.placements.map(p=>p.id===clusterId?{...p,angle:newAngle}:p);
    const V=validate(updated,layout.meta);
    const N=studioNotes(updated,V,layout.meta);
    const bp=layoutToBlueprint({placements:updated,meta:layout.meta},formula,diameter,parseInt(seed)||42);
    setLayout(prev=>({...prev,placements:updated,V,N,blueprint:bp}));
    setModified(true);
  }

  function handleActivate() {
    if(!layout||!product)return;
    onActivate(product.name,layout.blueprint);
    setActivated(prev=>({...prev,[product.name]:true}));
  }

  const isActivated=product&&(blueprints[product.name]||activated[product.name]);

  return <div>
    <div className="eyebrow">Layout Designer — Placement Intelligence Engine</div>
    <div className="note">Generate a layout, then <strong>drag any focal or secondary cluster</strong> to reposition it around the ring. Greenery sprigs show flow direction. Hit Activate when the layout reads right — the Render tab updates instantly with your exact coordinates.</div>

    <div className="layout-prod-pills">
      {products.map(p=><button key={p.name} className={`lpill${selected===p.name?' active':''}`} onClick={()=>setSelected(p.name)}>{p.name}</button>)}
    </div>

    {product&&<div>
      <div className="layout-controls">
        <div className="lctrl" style={{minWidth:160}}>
          <span className="lctrl-lbl">Formula</span>
          <select value={formula} onChange={e=>setFormula(e.target.value)}>
            {Object.keys(FORMULAS).map(f=><option key={f} value={f}>{f}</option>)}
          </select>
        </div>
        <div className="lctrl">
          <span className="lctrl-lbl">Coverage</span>
          <select value={coverage} onChange={e=>setCoverage(e.target.value)}>
            <option value="minimal">Minimal</option>
            <option value="classic">Classic</option>
            <option value="lush">Lush</option>
          </select>
        </div>
        <div className="lctrl" style={{minWidth:70}}>
          <span className="lctrl-lbl">Diameter</span>
          <input type="number" value={diameter} readOnly style={{color:'#8A7142',width:70}}/>
        </div>
        <div className="lctrl" style={{minWidth:80}}>
          <span className="lctrl-lbl">Seed</span>
          <input type="number" value={seed} onChange={e=>setSeed(e.target.value)} min="1" style={{width:80}}/>
        </div>
        <button className="intent-btn" style={{alignSelf:'flex-end',padding:'8px 18px',fontSize:'12px'}} onClick={handleGenerate}>Generate ✦</button>
      </div>

      {layout&&<>
        <div className="layout-canvas-wrap"><WreathCanvas placements={layout.placements} meta={layout.meta} V={layout.V} onClusterMove={handleClusterMove}/></div>

        <div className="vbadge-row">
          {Object.values(layout.V).filter(v=>v.label).map(v=><VBadge key={v.label} status={v.status} label={`${v.label} — ${v.value}`}/>)}
          <span className="vbadge info">{layout.placements.length} stems · seed {seed}</span>
          {modified&&<span className="vbadge" style={{background:'rgba(176,141,69,.12)',color:'#8A6A10',border:'.5px solid rgba(176,141,69,.3)'}}>✎ manually adjusted</span>}
        </div>

        <div className="design-note-block">
          {FORMULAS[formula]?.desc} · {diameter}" · {coverage} coverage
          {layout.blueprint.silence_arcs?.length>0?' · silence arc '+layout.blueprint.silence_arcs.map(s=>`${degToClock(s.from_deg)}-${degToClock(s.to_deg)}`).join(', '):''}
          {modified?' · custom cluster positions':''}
        </div>

        {layout.N.length>0&&<div className="note">{layout.N[0]}</div>}

        <div style={{display:'flex',gap:10,marginBottom:20,flexWrap:'wrap'}}>
          <button className={`activate-btn${isActivated?' on':''}`} onClick={handleActivate}>
            {isActivated?'✓ Active in Render':'Activate for Render →'}
          </button>
          <CopyBtn text={JSON.stringify(layout.blueprint,null,2)} label="Copy Blueprint JSON"/>
        </div>
      </>}
    </div>}
  </div>;
}
// ─────────────────────────────────────────────────────────────
// RENDER TAB — deterministic, no AI
// ─────────────────────────────────────────────────────────────
function RenderTab({d,blueprints}) {
  const [phases,setPhases]=useState({});
  const [activePhase,setActivePhase]=useState({});
  const products=d.hierarchy||[];

  useEffect(()=>{
    const built={};const active={};
    products.forEach(product=>{
      const bp=blueprints[product.name]||autoBlueprint(product,d);
      built[product.name]=buildPhasesHybrid(bp,product,d);
      active[product.name]=0;
    });
    setPhases(built);setActivePhase(active);
  },[blueprints]);

  function rebuild(product) {
    const bp=blueprints[product.name]||autoBlueprint(product,d);
    const result=buildPhasesHybrid(bp,product,d);
    setPhases(prev=>({...prev,[product.name]:result}));
    setActivePhase(prev=>({...prev,[product.name]:0}));
  }

  return <div>
    <div className="eyebrow">MJ V7 Render Packages — Full Collection</div>
    <div className="note">Prompts generated deterministically — PIE blueprint coordinates + CIE botanical specs. Instant, reproducible, no API calls. Customize placement precision in the Layout tab and activate to update these prompts.</div>

    {products.map((product,i)=>{
      const isCustom=!!blueprints[product.name];
      const productPhases=phases[product.name]||[];
      const activeIdx=activePhase[product.name]||0;
      return <div key={i}>
        <div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12,marginBottom:12}}>
          <div>
            <div className="render-hdr">{product.name}</div>
            <div className="render-sub">
              {product.role} · {product.form} · {product.formula}
              {" · "}<span className={`bp-status ${isCustom?"custom":"auto"}`}>{isCustom?"✓ Custom PIE layout":"⊕ Auto layout"}</span>
            </div>
          </div>
          <button className="saved-del-btn" style={{fontSize:"8.5px",flexShrink:0,marginTop:4}} onClick={()=>rebuild(product)}>Rebuild</button>
        </div>

        {(product.heroFloral||product.greeneryMix)&&(
          <div style={{background:"#FFFBF0",border:".5px solid #E8D49C",borderRadius:4,padding:"12px 15px",marginBottom:14,display:"grid",gridTemplateColumns:"1fr 1fr",gap:"6px 16px"}}>
            {[{l:"Hero Floral",v:product.heroFloral},{l:"Secondary Floral",v:product.secondaryFloral},{l:"Accent Materials",v:product.accentMaterials},{l:"Greenery Mix",v:product.greeneryMix}].filter(r=>r.v).map((r,ri)=><div key={ri}><div style={{fontFamily:"'DM Mono',monospace",fontSize:"8px",letterSpacing:".12em",textTransform:"uppercase",color:"#8A7142",marginBottom:2}}>{r.l}</div><div style={{fontSize:"11.5px",color:"#332B1A",lineHeight:1.55}}>{r.v}</div></div>)}
          </div>
        )}

        {productPhases.length>0&&<>
          <div className="ptab-row">
            {productPhases.map((ph,pi)=><button key={pi} className={`ptab${activeIdx===pi?" active":""}`} onClick={()=>setActivePhase(prev=>({...prev,[product.name]:pi}))}>{ph.label}</button>)}
          </div>
          <div className="prompt-block">
            <div className="prompt-hdr">
              <span className="prompt-lbl">{productPhases[activeIdx]?.label}</span>
              <CopyBtn text={productPhases[activeIdx]?.content||""}/>
            </div>
            <div className="prompt-txt">{productPhases[activeIdx]?.content}</div>
          </div>
        </>}

        <div className="hr"/>
      </div>;
    })}
  </div>;
}

// ─────────────────────────────────────────────────────────────
// GUIDE TAB
// ─────────────────────────────────────────────────────────────
function GuideTab() {
  return <div>
    <div className="eyebrow">MJ V7 Prompt Architecture · Master Reference</div>
    <div className="guide-thesis"><p>Tell MJ what it is made of, how it is photographed, where every element sits by clock position, and explicitly correct every default it would otherwise reach for. Then protect what you've built with --iw as you add each new layer.</p></div>

    <div className="guide-section">
      <div className="guide-h2">The Mental Model</div>
      <div className="guide-p">You're not describing an image. You're writing a construction blueprint that also specifies how it gets photographed. MJ V7 has strong defaults — pine defaults blue-gray, ranunculus defaults to florist bouquet, ribbon defaults to symmetrical bow. Your job is to correct those defaults explicitly.</div>
    </div>

    <div className="guide-section">
      <div className="guide-h2">Architecture of Every Prompt — write in this order</div>
      {[
        ["1 — Material register","Open with what it IS and what it's MADE OF.","Luxury handcrafted faux botanical wreath, premium artificial silk and polyester florals, home decor product photography"],
        ["2 — Photography register","Tell MJ what kind of image before describing what's in it.","photorealistic commercial product photography, real photograph not illustrated not painted"],
        ["3 — Base structure","Build the physical object before adding to it. 'Unbroken' matters.","complete circular grapevine ring base forming a full unbroken 24-inch loop"],
        ["4 — Greenery with clock positions","WHERE the greenery goes. Specific clock coverage.","greenery concentrated from 8 through 12 to 4 o'clock, warm grapevine exposed from 5 to 7 o'clock as intentional silence arc"],
        ["5 — Focal hierarchy","Tell MJ which element dominates. Name it explicitly.","three large ivory wax-finish faux silk ranunculus — ranunculus are the dominant commanding hero element — primary fully open at 11 o'clock, secondary mid-open at 9 o'clock, tertiary bud at 1 o'clock"],
        ["6 — Material specifics","Size, finish, position, relationship for every element.","brass-dusted faux magnolia pods — elongated organic pod form 2 to 3 inches long not spherical not round — subordinate in scale to ranunculus but commanding in texture"],
        ["7 — Camera and lighting","Specific lens, angle, light direction. Always.","photographed flat against a pale gray painted wall front-facing, soft studio daylight from upper left, 85mm editorial e-commerce product photography"],
      ].map((s,i)=><div key={i} style={{marginBottom:16}}>
        <div className="guide-label">{s[0]}</div>
        <div className="guide-p">{s[1]}</div>
        <div className="guide-code">{s[2]}</div>
      </div>)}
      <div style={{marginBottom:16}}>
        <div className="guide-label">8 — --no block</div>
        <div className="guide-p">Not redundant with in-prompt negatives. Main-prompt negatives tell MJ what the positive IS. --no tells MJ what OUTPUTS to exclude. Different levels.</div>
        <div className="guide-code">{"--no fresh flowers, real plants, live botanicals, organic, dew, wilting, florist, fresh-cut,\nflat lay, overhead shot, bird's eye view, illustrated, painted, digital art"}</div>
      </div>
      <div>
        <div className="guide-label">9 — Technical parameters</div>
        <div className="params-grid">
          <span className="params-key">--style raw</span><span className="params-val">always — prevents artistic stylization</span>
          <span className="params-key">--s 30–100</span><span className="params-val">30 stair garland · 40 mantel · 80–100 wreath</span>
          <span className="params-key">--ar 1:1</span><span className="params-val">door wreaths</span>
          <span className="params-key">--ar 16:9</span><span className="params-val">mantel garlands</span>
          <span className="params-key">--ar 4:5</span><span className="params-val">stair garlands</span>
          <span className="params-key">--v 7</span><span className="params-val">always explicit</span>
        </div>
      </div>
    </div>

    <div className="guide-section">
      <div className="guide-h2">Phase Logic</div>
      <div className="guide-p">When ten competing elements exist in one prompt, MJ produces a consensus average — everything gets a version of itself that coexists rather than a fully realized version. The phase stack eliminates competition.</div>
      <div className="params-grid">
        <span className="params-key">Phase 1</span><span className="params-val">Greenery only. No florals, no accents. Lock the base.</span>
        <span className="params-key">Phase 2</span><span className="params-val">Bring Phase 1 as --iw 1.8–2.2. Hero + secondary florals only.</span>
        <span className="params-key">Phase 3</span><span className="params-val">Bring Phase 2 as --iw 1.4–1.8. Accent layer only.</span>
      </div>
      <div className="note"><strong>--iw calibration:</strong> If new element isn't appearing strongly, lower --iw by 0.2. If base layer is drifting, raise it.</div>
    </div>

    <div className="guide-section">
      <div className="guide-h2">Canonical Defaults to Fight</div>
      <table className="ref-table">
        <thead><tr><th>Element</th><th>MJ's default</th><th>How to fight it</th></tr></thead>
        <tbody>
          {[
            ["Pine / fir","Blue-gray, Christmas","Name exact color: warm sage, olive, forest green. Add: not blue not gray not Christmas green"],
            ["Hellebores","Drooping fresh cup, dewy","wax-finish faux silk, cups semi-closed, no visible stamens, not drooping, not dewy"],
            ["Anemones","Fresh florist, drooping centre","premium faux silk anemone, petals fully formed, dark centre disc flat, not drooping"],
            ["Ranunculus","Fresh-cut florist, flat","wax-finish, fully dimensional, not fresh-cut not florist"],
            ["Magnolia / pods","Large open white flower","elongated organic pod form, not flower, not bloom, not open petal"],
            ["Ribbon","Symmetrical bow, stiff satin","single draped velvet tail, asymmetrical, not tied, not bow"],
            ["Cotton bolls","Appear uninvited","Always in --no: cotton bolls, cotton stems, cotton branches"],
            ["Fresh bough","Appears when material register weakens","--no: fresh branch arrangement, fresh bough, spring branch, botanical bough"],
            ["LED lights","Invisible or Christmas string","integrated warm white LED micro-strand lights threaded through interior, visible as soft warm glow points, not prominent string lights"],
            ["Mantel","Sage, gray, or wrong color","white painted wood mantel surround only — not gray, not sage, not mint"],
            ["Stair garland scale","Entire garland crammed in frame","frame as 4-5 foot section only, remainder trails off-frame, blooms proportionally smaller than newel post cap"],
            ["Material overall","Fresh flowers, florist","Declare register in line one: luxury handcrafted faux botanical, premium artificial silk"],
          ].map(([el,def,fix],i)=><tr key={i}><td>{el}</td><td>{def}</td><td>{fix}</td></tr>)}
        </tbody>
      </table>
    </div>

    <div className="guide-section">
      <div className="guide-h2">Lifestyle Architecture</div>
      <div className="guide-h3">Register change</div>
      <div className="guide-label" style={{marginBottom:4}}>Product</div>
      <div className="guide-code">{"home decor product photography, isolated subject, pale gray studio wall"}</div>
      <div className="guide-label" style={{marginBottom:4}}>Environmental</div>
      <div className="guide-code">{"interior lifestyle photography, editorial home styling, architectural context"}</div>
      <div className="guide-h3">Camera change</div>
      <div className="guide-code">{"Product: front-facing flat, 85mm, clean background\nEnvironmental: slight 3/4 angle, 35-50mm, shallow DOF, environment soft in background"}</div>
      <ul className="guide-ul">
        <li><strong>Exterior door:</strong> paint color, hardware finish, seasonal light quality</li>
        <li><strong>Interior entry:</strong> white or painted door, hardwood glimpse, no clutter</li>
        <li><strong>Mantel:</strong> white painted surround, candlesticks or vessels only</li>
        <li><strong>Console / table:</strong> runner context, overhead ambient light, 3/4 angle</li>
      </ul>
    </div>
  </div>;
}

// ─────────────────────────────────────────────────────────────
// SAVED SCREEN
// ─────────────────────────────────────────────────────────────
function SavedScreen({onBack,onLoad}) {
  const [manifest,setManifest]=useState([]);
  const [loading,setLoading]=useState(true);
  const [loadingId,setLoadingId]=useState(null);
  const [deletingId,setDeletingId]=useState(null);
  useEffect(()=>{getManifest().then(m=>{setManifest(m);setLoading(false);});}, []);
  async function handleLoad(id){setLoadingId(id);const data=await loadFromStorage(id);setLoadingId(null);if(data)onLoad(data);}
  async function handleDelete(id){setDeletingId(id);await deleteFromStorage(id);setManifest(m=>m.filter(e=>e.id!==id));setDeletingId(null);}
  return <div className="saved-screen">
    <div className="saved-hdr"><div><div className="saved-hdr-eye">Evercrafted Studio · Collection Library</div><div className="saved-hdr-title">Saved Collections</div></div><button className="reset-btn" onClick={onBack}>← Back</button></div>
    <div className="saved-body">
      {loading?<div style={{textAlign:"center",padding:"40px",color:"#8A7142",fontFamily:"'DM Mono',monospace",fontSize:"11px",letterSpacing:".1em"}}>Loading…</div>
      :manifest.length===0?<div className="saved-empty"><div className="saved-empty-g">○</div><div className="saved-empty-t">No saved collections yet.<br/>Generate one and hit Save ✦ to keep it here.</div></div>
      :<div className="saved-grid">{manifest.map(m=><div key={m.id} className="saved-card">
        <div className="saved-card-name">{m.name}</div>
        <div className="saved-card-tag">{m.tagline}</div>
        {m.palette?.length>0&&<div className="saved-card-dots">{m.palette.map((hex,i)=><div key={i} className="saved-card-dot" style={{background:hex}}/>)}</div>}
        <div className="saved-card-meta">Saved {m.savedAt}</div>
        <div className="saved-card-actions">
          <button className="saved-load-btn" onClick={()=>handleLoad(m.id)} disabled={loadingId===m.id}>{loadingId===m.id?"Loading…":"Load Collection"}</button>
          <button className="saved-del-btn" onClick={()=>handleDelete(m.id)} disabled={deletingId===m.id}>{deletingId===m.id?"…":"Delete"}</button>
        </div>
      </div>)}</div>}
    </div>
  </div>;
}

// ─────────────────────────────────────────────────────────────
// DASHBOARD
// ─────────────────────────────────────────────────────────────
function Dashboard({data,onReset,onSave,blueprints,onActivateBlueprint,restored=false}) {
  const [tab,setTab]=useState("foundation");
  const [saveStatus,setSaveStatus]=useState(null);
  async function handleSave(){setSaveStatus("saving");try{await onSave(data);setSaveStatus("saved");setTimeout(()=>setSaveStatus(null),3000);}catch{setSaveStatus("error");setTimeout(()=>setSaveStatus(null),2000);}}
  const saveLabel=saveStatus==="saving"?"Saving…":saveStatus==="saved"?"Saved ✓":saveStatus==="error"?"Error":"Save ✦";
  return <div className="dash">
    <div className="dash-hdr">
      <div className="dash-hdr-top">
        <div><div className="dash-eye">Evercrafted Studio · Full Collection Intelligence Package{restored&&<span style={{marginLeft:10,fontFamily:"'DM Mono',monospace",fontSize:"8px",letterSpacing:".1em",color:"#B08D45",background:"rgba(176,141,69,.1)",border:".5px solid rgba(176,141,69,.2)",borderRadius:2,padding:"1px 7px"}}>SESSION RESTORED</span>}</div><div className="dash-name">{data.meta?.name}</div><div className="dash-sub">{data.meta?.tagline}</div></div>
        <div className="dash-hdr-actions">
          <button className={`save-btn${saveStatus==="saved"?" saved":""}`} onClick={handleSave} disabled={saveStatus==="saving"}>{saveLabel}</button>
          <button className="reset-btn" onClick={onReset}>← New Collection</button>
        </div>
      </div>
      <div className="tabs">{TABS.map(t=><button key={t.id} className={`tab-btn${tab===t.id?" active":""}`} onClick={()=>setTab(t.id)}>{t.label}</button>)}</div>
    </div>
    <div className="dash-body">
      {tab==="foundation" &&<FoundationTab d={data}/>}
      {tab==="hierarchy"  &&<HierarchyTab  d={data}/>}
      {tab==="continuity" &&<ContinuityTab d={data}/>}
      {tab==="release"    &&<ReleaseTab    d={data}/>}
      {tab==="crosssell"  &&<CrossSellTab  d={data}/>}
      {tab==="merch"      &&<MerchTab      d={data}/>}
      {tab==="layout"     &&<LayoutTab     d={data} blueprints={blueprints} onActivate={onActivateBlueprint}/>}
      {tab==="render"     &&<RenderTab     d={data} blueprints={blueprints}/>}
      {tab==="guide"      &&<GuideTab/>}
    </div>
  </div>;
}

// ─────────────────────────────────────────────────────────────
// LOADING + INTENT SCREENS
// ─────────────────────────────────────────────────────────────
function Loading({intent}) {
  const [idx,setIdx]=useState(0);
  useEffect(()=>{const t=setInterval(()=>setIdx(i=>(i+1)%MSGS.length),3400);return()=>clearInterval(t);},[]);
  return <div className="loading"><div className="loading-g">✦</div><div className="loading-m">{MSGS[idx]}</div>{intent&&<div className="loading-i">"{intent}"</div>}</div>;
}

function IntentScreen({onGenerate,onViewSaved,savedCount,error}) {
  const [intent,setIntent]=useState("");
  return <div className="intent">
    <div className="intent-mark">Evercrafted Studio · Collection Intelligence Engine</div>
    <h1 className="intent-title">What collection are you building?</h1>
    <p className="intent-sub">Describe your intent in plain language. The system generates the complete collection — hierarchy, continuity, release strategy, cross-sell, merchandising — plus deterministic MJ prompts from the PIE layout engine.</p>
    <div className="intent-form">
      <textarea className="intent-ta" rows={4} value={intent} onChange={e=>setIntent(e.target.value)}
        onKeyDown={e=>{if(e.key==="Enter"&&(e.metaKey||e.ctrlKey)&&intent.trim())onGenerate(intent.trim());}}
        placeholder="e.g. moody autumn wreath collection, dried botanicals, rust dahlias and aged copper, warm earthy palette, 6 products for Etsy"/>
      {error&&<div className="intent-err"><strong>Error:</strong> {error}</div>}
      <button className="intent-btn" onClick={()=>intent.trim()&&onGenerate(intent.trim())} disabled={!intent.trim()}>Generate Collection ✦</button>
      {savedCount>0&&<button className="intent-saved-link" onClick={onViewSaved}>My Saved Collections ({savedCount})</button>}
      <div className="intent-hint">Cmd+Enter to generate · ~25 seconds</div>
    </div>
  </div>;
}

// ─────────────────────────────────────────────────────────────
// APP
// ─────────────────────────────────────────────────────────────
// Session key — persists current collection across artifact re-renders
const SK="ec-session";
async function saveSession(data){try{await window.storage.set(SK,JSON.stringify(data),false);}catch{}}
async function clearSession(){try{await window.storage.delete(SK,false);}catch{}}
async function loadSession(){try{const r=await window.storage.get(SK,false);return r?.value?JSON.parse(r.value):null;}catch{return null;}}

export default function App() {
  const [screen,setScreen]=useState("intent");
  const [data,setData]=useState(null);
  const [error,setError]=useState(null);
  const [intent,setIntent]=useState("");
  const [savedCount,setSavedCount]=useState(0);
  const [blueprints,setBlueprints]=useState({});
  const [restored,setRestored]=useState(false);

  // On mount: restore session and saved count
  useEffect(()=>{
    getManifest().then(m=>setSavedCount(m.length)).catch(()=>{});
    loadSession().then(session=>{
      if(session?.meta?.name){setData(session);setScreen("done");setRestored(true);}
    }).catch(()=>{});
  },[]);

  async function handleGenerate(intentStr) {
    setIntent(intentStr);setError(null);setBlueprints({});setScreen("loading");
    try{
      const result=await generate(intentStr);
      setData(result);setScreen("done");setRestored(false);
      saveSession(result);
    }catch(e){setError(e.message);setScreen("intent");}
  }

  async function handleSave(collectionData) {
    await saveToStorage(collectionData);
    const m=await getManifest();setSavedCount(m.length);
  }

  function handleLoad(collectionData) {
    setData(collectionData);setBlueprints({});setScreen("done");setRestored(false);
    saveSession(collectionData);
  }

  function handleReset() {
    setScreen("intent");setData(null);setError(null);setBlueprints({});setRestored(false);
    clearSession();
  }

  function handleActivateBlueprint(productName,blueprint) {
    setBlueprints(prev=>({...prev,[productName]:blueprint}));
  }

  return <>
    <style>{CSS}</style>
    {screen==="intent"  &&<IntentScreen onGenerate={handleGenerate} onViewSaved={()=>setScreen("saved")} savedCount={savedCount} error={error}/>}
    {screen==="loading" &&<Loading intent={intent}/>}
    {screen==="done"    &&<Dashboard data={data} onReset={handleReset} onSave={handleSave} blueprints={blueprints} onActivateBlueprint={handleActivateBlueprint} restored={restored}/>}
    {screen==="saved"   &&<SavedScreen onBack={()=>setScreen("intent")} onLoad={handleLoad}/>}
  </>;
}

import { useState, useEffect } from "react";

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400;1,500&family=DM+Sans:wght@300;400;500&family=DM+Mono:wght@400;500&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;}

/* INTENT */
.intent{min-height:100vh;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 22px;}
.intent-mark{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.22em;text-transform:uppercase;color:#8A7142;margin-bottom:34px;}
.intent-title{font-family:'Cormorant Garamond',serif;font-size:46px;font-weight:400;font-style:italic;color:#1A1814;text-align:center;line-height:1.08;margin-bottom:14px;max-width:580px;}
.intent-sub{font-size:13.5px;color:#5A5240;text-align:center;margin-bottom:48px;max-width:480px;line-height:1.7;}
.intent-form{width:100%;max-width:600px;display:flex;flex-direction:column;gap:12px;}
.intent-ta{width:100%;background:#fff;border:1px solid #E2DACB;border-radius:5px;padding:20px 22px;color:#1A1814;font-family:'Cormorant Garamond',serif;font-size:18px;font-style:italic;line-height:1.65;resize:vertical;min-height:100px;outline:none;transition:border-color .15s;}
.intent-ta:focus{border-color:#B08D45;box-shadow:0 0 0 3px rgba(176,141,69,.08);}
.intent-ta::placeholder{color:#C8B888;}
.intent-btn{background:#b5703a;color:white;border:none;border-radius:5px;padding:14px 28px;font-family:'DM Sans',sans-serif;font-size:13px;font-weight:500;letter-spacing:.06em;cursor:pointer;transition:background .14s;align-self:flex-end;}
.intent-btn:hover:not(:disabled){background:#a06035;}
.intent-btn:disabled{opacity:.38;cursor:not-allowed;}
.intent-err{background:rgba(180,55,55,.07);border:.5px solid rgba(180,55,55,.2);border-radius:4px;padding:13px 16px;color:#943030;font-size:12.5px;line-height:1.6;}
.intent-hint{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;color:#C8B888;text-align:center;}
.intent-saved-link{background:none;border:.5px solid #D8C8A0;border-radius:4px;padding:10px 18px;font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;cursor:pointer;transition:all .18s;align-self:center;}
.intent-saved-link:hover{border-color:#B08D45;color:#B08D45;}

/* LOADING */
.loading{min-height:100vh;background:#F7F4EE;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:24px;}
.loading-g{font-family:'Cormorant Garamond',serif;font-size:52px;color:#B08D45;animation:breathe 2.6s ease-in-out infinite;}
@keyframes breathe{0%,100%{opacity:.3;transform:scale(1);}50%{opacity:1;transform:scale(1.07);}}
.loading-m{font-size:13px;color:#8A7142;letter-spacing:.04em;text-align:center;min-height:20px;}
.loading-i{font-family:'Cormorant Garamond',serif;font-size:15px;font-style:italic;color:#C8B888;max-width:460px;text-align:center;line-height:1.55;}

/* DASHBOARD */
.dash{background:#F7F4EE;color:#1A1814;min-height:100vh;}
.dash-hdr{padding:28px 32px 0;border-bottom:1px solid #E2DACB;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);}
.dash-hdr-top{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;}
.dash-eye{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.dash-name{font-family:'Cormorant Garamond',serif;font-size:32px;font-weight:500;line-height:1.1;margin-bottom:4px;}
.dash-sub{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:15px;color:#8A7142;margin-bottom:18px;}
.dash-hdr-actions{display:flex;gap:8px;flex-shrink:0;margin-top:4px;flex-wrap:wrap;justify-content:flex-end;}
.reset-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;padding:6px 13px;background:none;border:.5px solid #C8B888;color:#8A7142;cursor:pointer;border-radius:2px;transition:all .18s;white-space:nowrap;}
.reset-btn:hover{border-color:#B08D45;color:#B08D45;}
.save-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.12em;text-transform:uppercase;padding:6px 14px;background:none;border:.5px solid #B08D45;color:#B08D45;cursor:pointer;border-radius:2px;transition:all .18s;white-space:nowrap;}
.save-btn:hover:not(:disabled){background:rgba(176,141,69,.08);}
.save-btn.saved{border-color:#3D7A4A;color:#3D7A4A;}
.save-btn:disabled{opacity:.5;cursor:not-allowed;}
.tabs{display:flex;gap:0;overflow-x:auto;scrollbar-width:none;}
.tabs::-webkit-scrollbar{display:none;}
.tab-btn{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.1em;text-transform:uppercase;padding:10px 14px;background:none;border:none;cursor:pointer;color:#8A7142;border-bottom:2px solid transparent;white-space:nowrap;transition:all .18s;}
.tab-btn:hover{color:#1A1814;}
.tab-btn.active{color:#1A1814;border-bottom-color:#B08D45;}
.dash-body{padding:30px 32px;max-width:980px;}

/* SAVED SCREEN */
.saved-screen{min-height:100vh;background:#F7F4EE;}
.saved-hdr{padding:28px 32px;border-bottom:1px solid #E2DACB;background:linear-gradient(180deg,#F0EBDC 0%,#F7F4EE 100%);display:flex;align-items:flex-start;justify-content:space-between;gap:16px;}
.saved-hdr-eye{font-family:'DM Mono',monospace;font-size:10px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.saved-hdr-title{font-family:'Cormorant Garamond',serif;font-size:28px;font-weight:500;color:#1A1814;line-height:1.1;}
.saved-body{padding:30px 32px;max-width:980px;}
.saved-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
.saved-card{background:#fff;border:.5px solid #E2DACB;border-radius:5px;padding:18px 20px;}
.saved-card-name{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:3px;color:#1A1814;}
.saved-card-tag{font-size:11px;color:#8A7142;margin-bottom:10px;font-family:'Cormorant Garamond',serif;font-style:italic;}
.saved-card-dots{display:flex;gap:5px;margin-bottom:10px;}
.saved-card-dot{width:13px;height:13px;border-radius:50%;border:.5px solid rgba(0,0,0,.07);}
.saved-card-meta{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:#C8B888;margin-bottom:14px;}
.saved-card-actions{display:flex;gap:8px;}
.saved-load-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;padding:6px 14px;background:#b5703a;color:white;border:none;border-radius:2px;cursor:pointer;transition:background .14s;}
.saved-load-btn:hover{background:#a06035;}
.saved-load-btn:disabled{opacity:.5;cursor:not-allowed;}
.saved-del-btn{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;padding:6px 12px;background:none;border:.5px solid #E2DACB;color:#C8B888;border-radius:2px;cursor:pointer;transition:all .14s;}
.saved-del-btn:hover{border-color:rgba(180,55,55,.3);color:#943030;}
.saved-empty{text-align:center;padding:70px 20px;}
.saved-empty-g{font-family:'Cormorant Garamond',serif;font-size:34px;font-style:italic;color:#C8B888;margin-bottom:10px;}
.saved-empty-t{font-size:13px;color:#8A7142;line-height:1.6;}

/* SHARED */
.eyebrow{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:#8A7142;margin-bottom:14px;}
.pull{background:#EFE9D8;border-left:3px solid #B08D45;padding:18px 22px;margin-bottom:26px;}
.pull p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:18px;line-height:1.62;color:#332B1A;}
.hr{border:none;border-top:1px solid #E2DACB;margin:24px 0;}
.note{background:#FFFBF0;border:.5px solid #E8D49C;border-radius:4px;padding:12px 15px;margin-bottom:18px;font-size:12px;color:#4A3E20;line-height:1.65;}
.note strong{font-weight:500;}
.sec-title{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;margin-bottom:12px;}

/* FOUNDATION */
.swatch-row{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap;}
.swatch{flex:1;min-width:90px;border-radius:4px;overflow:hidden;border:.5px solid #E2DACB;}
.swatch-color{height:48px;}
.swatch-label{background:#fff;padding:7px 9px;}
.swatch-name{font-size:11px;font-weight:500;margin-bottom:1px;}
.swatch-hex{font-family:'DM Mono',monospace;font-size:9px;color:#8A7142;}
.profile-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:24px;}
.profile-card{background:#fff;border:.5px solid #E2DACB;padding:12px 14px;border-radius:4px;}
.profile-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;margin-bottom:4px;}
.profile-val{font-size:12.5px;line-height:1.5;color:#1A1814;}
.sig-block{background:#1A1814;border-radius:5px;padding:20px 24px;margin-bottom:24px;}
.sig-row{display:flex;gap:12px;padding:7px 0;border-bottom:.5px solid #2E2A22;}
.sig-row:last-child{border-bottom:none;}
.sig-lbl{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.08em;text-transform:uppercase;color:#B08D45;min-width:150px;flex-shrink:0;padding-top:2px;}
.sig-val{color:#E0D8C4;line-height:1.55;font-family:'Cormorant Garamond',serif;font-size:14px;}

/* HIERARCHY */
.price-bar{background:#1A1814;border-radius:5px;padding:16px 20px;display:flex;justify-content:space-between;flex-wrap:wrap;gap:12px;margin-bottom:24px;}
.pb-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.pb-val{font-family:'DM Mono',monospace;font-size:17px;color:#E0D8C4;}
.role-list{display:flex;flex-direction:column;gap:9px;margin-bottom:24px;}
.role-card{background:#fff;border:.5px solid #E2DACB;border-left:4px solid;border-radius:4px;padding:14px 18px;display:flex;justify-content:space-between;align-items:flex-start;gap:14px;flex-wrap:wrap;}
.role-left{flex:1;min-width:200px;}
.role-tag{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.role-name{font-family:'Cormorant Garamond',serif;font-size:17px;font-weight:600;margin-bottom:3px;}
.role-form{font-size:11px;color:#5A5240;margin-bottom:5px;}
.role-meta{font-size:11px;color:#5A5240;line-height:1.55;}
.role-price{font-family:'DM Mono',monospace;font-size:21px;font-weight:500;color:#1A1814;white-space:nowrap;flex-shrink:0;}

/* CONTINUITY */
.score-strip{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.score-card{flex:1;min-width:80px;background:#1A1814;border-radius:4px;padding:12px 14px;text-align:center;}
.score-val{font-family:'DM Mono',monospace;font-size:18px;color:#B08D45;margin-bottom:3px;}
.score-val.big{font-family:'Cormorant Garamond',serif;font-size:14px;font-style:italic;}
.score-lbl-sm{font-family:'DM Mono',monospace;font-size:7.5px;letter-spacing:.1em;text-transform:uppercase;color:#5A5248;}
.thread-card{background:#fff;border:.5px solid #E2DACB;padding:13px 16px;border-radius:4px;margin-bottom:9px;}
.thread-verdict{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.1em;text-transform:uppercase;padding:2px 8px;border-radius:2px;display:inline-block;margin-bottom:5px;}
.thread-verdict.strong{background:rgba(61,122,74,.1);color:#3D7A4A;}
.thread-verdict.needs-attention{background:rgba(180,140,40,.1);color:#8A6A10;}
.thread-verdict.critical{background:rgba(180,55,55,.1);color:#943030;}
.thread-name{font-family:'Cormorant Garamond',serif;font-weight:600;font-size:15px;margin-bottom:4px;}
.thread-body{font-size:11.5px;color:#5A5240;line-height:1.62;}
.chk-list{display:flex;flex-direction:column;gap:7px;margin-bottom:20px;}
.chk-row{display:flex;align-items:center;gap:9px;font-size:12px;color:#332B1A;}
.chk-icon{font-size:13px;flex-shrink:0;}
.chk-icon.ok{color:#3D7A4A;}
.chk-icon.fail{color:#943030;}

/* RELEASE */
.timeline{display:flex;flex-direction:column;gap:0;margin-bottom:24px;}
.phase-card{border-left:3px solid #B08D45;padding:4px 0 24px 20px;position:relative;}
.phase-card::before{content:'';position:absolute;left:-7px;top:5px;width:11px;height:11px;border-radius:50%;background:#B08D45;}
.phase-card:last-child{padding-bottom:0;}
.phase-num{font-family:'DM Mono',monospace;font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:#8A7142;margin-bottom:3px;}
.phase-title{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:7px;}
.phase-row{font-size:12px;color:#5A5240;line-height:1.65;margin-bottom:2px;}
.phase-row b{color:#332B1A;font-weight:500;}

/* CROSS-SELL */
.system-card{background:#fff;border:.5px solid #E2DACB;padding:14px 18px;border-radius:4px;margin-bottom:10px;}
.system-name{font-family:'Cormorant Garamond',serif;font-size:16px;font-weight:600;margin-bottom:7px;color:#B08D45;}
.system-flow{font-size:12px;color:#332B1A;line-height:1.7;}
.bundle-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:24px;}
.bundle-card{background:#fff;border:.5px solid #E2DACB;border-radius:4px;padding:14px 16px;}
.bundle-name{font-family:'Cormorant Garamond',serif;font-size:15px;font-weight:600;margin-bottom:3px;}
.bundle-type{font-family:'DM Mono',monospace;font-size:7.5px;letter-spacing:.1em;text-transform:uppercase;color:#8A7142;margin-bottom:7px;}
.bundle-contents{font-size:11px;color:#5A5240;line-height:1.55;margin-bottom:9px;}
.bundle-pr{display:flex;align-items:baseline;gap:7px;margin-bottom:3px;}
.bundle-was{font-family:'DM Mono',monospace;font-size:10px;color:#A89878;text-decoration:line-through;}
.bundle-now{font-family:'DM Mono',monospace;font-size:16px;color:#B08D45;font-weight:500;}
.bundle-save{font-family:'DM Mono',monospace;font-size:8.5px;color:#3D7A4A;}

/* MERCH */
.merch-block{margin-bottom:20px;}
.merch-title{font-family:'Cormorant Garamond',serif;font-size:15px;font-weight:600;margin-bottom:5px;}
.merch-body{font-size:12px;color:#5A5240;line-height:1.65;}
.flow-list{list-style:none;counter-reset:fl;margin-bottom:24px;}
.flow-list li{counter-increment:fl;padding:8px 0 8px 30px;border-bottom:.5px solid #EDE6D4;position:relative;font-size:12px;color:#332B1A;line-height:1.55;}
.flow-list li::before{content:counter(fl);position:absolute;left:0;top:8px;font-family:'DM Mono',monospace;font-size:9px;color:#B08D45;border:.5px solid #B08D45;border-radius:50%;width:17px;height:17px;display:flex;align-items:center;justify-content:center;}

/* GUIDE */
.guide-thesis{background:#EFE9D8;border-left:3px solid #B08D45;padding:18px 22px;margin-bottom:28px;}
.guide-thesis p{font-family:'Cormorant Garamond',serif;font-style:italic;font-size:17px;line-height:1.62;color:#332B1A;}
.guide-section{margin-bottom:32px;}
.guide-h2{font-family:'Cormorant Garamond',serif;font-size:20px;font-weight:600;margin-bottom:10px;padding-bottom:8px;border-bottom:.5px solid #E2DACB;color:#1A1814;}
.guide-h3{font-family:'DM Sans',sans-serif;font-size:12px;font-weight:500;color:#1A1814;margin:14px 0 6px;letter-spacing:.01em;}
.guide-p{font-size:12.5px;color:#332B1A;line-height:1.72;margin-bottom:10px;}
.guide-ul{padding-left:18px;margin-bottom:12px;}
.guide-ul li{font-size:12px;color:#332B1A;line-height:1.65;margin-bottom:4px;}
.guide-code{background:#1A1814;border-radius:4px;padding:13px 16px;margin:6px 0 14px;font-family:'DM Mono',monospace;font-size:10px;color:#D4C8B0;line-height:1.7;white-space:pre-wrap;word-break:break-word;}
.guide-wrong{background:rgba(180,55,55,.06);border:.5px solid rgba(180,55,55,.15);border-radius:4px;padding:10px 14px;margin-bottom:6px;font-family:'DM Mono',monospace;font-size:10px;color:#7A3A36;line-height:1.6;}
.guide-right{background:rgba(61,122,74,.06);border:.5px solid rgba(61,122,74,.18);border-radius:4px;padding:10px 14px;margin-bottom:14px;font-family:'DM Mono',monospace;font-size:10px;color:#2A5A34;line-height:1.6;}
.guide-label{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.12em;text-transform:uppercase;color:#8A7142;margin-bottom:4px;}
.ref-table{width:100%;border-collapse:collapse;margin-bottom:24px;}
.ref-table th{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;padding:8px 12px;border-bottom:1.5px solid #E2DACB;text-align:left;background:#F7F4EE;}
.ref-table td{padding:9px 12px;border-bottom:.5px solid #EDE6D4;font-size:11.5px;color:#332B1A;vertical-align:top;line-height:1.55;}
.ref-table tr:last-child td{border-bottom:none;}
.ref-table td:first-child{font-family:'DM Mono',monospace;font-size:10px;color:#1A1814;white-space:nowrap;}
.ref-table td:nth-child(2){color:#5A5240;}
.ref-table td:nth-child(3){color:#3A4A3A;}
.ref-table tr:hover td{background:rgba(176,141,69,.04);}
.params-grid{display:grid;grid-template-columns:auto 1fr;gap:6px 16px;margin-bottom:16px;font-size:12px;}
.params-key{font-family:'DM Mono',monospace;font-size:10px;color:#B08D45;white-space:nowrap;}
.params-val{color:#332B1A;line-height:1.55;}

/* RENDER */
.genome{background:#EFE9D8;border:.5px solid #D8C8A0;border-radius:4px;padding:12px 15px;margin-bottom:13px;}
.genome-lbl{font-family:'DM Mono',monospace;font-size:8px;letter-spacing:.14em;text-transform:uppercase;color:#8A7142;margin-bottom:5px;}
.genome-str{font-family:'DM Mono',monospace;font-size:9.5px;color:#6A5420;word-break:break-all;line-height:1.6;}
.prompt-block{background:#1A1814;border-radius:5px;margin-bottom:20px;overflow:hidden;}
.prompt-hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #2E2A24;gap:10px;}
.prompt-lbl{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:#9A8860;flex:1;}
.copy-btn{font-family:'DM Mono',monospace;font-size:8.5px;letter-spacing:.08em;text-transform:uppercase;padding:4px 10px;background:none;border:.5px solid #3A3428;color:#9A8860;cursor:pointer;border-radius:2px;transition:all .18s;}
.copy-btn:hover,.copy-btn.ok{border-color:#B08D45;color:#B08D45;}
.prompt-txt{font-family:'DM Mono',monospace;font-size:10px;color:#D4C8B0;padding:14px;line-height:1.72;white-space:pre-wrap;word-break:break-word;}
.render-hdr{font-family:'Cormorant Garamond',serif;font-size:19px;font-weight:600;margin-bottom:4px;}
.render-sub{font-size:11.5px;color:#8A7142;margin-bottom:13px;}
.condensed-card{background:#fff;border:.5px solid #E2DACB;padding:12px 16px;border-radius:4px;margin-bottom:9px;}
.condensed-name{font-weight:500;font-size:12.5px;margin-bottom:4px;}
.condensed-note{font-size:11px;color:#5A5240;line-height:1.55;}
`;

const TABS = [
  { id:"foundation", label:"Foundation"    },
  { id:"hierarchy",  label:"Hierarchy"     },
  { id:"continuity", label:"Continuity"    },
  { id:"release",    label:"Release"       },
  { id:"crosssell",  label:"Cross-Sell"    },
  { id:"merch",      label:"Merchandising" },
  { id:"render",     label:"Render"        },
  { id:"guide",      label:"Render Guide"  },
];

const MSGS = [
  "Reading your intent…",
  "Mapping emotional architecture…",
  "Assigning hierarchy roles and botanicals…",
  "Threading continuity logic…",
  "Building release strategy…",
  "Composing cross-sell systems…",
  "Building visual merchandising plan…",
  "Finalising the collection package…",
];

const SYSTEM = `You are the Evercrafted Collection Intelligence Engine. Transform any creative intent into a complete luxury faux botanical wreath collection system.

Return ONLY valid JSON. No backticks, no markdown, no preamble, no trailing text. First character must be { and last must be }. All string values must be on a single line — no literal newlines inside values.

=== HARD RULES ===
- NEVER use cherry blossoms or pussy willow
- Every wreath/garland product MUST include integrated warm LED lights
- Composition formulas from ONLY these 12: Crescent, Side Sweep, Bottom Heavy, Diagonal Flow, Twin Cluster, Corner Cluster, Wild Asymmetry, Half Ring, Top Cluster, Spiral Flow, Classic Balanced, Garden Scatter
- Hero product is always a 24-inch door wreath
- In render prompts: "luxury handcrafted faux botanical", "premium silk florals" — NEVER "artificial", "fake", "plastic"
- Palette: exactly 5 swatches with evocative names ("Midnight Moss" not "Dark Green")
- All product names include the collection name as a prefix

=== HIERARCHY ROLES AND COLORS ===
Premium Anchor (#1F3326): Most complex, highest price. Large garland or statement piece.
Hero (#B08D45): Emotional centerpiece. Always 24-inch door wreath.
Supporting (#5C1A2E): Expands without competing. Medium scale.
Gateway (#8A7142): Entry price. Simpler version of the signature form.
Atmospheric Filler (#B8C4BE): Small scale, high continuity. Candle ring or small swag.
Accent (#F0E8D8 border #C8B888): Impulse add. Ribbon bundle, picks, accessories. Lowest price.

=== WGS GENOME FORMAT ===
For the silenceArc field on each product, use clock-position language: e.g. "5 to 7 o'clock warm grapevine exposed"

=== JSON SCHEMA ===
{
  "meta": { "name": "Collection Name", "tagline": "Season · Atmosphere · N-Product Collection System", "pullQuote": "2-3 sentence editorial positioning", "season": "season string", "atmosphere": "atmosphere name" },
  "palette": [{"name": "Evocative Name", "hex": "#XXXXXX"}],
  "foundation": {
    "profile": [["Collection name","value"],["Atmosphere archetype","value"],["Season / timing","value"],["Palette identity","value"],["Movement archetype","value"],["Texture language","value"],["Emotional purchase trigger","value"],["Hero formula","value"],["Variation formulas","value"],["Collection ambition","value"]],
    "signature": [["Emotional Atmosphere","value"],["Structural Movement","value"],["Palette Language","value"],["Density Profile","value"],["Asymmetry Direction","value"],["Texture Language","value"],["Composition Formula","value"],["Silence Arc","value"],["Seasonal Resonance","value"],["Emotion Tags","[\"tag1\", \"tag2\", \"tag3\", \"tag4\", \"tag5\", \"tag6\"]"]]
  },
  "hierarchy": [
    {
      "role": "Premium Anchor",
      "color": "#1F3326",
      "name": "Full Product Name",
      "form": "6ft mantel garland",
      "formula": "Crescent",
      "scale": "72-inch",
      "price": 295,
      "meta": "2-3 sentence commercial rationale",
      "heroFloral": "exact species, finish, size in inches, count — e.g. three large ivory wax-finish faux silk magnolia blooms 5-6 inches across",
      "secondaryFloral": "exact species, finish, size, count — e.g. five dusty rose faux ranunculus 3-4 inches bud-to-open variety",
      "accentMaterials": "all accent elements with size and count — e.g. seven antiqued silver faux pinecones 2-3 inches, three burgundy faux berry clusters",
      "greeneryMix": "specific greenery species — e.g. frosted mixed pine, warm sage eucalyptus, dried cedar sprigs",
      "silenceArc": "exact clock range of exposed base — e.g. 5 to 7 o'clock warm grapevine exposed"
    }
  ],
  "continuity": {
    "threads": [{"name":"Atmosphere","analysis":"specific analysis","verdict":"strong"},{"name":"Palette","analysis":"analysis","verdict":"strong"},{"name":"Movement","analysis":"analysis","verdict":"strong"},{"name":"Texture","analysis":"analysis","verdict":"strong"}],
    "overallScore":"Excellent","scoreRationale":"one sentence",
    "qualityGates": [{"label":"Atmosphere archetype consistent across all products","pass":true},{"label":"All six hierarchy roles assigned","pass":true},{"label":"No continuity flags unresolved","pass":true},{"label":"Release strategy assigns each product to a phase","pass":true},{"label":"Cross-sell operates at room level","pass":true},{"label":"Photography direction consistent across all products","pass":true}]
  },
  "release": [
    {"phase":"Phase 1","title":"Anticipation","timing":"4-6 weeks before peak","products":"which products","copyHook":"hook","buyerPsychology":"who and why","emotionalArc":"beat"},
    {"phase":"Phase 2","title":"Hero Launch","timing":"2-3 weeks before peak","products":"which products","copyHook":"hook","buyerPsychology":"highest-intent window","emotionalArc":"peak beat"},
    {"phase":"Phase 3","title":"Full Collection","timing":"At season peak","products":"remaining products","copyHook":"completion narrative","buyerPsychology":"re-engaging earlier buyers","emotionalArc":"ecosystem completion"},
    {"phase":"Late Season","title":"Sustain","timing":"2-3 weeks post-peak","products":"bundle focus","copyHook":"transition narrative","buyerPsychology":"late-season buyer","emotionalArc":"closing arc"}
  ],
  "crossSell": {
    "systems": [{"name":"Entry System (Door / Porch)","flow":"which products and how"},{"name":"Mantel System","flow":"which products and how"},{"name":"Living Room / Table System","flow":"which products and how"}],
    "bundles": [{"name":"Bundle Name","type":"Room Completion Bundle","contents":"product list","sum":400,"final":360,"pct":0.1}]
  },
  "merch": {
    "heroShot":"collection hero shot direction","familyGroupings":"family grouping direction","individualShots":"consistent individual shot direction","detailShots":"macro shot direction",
    "shopFrontFlow":["step 1","step 2","step 3","step 4","step 5","step 6"],
    "displayPrinciples":"grouping principles"
  }
}

Generate a commercially sophisticated, emotionally intelligent collection. Every section must be specific to this collection. Pull Quote must feel worthy of a luxury brand. Render prompts are generated on demand — do not include a render section.`;

/* ── GENERATE ────────────────────────────────────── */
async function generate(intent) {
  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: 8000, system: SYSTEM, messages: [{ role: "user", content: `COLLECTION INTENT: ${intent}` }] })
  });
  const d = await r.json();
  if (d.error) throw new Error(d.error.message);
  const raw = d.content[0].text;
  const clean = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try { return JSON.parse(clean); }
  catch { throw new Error("Couldn't parse the response — try again."); }
}

/* ── RENDER ENGINE ───────────────────────────────── */

function detectFormType(form) {
  const f = (form || "").toLowerCase();
  if (f.includes("stair")) return "stair_garland";
  if (f.includes("mantel") || f.includes("mantle")) return "mantel_garland";
  if ((f.includes("door") || f.includes("swag")) && f.includes("garland")) return "door_garland";
  if (f.includes("garland")) return "garland";
  if (f.includes("candle") || f.includes("small") || f.includes("filler") || f.includes("ring")) return "small_accent";
  return "door_wreath";
}

const FORM_FRAMING = {
  door_wreath: `
FRAMING: Door wreath — full isolated product view
- Frame: complete wreath circle against pale dove-gray painted wall, front-facing flat, wreath occupies ~65% of frame height, breathing room on all sides
- Scale anchor: wreath diameter matches its stated inch size — a 24-inch wreath appears as a 24-inch object relative to the wall surface
- Density: full coverage appropriate, florals read clearly at product photography scale
- Camera: 85mm lens, flat frontal angle, soft studio daylight from upper-left, no perspective distortion
- --ar 1:1 --s 100 --style raw --v 7`,

  mantel_garland: `
FRAMING: Mantel garland — full mantel contextual view
- Frame: garland draped naturally from end to end of a white painted wood mantel surround — mantel is white painted wood only, not gray, not sage, not mint, not cream, not marble, not any other color or material
- Scale anchor: each floral bloom visibly smaller than the mantel shelf depth — a 5-inch bloom appears as a 5-inch object against the 10-12 inch mantel shelf
- Density: generous greenery visible between floral groupings — florals cluster in 2-3 groupings along the length, not wall-to-wall
- Camera: front-facing slight elevation, 50mm, white painted mantel surround and firebox opening suggest architectural context in soft focus below
- --ar 16:9 --s 40 --style raw --v 7`,

  stair_garland: `
FRAMING: Stair garland — section view only (critical)
- Frame: approximately 4 to 5 feet of garland visible in frame — remainder trails off-frame above and below. NEVER attempt to show the full garland length. This is a section, not a product shot.
- Scale anchor: each floral bloom stated as proportionally smaller than the stair newel post cap visible in frame. A 5-inch bloom appears as a 5-inch object beside a 4-inch newel post cap. State this relationship explicitly in the prompt.
- Density: generous negative space between floral groupings — garland drapes naturally with visible greenery between each cluster. Not wall-to-wall, not crammed. Florals appear in 2-3 distinct groupings within the visible section.
- Camera: slight 3/4 angle looking up the staircase, 35-50mm, painted white balusters and handrail visible as architectural context in foreground, stair treads suggesting depth in background
- --ar 4:5 --s 30 --style raw --v 7`,

  door_garland: `
FRAMING: Door garland / swag — architectural context view
- Frame: garland draped over exterior door top, door frame and hardware visible as architectural anchor
- Scale anchor: florals proportional to door hardware — a 5-inch bloom appears smaller than the door width
- Density: natural drape with greenery visible between floral groupings
- Camera: slight 3/4 angle, 35-50mm, door as architectural anchor, seasonal light quality
- --ar 4:5 --s 40 --style raw --v 7`,

  garland: `
FRAMING: Garland — section view
- Frame: approximately 4-5 feet of garland visible in frame, remainder trailing off-frame
- Scale anchor: florals proportional to any architectural element visible in frame
- Density: generous greenery visible between floral groupings, natural drape
- Camera: slight angle showing dimensional depth, 50mm
- --ar 16:9 --s 40 --style raw --v 7`,

  small_accent: `
FRAMING: Small accent piece — close product view
- Frame: small form against neutral pale background, generous negative space around it
- Scale anchor: small product — 8-12 inch maximum diameter or length, reads as tabletop accessory
- Density: intentionally minimal — this is a subtle accent, not a hero
- Camera: slight elevation angle, 85mm, clean studio lighting
- --ar 1:1 --s 80 --style raw --v 7`,
};
const RENDER_SYSTEM = `You are the Evercrafted Render Engine. Generate a complete MJ V7 render package for a single faux botanical product.

You will receive: (1) collection context, (2) exact botanical composition, (3) FRAMING RULES specific to this product's physical form. Apply all three in every prompt.

Return ONLY valid JSON. No backticks, no markdown, no preamble. First character must be { and last must be }. All string values on a single line — no literal newlines inside values.

SPECIES-SPECIFIC DEFAULTS TO FIGHT — apply these when the named species appears in botanicals:
- Hellebores: always add "wax-finish faux silk hellebores, cups semi-closed or three-quarter open, no visible stamens protruding, not drooping, not dewy, not fresh-cut, petals hold their form" — MJ defaults to drooping fresh open cup
- Anemones: always add "premium faux silk anemones, petals fully formed and dimensional, dark centre disc flat and defined, not drooping, not fresh" — MJ defaults to fresh florist anemone
- Ranunculus: always add "wax-finish faux silk ranunculus, fully dimensional not flat, not fresh-cut not florist bowl shape"
- Pine/fir: always name the exact color — "warm sage-green mixed pine" or "ice-dusted silver-green pine" — never leave pine color to MJ or it defaults blue-gray Christmas
- Eucalyptus: always name the exact color and finish — "frosted blue-grey eucalyptus" or "warm sage eucalyptus" — never just "eucalyptus"
- Berry clusters: always add "faux [color] berry clusters, each berry a dimensional sphere, clusters not drooping, not wilted, stems upright"
- Pinecones: always add "each faux pinecone a fully discrete separated element, clear negative space between adjacent pinecones, no pinecone touching or overlapping another"
- Magnolia blooms: always add "faux silk magnolia bloom, petals fully formed not open flat, not fresh white flower"
- Mercury glass elements: always add "mercury glass finish, antiqued silver with dark depth, not chrome, not shiny modern silver"

HARD RULES:
- Use ONLY the exact botanicals specified — do not add, substitute, or remove any element
- NEVER use cherry blossoms or pussy willow
- Every prompt opens with material register: "Luxury handcrafted faux botanical [form], premium artificial silk and polyester florals..."
- All placements use clock positions — never vague directional language
- Name and expose the silence arc at its exact clock range
- Faux botanical register throughout — NEVER "artificial", "fake", "plastic"
- Always include: "integrated warm white LED micro-strand lights threaded through interior construction, visible as soft warm glow points between foliage, not prominent string lights, not visible cord"
- Apply the FRAMING RULES exactly as given — camera angle, scale anchor, density spec, aspect ratio, and stylize value all come from the FRAMING RULES block
- Single-shot prompt: 220+ words, complete 9-step architecture
- Phase prompts: 80–120 words each, their single layer only

SPATIAL SEPARATION (critical — prevents elements merging):
- Phase 3 must explicitly state: each accent element positioned in negative space BETWEEN florals, never overlapping any bloom face, never appearing in front of any petal, each element a fully discrete form with clear spatial separation from all florals
- --no block must include: [accent type] overlapping florals, [accent type] inside flowers, [accent type] in front of blooms, elements merging, blended layers

PHASE ARCHITECTURE:
Phase 1 — Greenery only. No florals, no accents at all. Describe every species in greeneryMix, clock-position coverage, exposed silence arc at exact clock range, warm LED lights. Apply FRAMING RULES camera and params. End with --no block and params.
Phase 2 — Hero AND secondary florals only. Open with: "Use Phase 1 render as --iw 1.8–2.2 image reference." Place heroFloral with exact clock positions and facing directions for each bloom. Then place secondaryFloral with its own clock positions and bud-stage variety. Do NOT re-describe greenery. Apply FRAMING RULES params.
Phase 3 — Accent layer only. Open with: "Use Phase 2 render as --iw 1.4–1.8 image reference." Use exact accentMaterials. State spatial separation from all florals explicitly. Do NOT re-describe anything from prior phases. Apply FRAMING RULES params.

WGS GENOME: WGS1|[size_in]|[formula-slug]|[density: sparse/moderate/lush]|[palette-slug]|[focal-species-color]|[secondary]|[accents]|[greenery]|[led-warm-strand]|[atmosphere-slug]|[season-slug]|[emotion-tags]|[CODEID]

JSON SCHEMA:
{
  "genome": "WGS1|...",
  "singleShot": "Full 220+ word single-shot prompt with exact botanicals, scale anchor, FRAMING RULES applied — single line",
  "phase1": "Greenery-only — single line — FRAMING RULES camera and params applied",
  "phase2": "heroFloral + secondaryFloral both placed with clock positions — single line — opens with --iw instruction — FRAMING RULES params",
  "phase3": "accentMaterials with explicit spatial separation from all florals — single line — opens with --iw instruction — FRAMING RULES params",
  "noBlock": "--no fresh flowers, real plants, live botanicals, organic, dew, wilting, drooping florals, dewy petals, fresh-cut, florist arrangement, fresh branch arrangement, fresh bough, spring branch, cherry blossom branch, botanical bough, organic stems, illustrated, painted, digital art, flat lay, overhead shot, bird's eye view, [accent type] overlapping florals, [accent type] inside flowers, elements merging, blended layers, [collection-specific additions based on palette and atmosphere]"
}`;

async function generateRenderPrompt(collection, product) {
  const sig = collection.foundation?.signature || [];
  const findSig = label => (sig.find(([l]) => l === label) || [])[1] || "";

  const formType = detectFormType(product.form);
  const framingRules = FORM_FRAMING[formType] || FORM_FRAMING["door_wreath"];

  const ctx = [
    "COLLECTION CONTEXT:",
    `Name: ${collection.meta?.name}`,
    `Atmosphere: ${collection.meta?.atmosphere}`,
    `Season: ${collection.meta?.season}`,
    `Palette: ${(collection.palette || []).map(p => `${p.name} (${p.hex})`).join(", ")}`,
    `Structural Movement: ${findSig("Structural Movement")}`,
    `Texture Language: ${findSig("Texture Language")}`,
    `Density Profile: ${findSig("Density Profile")}`,
    "",
    "PRODUCT TO RENDER:",
    `Name: ${product.name}`,
    `Role: ${product.role}`,
    `Physical Form: ${product.form}`,
    `Detected Form Type: ${formType}`,
    `Composition Formula: ${product.formula}`,
    `Scale: ${product.scale}`,
    "",
    "BOTANICAL COMPOSITION — use these exact specifications, no substitutions:",
    `Hero Floral: ${product.heroFloral || "not specified"}`,
    `Secondary Floral: ${product.secondaryFloral || "not specified"}`,
    `Accent Materials: ${product.accentMaterials || "not specified"}`,
    `Greenery Mix: ${product.greeneryMix || "not specified"}`,
    `Silence Arc: ${product.silenceArc || "not specified"}`,
    "",
    framingRules,
  ].join("\n");

  const r = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 3500,
      system: RENDER_SYSTEM,
      messages: [{ role: "user", content: ctx }]
    })
  });
  const d = await r.json();
  if (d.error) throw new Error(d.error.message);
  const raw = d.content[0].text;
  const clean = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  try { return JSON.parse(clean); }
  catch { throw new Error("Render package couldn't be parsed. Try again."); }
}

/* ── STORAGE ─────────────────────────────────────── */
const MK = "ec-manifest";
const CP = "ec-col:";

async function getManifest() {
  try { const m = await window.storage.get(MK, false); return m ? JSON.parse(m.value) : []; }
  catch { return []; }
}

async function saveToStorage(data) {
  const id = Date.now().toString();
  await window.storage.set(CP + id, JSON.stringify(data), false);
  const manifest = await getManifest();
  const entry = {
    id, savedAt: new Date().toLocaleDateString("en-US", { month:"short", day:"numeric", year:"numeric" }),
    name: data.meta?.name || "Untitled",
    tagline: data.meta?.tagline || "",
    palette: (data.palette || []).slice(0, 5).map(p => p.hex),
  };
  await window.storage.set(MK, JSON.stringify([entry, ...manifest]), false);
  return id;
}

async function loadFromStorage(id) {
  try { const c = await window.storage.get(CP + id, false); return c ? JSON.parse(c.value) : null; }
  catch { return null; }
}

async function deleteFromStorage(id) {
  try { await window.storage.delete(CP + id, false); } catch {}
  const manifest = await getManifest();
  await window.storage.set(MK, JSON.stringify(manifest.filter(m => m.id !== id)), false);
}

/* ── COPY BUTTON ─────────────────────────────────── */
function CopyBtn({ text }) {
  const [ok, setOk] = useState(false);
  return (
    <button className={`copy-btn${ok ? " ok" : ""}`} onClick={() => {
      navigator.clipboard.writeText(text).catch(() => {});
      setOk(true); setTimeout(() => setOk(false), 2400);
    }}>{ok ? "Copied ✓" : "Copy"}</button>
  );
}

/* ── TAB COMPONENTS ──────────────────────────────── */
function FoundationTab({ d }) {
  return (
    <div>
      <div className="eyebrow">Collection Foundation Profile</div>
      <div className="pull"><p>{d.meta?.pullQuote}</p></div>
      <div className="sec-title">Palette Identity</div>
      <div className="swatch-row">
        {(d.palette || []).map((p, i) => (
          <div key={i} className="swatch">
            <div className="swatch-color" style={{ background: p.hex }} />
            <div className="swatch-label"><div className="swatch-name">{p.name}</div><div className="swatch-hex">{p.hex}</div></div>
          </div>
        ))}
      </div>
      <div className="sec-title">Foundation Profile</div>
      <div className="profile-grid">
        {(d.foundation?.profile || []).map(([l, v], i) => (
          <div key={i} className="profile-card"><div className="profile-lbl">{l}</div><div className="profile-val">{v}</div></div>
        ))}
      </div>
      <div className="sec-title">Signature Spec Block</div>
      <div className="sig-block">
        {(d.foundation?.signature || []).map(([l, v], i) => (
          <div key={i} className="sig-row"><span className="sig-lbl">{l}</span><span className="sig-val">{v}</span></div>
        ))}
      </div>
    </div>
  );
}

function HierarchyTab({ d }) {
  const prices = (d.hierarchy || []).map(h => h.price).filter(p => p > 0);
  const total = prices.reduce((s, p) => s + p, 0);
  return (
    <div>
      <div className="eyebrow">Collection Hierarchy Map</div>
      {prices.length > 0 && (
        <div className="price-bar">
          <div><div className="pb-lbl">Entry</div><div className="pb-val">${Math.min(...prices)}</div></div>
          <div><div className="pb-lbl">Average</div><div className="pb-val">${Math.round(total / prices.length)}</div></div>
          <div><div className="pb-lbl">Premium Ceiling</div><div className="pb-val">${Math.max(...prices)}</div></div>
          <div><div className="pb-lbl">Collection Total</div><div className="pb-val">${total}</div></div>
          <div><div className="pb-lbl">Products</div><div className="pb-val">{d.hierarchy.length}</div></div>
        </div>
      )}
      <div className="role-list">
        {(d.hierarchy || []).map((h, i) => (
          <div key={i} className="role-card" style={{ borderLeftColor: h.color }}>
            <div className="role-left">
              <div className="role-tag">{h.role}</div>
              <div className="role-name">{h.name}</div>
              <div className="role-form"><strong>{h.form}</strong> · {h.formula} · {h.scale}</div>
              <div className="role-meta">{h.meta}</div>
            </div>
            <div className="role-price">${h.price}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContinuityTab({ d }) {
  const c = d.continuity || {};
  const vc = v => v === "strong" ? "strong" : v === "critical" ? "critical" : "needs-attention";
  const vi = v => v === "strong" ? "✓" : v === "critical" ? "✗" : "⚠";
  return (
    <div>
      <div className="eyebrow">Emotional Continuity Audit</div>
      <div className="score-strip">
        <div className="score-card"><div className="score-val big">{c.overallScore}</div><div className="score-lbl-sm">Overall Score</div></div>
        {(c.threads || []).map((t, i) => (
          <div key={i} className="score-card">
            <div className="score-val" style={{ color: t.verdict === "strong" ? "#B08D45" : t.verdict === "critical" ? "#943030" : "#8A6A10" }}>{vi(t.verdict)}</div>
            <div className="score-lbl-sm">{t.name}</div>
          </div>
        ))}
      </div>
      {c.scoreRationale && <div className="note">{c.scoreRationale}</div>}
      {(c.threads || []).map((t, i) => (
        <div key={i} className="thread-card">
          <div className={`thread-verdict ${vc(t.verdict)}`}>{t.verdict}</div>
          <div className="thread-name">{t.name}</div>
          <div className="thread-body">{t.analysis}</div>
        </div>
      ))}
      <div className="hr" />
      <div className="sec-title">Quality Gate Checklist</div>
      <div className="chk-list">
        {(c.qualityGates || []).map((g, i) => (
          <div key={i} className="chk-row">
            <span className={`chk-icon ${g.pass ? "ok" : "fail"}`}>{g.pass ? "✓" : "✗"}</span>{g.label}
          </div>
        ))}
      </div>
    </div>
  );
}

function ReleaseTab({ d }) {
  return (
    <div>
      <div className="eyebrow">Phased Release Strategy</div>
      <div className="timeline">
        {(d.release || []).map((ph, i) => (
          <div key={i} className="phase-card">
            <div className="phase-num">{ph.phase}</div>
            <div className="phase-title">{ph.title}</div>
            <div className="phase-row"><b>Timing:</b> {ph.timing}</div>
            <div className="phase-row"><b>Products:</b> {ph.products}</div>
            <div className="phase-row"><b>Copy Hook:</b> {ph.copyHook}</div>
            <div className="phase-row"><b>Buyer Psychology:</b> {ph.buyerPsychology}</div>
            <div className="phase-row"><b>Emotional Arc:</b> {ph.emotionalArc}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CrossSellTab({ d }) {
  const cs = d.crossSell || {};
  return (
    <div>
      <div className="eyebrow">Cross-Sell Architecture</div>
      <div className="sec-title">Room Systems</div>
      {(cs.systems || []).map((s, i) => (
        <div key={i} className="system-card"><div className="system-name">{s.name}</div><div className="system-flow">{s.flow}</div></div>
      ))}
      <div className="hr" />
      <div className="sec-title">Bundle Opportunities</div>
      <div className="bundle-grid">
        {(cs.bundles || []).map((b, i) => (
          <div key={i} className="bundle-card">
            <div className="bundle-name">{b.name}</div>
            <div className="bundle-type">{b.type}</div>
            <div className="bundle-contents">{b.contents}</div>
            <div className="bundle-pr">
              {b.pct > 0 && <span className="bundle-was">${b.sum}</span>}
              <span className="bundle-now">${b.final}</span>
            </div>
            {b.pct > 0 ? <div className="bundle-save">Save ${(b.sum||0)-(b.final||0)} ({Math.round((b.pct||0)*100)}%)</div>
                        : <div className="bundle-save">Premium presentation — full price</div>}
          </div>
        ))}
      </div>
    </div>
  );
}

function MerchTab({ d }) {
  const m = d.merch || {};
  const blocks = [
    { t:"Collection hero shot",     b:m.heroShot },
    { t:"Product family groupings", b:m.familyGroupings },
    { t:"Individual product shots", b:m.individualShots },
    { t:"Detail shots",             b:m.detailShots },
  ];
  return (
    <div>
      <div className="eyebrow">Visual Merchandising Plan</div>
      {blocks.map((b, i) => b.b && <div key={i} className="merch-block"><div className="merch-title">{b.t}</div><div className="merch-body">{b.b}</div></div>)}
      <div className="hr" />
      <div className="eyebrow">Shop Front Flow</div>
      <ol className="flow-list">{(m.shopFrontFlow || []).map((s, i) => <li key={i}>{s}</li>)}</ol>
      <div className="eyebrow">Display Grouping Principles</div>
      <div className="note">{m.displayPrinciples}</div>
    </div>
  );
}

function RenderTab({ d }) {
  const [prompts, setPrompts] = useState({});
  const [generatingAll, setGeneratingAll] = useState(false);
  const [progress, setProgress] = useState({ n: 0, total: 0 });

  const products = d.hierarchy || [];

  async function handleGenerate(product) {
    setPrompts(prev => ({ ...prev, [product.name]: { status: "loading" } }));
    try {
      const result = await generateRenderPrompt(d, product);
      setPrompts(prev => ({ ...prev, [product.name]: { status: "done", ...result } }));
    } catch(e) {
      setPrompts(prev => ({ ...prev, [product.name]: { status: "error", error: e.message } }));
    }
  }

  async function handleGenerateAll() {
    setGeneratingAll(true);
    setProgress({ n: 0, total: products.length });
    for (let i = 0; i < products.length; i++) {
      setProgress({ n: i + 1, total: products.length });
      if (prompts[products[i].name]?.status === "done") continue;
      await handleGenerate(products[i]);
    }
    setGeneratingAll(false);
    setProgress({ n: 0, total: 0 });
  }

  return (
    <div>
      <div className="eyebrow">MJ V7 Render Packages — Full Collection</div>
      <div className="note">
        Each product gets a complete render package — WGS genome string, a full single-shot prompt (220+ words), and a three-phase stack for higher fidelity. Generated on demand using the full collection context. Prompts are ready to paste into Midjourney.
      </div>

      <div style={{ display:"flex", gap:12, alignItems:"center", marginBottom:28, flexWrap:"wrap" }}>
        <button
          className="intent-btn"
          style={{ alignSelf:"auto", padding:"11px 24px" }}
          onClick={handleGenerateAll}
          disabled={generatingAll}
        >
          {generatingAll ? `Generating ${progress.n} of ${progress.total}…` : "Generate All Prompts ✦"}
        </button>
        <div style={{ fontFamily:"'DM Mono',monospace", fontSize:"10px", color:"#C8B888", letterSpacing:".06em" }}>
          ~15 sec per product · {products.length} products
        </div>
      </div>

      {products.map((product, i) => {
        const state = prompts[product.name];
        const isDone  = state?.status === "done";
        const isLoad  = state?.status === "loading";
        const isError = state?.status === "error";

        return (
          <div key={i}>
            {/* Product header */}
            <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:12, marginBottom:14 }}>
              <div>
                <div className="render-hdr">{product.name}</div>
                <div className="render-sub">{product.role} · {product.form} · {product.formula} · <span style={{color:"#B08D45",fontFamily:"'DM Mono',monospace",fontSize:"10px",letterSpacing:".06em"}}>{detectFormType(product.form).replace(/_/g," ")}</span></div>
              </div>
              <div style={{ display:"flex", gap:8, flexShrink:0, marginTop:4 }}>
                {isDone && (
                  <button className="saved-del-btn" style={{ fontSize:"8.5px" }} onClick={() => handleGenerate(product)}>
                    Regenerate
                  </button>
                )}
                {!isDone && !isLoad && (
                  <button className="save-btn" onClick={() => handleGenerate(product)}>Generate ✦</button>
                )}
              </div>
            </div>

            {/* Botanical composition — always visible */}
            {(product.heroFloral || product.greeneryMix) && (
              <div style={{ background:"#FFFBF0", border:".5px solid #E8D49C", borderRadius:4, padding:"12px 15px", marginBottom:14, display:"grid", gridTemplateColumns:"1fr 1fr", gap:"6px 16px" }}>
                {[
                  { l:"Hero Floral",       v: product.heroFloral },
                  { l:"Secondary Floral",  v: product.secondaryFloral },
                  { l:"Accent Materials",  v: product.accentMaterials },
                  { l:"Greenery Mix",      v: product.greeneryMix },
                  { l:"Silence Arc",       v: product.silenceArc },
                ].filter(r => r.v).map((r, ri) => (
                  <div key={ri}>
                    <div style={{ fontFamily:"'DM Mono',monospace", fontSize:"8px", letterSpacing:".12em", textTransform:"uppercase", color:"#8A7142", marginBottom:2 }}>{r.l}</div>
                    <div style={{ fontSize:"11.5px", color:"#332B1A", lineHeight:1.55 }}>{r.v}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Loading */}
            {isLoad && (
              <div style={{ padding:"12px 0 18px", color:"#8A7142", fontFamily:"'DM Mono',monospace", fontSize:"10px", letterSpacing:".08em", display:"flex", gap:10, alignItems:"center" }}>
                <span style={{ animation:"breathe 1.8s ease-in-out infinite", display:"inline-block" }}>✦</span>
                Building render package…
              </div>
            )}

            {/* Error */}
            {isError && <div className="intent-err" style={{ marginBottom:16 }}><strong>Error:</strong> {state.error}</div>}

            {/* Done — full package */}
            {isDone && (
              <div>
                {/* Genome */}
                <div className="genome">
                  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
                    <div className="genome-lbl" style={{ marginBottom:0 }}>WGS Genome String</div>
                    <CopyBtn text={state.genome} />
                  </div>
                  <div className="genome-str">{state.genome}</div>
                </div>

                {/* Single-shot */}
                <div className="eyebrow" style={{ marginBottom:6 }}>Single-Shot Prompt — paste directly into MJ</div>
                <div className="prompt-block" style={{ marginBottom:18 }}>
                  <div className="prompt-hdr">
                    <span className="prompt-lbl">Full 9-step architecture · 220+ words</span>
                    <CopyBtn text={state.singleShot} />
                  </div>
                  <div className="prompt-txt">{state.singleShot}</div>
                </div>

                {/* Phase stack */}
                <div className="eyebrow" style={{ marginBottom:8 }}>Phase Stack — three generations, highest fidelity</div>
                {[
                  { label:"Phase 1 — Greenery base · generate first", key:"phase1" },
                  { label:"Phase 2 — Hero floral · --iw 1.8–2.2 from Phase 1", key:"phase2" },
                  { label:"Phase 3 — Structural accent · --iw 1.4–1.8 from Phase 2", key:"phase3" },
                ].map((ph, pi) => (
                  <div key={pi} className="prompt-block" style={{ marginBottom:6 }}>
                    <div className="prompt-hdr">
                      <span className="prompt-lbl">{ph.label}</span>
                      <CopyBtn text={state[ph.key] || ""} />
                    </div>
                    <div className="prompt-txt">{state[ph.key]}</div>
                  </div>
                ))}

                {/* --no block */}
                <div className="genome" style={{ marginTop:8 }}>
                  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:6 }}>
                    <div className="genome-lbl" style={{ marginBottom:0 }}>--no block · append to any phase</div>
                    <CopyBtn text={state.noBlock || ""} />
                  </div>
                  <div className="genome-str">{state.noBlock}</div>
                </div>
              </div>
            )}

            <div className="hr" />
          </div>
        );
      })}
    </div>
  );
}

/* ── GUIDE TAB ───────────────────────────────────── */
function GuideTab() {
  return (
    <div>
      <div className="eyebrow">MJ V7 Prompt Architecture · Master Reference</div>

      <div className="guide-thesis">
        <p>Tell MJ what it is made of, how it is photographed, where every element sits by clock position, and explicitly correct every default it would otherwise reach for. Then protect what you've built with --iw as you add each new layer.</p>
      </div>

      {/* MENTAL MODEL */}
      <div className="guide-section">
        <div className="guide-h2">The Mental Model</div>
        <div className="guide-p">You're not describing an image. You're writing a construction blueprint that also specifies how it gets photographed.</div>
        <div className="guide-p">MJ V7 has strong defaults trained into it from millions of images. Pine defaults to blue-gray Christmas color. Magnolia defaults to a giant open white flower. Ranunculus defaults to a fresh-cut florist bouquet. Velvet ribbon defaults to a symmetrical bow. Your entire job as a prompt writer is to correct those defaults explicitly and then describe what you actually want.</div>
        <div className="guide-p">Every prompt does two things simultaneously: fights MJ's defaults, and specifies your actual intent. If you forget either one, MJ fills the gap with its default. That's where blue pine, cotton bolls, and symmetrical ribbons come from.</div>
      </div>

      {/* ARCHITECTURE */}
      <div className="guide-section">
        <div className="guide-h2">The Architecture of Every Prompt</div>
        <div className="guide-p" style={{color:"#8A7142",fontSize:"11.5px"}}>Write in this exact order every time. Order matters — MJ front-weights. What comes first has the most influence.</div>

        {[
          { n:"1", t:"Material and product register", body:"Declare what the object IS and what it's MADE OF before anything else.", code:"Luxury handcrafted faux botanical wreath, premium artificial\nsilk and polyester florals, home decor product photography" },
          { n:"2", t:"Photography register", body:"Tell MJ what kind of image you want before you describe what's in it.", code:"photorealistic commercial product photography,\nreal photograph not illustrated not painted" },
          { n:"3", t:"Base structure", body:'Always build the physical object before you add anything to it. "Unbroken" matters — without it MJ sometimes renders a half-ring or open arc.', code:"complete circular grapevine ring base forming a full\nunbroken 24-inch loop" },
          { n:"4", t:"Greenery layer with distribution", body:"Describe WHERE the greenery goes using clock positions. Not 'mostly on the left side.' Specifically which hours it covers and which hours it doesn't.", code:"greenery concentrated from 8 through 12 to 4 o'clock,\nwarm grapevine exposed from 5 to 7 o'clock as\nintentional silence arc" },
          { n:"5", t:"Focal hierarchy — named in order of dominance", body:"Tell MJ explicitly which element is the boss. If you don't, it distributes visual weight evenly which flattens the composition.", code:"three large ivory wax-finish faux silk ranunculus blooms\n— ranunculus are the dominant commanding hero element\nof this composition —\nprimary fully open facing forward at 11 o'clock,\nsecondary mid-open at 9 o'clock angled slightly inward,\ntertiary bud stage at 1 o'clock" },
          { n:"6", t:"Each material's specific properties", body:"For every element: size in inches, finish description, position, and its relationship to other elements. Never rely on MJ knowing what something looks like.", code:"brass-dusted faux magnolia pods — elongated organic\npod form 2 to 3 inches long not spherical not round —\nsubordinate in scale to ranunculus but commanding\nin surface texture" },
          { n:"7", t:"Camera and lighting", body:"Specific lens. Specific angle. Specific light direction. Always.", code:"photographed flat against a pale gray painted wall\nfront-facing, soft studio daylight from upper left,\n85mm editorial e-commerce product photography" },
        ].map((s, i) => (
          <div key={i} style={{marginBottom:18}}>
            <div className="guide-label">{s.n} — {s.t}</div>
            <div className="guide-p">{s.body}</div>
            <div className="guide-code">{s.code}</div>
          </div>
        ))}

        <div style={{marginBottom:18}}>
          <div className="guide-label">8 — The --no block</div>
          <div className="guide-p">Not redundant with in-prompt negatives. In-prompt negatives ("not blue not gray") tell MJ what the positive thing IS. The --no block tells MJ what outputs to exclude entirely. They work at different levels.</div>
          <ul className="guide-ul">
            <li>Material exclusions: <code style={{fontFamily:"'DM Mono',monospace",fontSize:"10px"}}>fresh flowers, real plants, live botanicals, organic</code></li>
            <li>Camera exclusions: <code style={{fontFamily:"'DM Mono',monospace",fontSize:"10px"}}>flat lay, overhead shot, bird's eye view</code></li>
            <li>Style exclusions: <code style={{fontFamily:"'DM Mono',monospace",fontSize:"10px"}}>illustrated, painted, digital art</code></li>
            <li>Collection-specific: <code style={{fontFamily:"'DM Mono',monospace",fontSize:"10px"}}>blue pine, gray pine, symmetrical ribbon, cotton bolls</code></li>
          </ul>
        </div>

        <div style={{marginBottom:18}}>
          <div className="guide-label">9 — Technical parameters</div>
          <div className="params-grid">
            <span className="params-key">--style raw</span><span className="params-val">always — prevents artistic stylization</span>
            <span className="params-key">--s 50</span><span className="params-val">garlands — keeps it photographic</span>
            <span className="params-key">--s 100</span><span className="params-val">wreaths — slight stylize for material quality</span>
            <span className="params-key">--ar 1:1</span><span className="params-val">wreaths</span>
            <span className="params-key">--ar 16:9</span><span className="params-val">mantel garlands</span>
            <span className="params-key">--ar 4:5</span><span className="params-val">stair garlands</span>
            <span className="params-key">--v 7</span><span className="params-val">always explicit</span>
          </div>
        </div>
      </div>

      {/* CORE RULES */}
      <div className="guide-section">
        <div className="guide-h2">The Core Rules — Declarative Not Descriptive</div>
        <div className="guide-label" style={{marginBottom:6}}>Wrong</div>
        <div className="guide-wrong">"Beautiful ivory flowers catching the warm light, their petals unfurling softly..."</div>
        <div className="guide-label" style={{marginBottom:6}}>Right</div>
        <div className="guide-right">"three large ivory wax-finish faux silk ranunculus blooms each 4 to 5 inches across fully open at dinner-plate scale"</div>
        <div className="guide-p">Declarative prompts always specify:</div>
        <ul className="guide-ul">
          <li><strong>Count</strong> — three, not "several"</li>
          <li><strong>Size</strong> — 4 to 5 inches, not "large"</li>
          <li><strong>Finish</strong> — wax-finish, matte, brushed brass — not "beautiful"</li>
          <li><strong>Position</strong> — 11 o'clock, not "upper left area"</li>
          <li><strong>Relationship</strong> — "subordinate in scale to" / "dominant over"</li>
        </ul>
      </div>

      {/* PHASE LOGIC */}
      <div className="guide-section">
        <div className="guide-h2">The Phase Logic</div>
        <div className="guide-p">When ten competing elements exist in one prompt, MJ produces a consensus average — every element gets a version of itself that coexists with everything else, rather than a fully realized version of itself. That's what a flat, default-heavy render looks like. The phase stack eliminates competition. It's not about dividing a resource — it's about ensuring each layer has no rivals when it's being resolved.</div>
        <div className="params-grid" style={{marginBottom:20}}>
          <span className="params-key">Phase 1</span><span className="params-val">Generate greenery only. Lock the base. No florals, no accents.</span>
          <span className="params-key">Phase 2</span><span className="params-val">Bring Phase 1 as image reference at --iw 1.8–2.2. Describe only the hero floral. Greenery is locked; the full generation resolves the bloom.</span>
          <span className="params-key">Phase 3</span><span className="params-val">Bring Phase 2 as image reference at --iw 1.4–1.8. Describe only the structural accent. Both prior layers are locked.</span>
        </div>
        <div className="note"><strong>--iw calibration:</strong> If the new element isn't appearing strongly enough, lower --iw by 0.2. If the base layer is drifting or being replaced, raise it by 0.2. The sweet spot holds the previous layer without suppressing the incoming one.</div>
      </div>

      {/* OREF */}
      <div className="guide-section">
        <div className="guide-h2">The Oref Rule</div>
        <div className="guide-p"><strong>What oref is:</strong> Oref (Object Reference) is MJ V7's dedicated material reference input, separate from style references. You provide a photo of the specific stem, bloom, or material you want rendered, and MJ reads its form, texture, finish, and color directly from the image. It's how you show MJ an exact inventory item and say: this specific thing, in this composition.</div>
        <div className="params-grid">
          <span className="params-key">--ow 300–380</span><span className="params-val">Literal material copy — exact texture, color, finish. Use for a specific inventory stem that must be reproduced accurately.</span>
          <span className="params-key">--ow 180–220</span><span className="params-val">Atmospheric influence — palette and texture absorbed, form not copied. Use when referencing a bundle or cascade.</span>
        </div>
        <div className="guide-p">The fidelity ceiling of oref at --ow 380 is higher than any text description for botanical surface quality. Show don't tell.</div>
      </div>

      {/* DEFAULTS TABLE */}
      <div className="guide-section">
        <div className="guide-h2">Canonical Defaults to Fight — Wreath Specific</div>
        <div className="guide-p" style={{color:"#8A7142",fontSize:"11.5px"}}>These are the defaults MJ reaches for unless you explicitly correct them. Each one will ruin a premium faux botanical render.</div>
        <table className="ref-table">
          <thead>
            <tr><th>Element</th><th>MJ's default</th><th>How to fight it</th></tr>
          </thead>
          <tbody>
            {[
              ["Pine / fir", "Blue-gray, Christmas, uniform density", "Name the exact color: warm sage, olive, forest green. Add: not blue not gray not Christmas green"],
              ["Hellebores", "Drooping fresh cup, wide-open stamens, dewy", "wax-finish faux silk, cups semi-closed or three-quarter open, no visible stamens, not drooping, not dewy, not fresh-cut"],
              ["Anemones", "Fresh florist, drooping petals, dewy centre", "premium faux silk anemone, petals fully formed and dimensional, dark centre disc flat and defined, not drooping, not fresh"],
              ["Ranunculus", "Fresh-cut florist, open bowl, flat", "wax-finish, fully dimensional, not fresh-cut not florist"],
              ["Magnolia / pods", "Large open white flower", "elongated organic pod form 2 to 3 inches long, not flower, not bloom, not open petal"],
              ["Ribbon", "Symmetrical bow, stiff satin", "Specify texture and behavior: single draped velvet tail, asymmetrical, not tied, not bow"],
              ["Cotton bolls", "Appear uninvited in neutral palettes", "Always in --no: cotton bolls, cotton stems, cotton branches"],
              ["Fresh bough", "Appears when material register weakens", "Always in --no: fresh branch arrangement, fresh bough, spring branch, cherry blossom branch, botanical bough"],
              ["Composition", "Centered symmetrical blob", "Clock positions for every element, name silence arc, specify asymmetry direction"],
              ["LED lights", "Invisible or prominent Christmas string", "integrated warm white LED micro-strand lights threaded through interior construction, visible as soft warm glow points between foliage, not prominent string lights, not visible cord"],
              ["Grapevine base", "Hidden, replaced with foam ring", "warm exposed grapevine visible in silence arc from [X] to [Y] o'clock"],
              ["Depth", "Flat, two-dimensional", "three-dimensional with foreground mid-ground background material layering, stems emerging at varied depth planes"],
              ["Mantel color", "Sage, gray, or painted any color", "white painted wood mantel surround only — not gray, not sage, not mint, not cream"],
              ["Material overall", "Fresh flowers, florist aesthetic", "Declare register in line one: luxury handcrafted faux botanical, premium artificial silk and polyester florals"],
            ].map(([el, def, fix], i) => (
              <tr key={i}><td>{el}</td><td>{def}</td><td>{fix}</td></tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* LIFESTYLE */}
      <div className="guide-section">
        <div className="guide-h2">Lifestyle Architecture — Environmental Renders</div>
        <div className="guide-p">Product photography places the wreath against a neutral wall. Environmental renders place it in a space. The prompt architecture shifts in three ways.</div>

        <div className="guide-h3">The register line changes</div>
        <div className="guide-label" style={{marginBottom:4}}>Product</div>
        <div className="guide-code">{"home decor product photography, isolated subject,\npale gray studio wall, clean background"}</div>
        <div className="guide-label" style={{marginBottom:4}}>Environmental</div>
        <div className="guide-code">{"interior lifestyle photography, editorial home styling,\narchitectural context, real home environment"}</div>

        <div className="guide-h3">Spatial language shifts from self-referential to relational</div>
        <div className="guide-p">Instead of clock positions within the wreath, you're placing the wreath within the environment. Specify what surface it hangs on, what's immediately adjacent, and what's in the soft-focus background.</div>

        <div className="guide-h3">Camera instruction changes</div>
        <div className="guide-label" style={{marginBottom:4}}>Product</div>
        <div className="guide-code">{"front-facing flat against wall, 85mm, clean background"}</div>
        <div className="guide-label" style={{marginBottom:4}}>Environmental</div>
        <div className="guide-code">{"shot from slight 3/4 angle, 35–50mm, shallow depth of field,\nenvironment softly suggested in background, wreath in sharp focus"}</div>

        <div className="guide-h3">Canonical lifestyle contexts</div>
        <ul className="guide-ul">
          <li><strong>Exterior door</strong> — specify paint color, hardware finish, seasonal light quality: warm golden hour autumn, flat gray winter overcast, deep blue dusk</li>
          <li><strong>Interior entry</strong> — white or painted door, hardwood glimpse, natural ambient light from implied sidelight, no clutter</li>
          <li><strong>Mantel</strong> — marble or painted surround, candlesticks or vessels only, wreath centered and dominant</li>
          <li><strong>Console / table</strong> — runner context, overhead ambient light, 3/4 angle to show dimensional depth</li>
        </ul>

        <div className="guide-h3">--no additions for lifestyle</div>
        <div className="guide-code">{"cluttered background, visible furniture in sharp focus,\npeople, pets, florist shop, staging excess,\nstock photo aesthetic, real estate photography"}</div>
      </div>

    </div>
  );
}

/* ── SAVED SCREEN ────────────────────────────────── */
function SavedScreen({ onBack, onLoad }) {
  const [manifest, setManifest] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingId, setLoadingId] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => {
    getManifest().then(m => { setManifest(m); setLoading(false); });
  }, []);

  async function handleLoad(id) {
    setLoadingId(id);
    const data = await loadFromStorage(id);
    setLoadingId(null);
    if (data) onLoad(data);
  }

  async function handleDelete(id) {
    setDeletingId(id);
    await deleteFromStorage(id);
    setManifest(m => m.filter(e => e.id !== id));
    setDeletingId(null);
  }

  return (
    <div className="saved-screen">
      <div className="saved-hdr">
        <div>
          <div className="saved-hdr-eye">Evercrafted Studio · Collection Library</div>
          <div className="saved-hdr-title">Saved Collections</div>
        </div>
        <button className="reset-btn" onClick={onBack}>← Back</button>
      </div>
      <div className="saved-body">
        {loading ? (
          <div style={{ textAlign:"center", padding:"40px", color:"#8A7142", fontFamily:"'DM Mono',monospace", fontSize:"11px", letterSpacing:".1em" }}>Loading…</div>
        ) : manifest.length === 0 ? (
          <div className="saved-empty">
            <div className="saved-empty-g">○</div>
            <div className="saved-empty-t">No saved collections yet.<br />Generate one and hit Save ✦ to keep it here.</div>
          </div>
        ) : (
          <div className="saved-grid">
            {manifest.map(m => (
              <div key={m.id} className="saved-card">
                <div className="saved-card-name">{m.name}</div>
                <div className="saved-card-tag">{m.tagline}</div>
                {m.palette && m.palette.length > 0 && (
                  <div className="saved-card-dots">
                    {m.palette.map((hex, i) => <div key={i} className="saved-card-dot" style={{ background: hex }} />)}
                  </div>
                )}
                <div className="saved-card-meta">Saved {m.savedAt}</div>
                <div className="saved-card-actions">
                  <button className="saved-load-btn" onClick={() => handleLoad(m.id)} disabled={loadingId === m.id}>
                    {loadingId === m.id ? "Loading…" : "Load Collection"}
                  </button>
                  <button className="saved-del-btn" onClick={() => handleDelete(m.id)} disabled={deletingId === m.id}>
                    {deletingId === m.id ? "…" : "Delete"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── DASHBOARD ───────────────────────────────────── */
function Dashboard({ data, onReset, onSave }) {
  const [tab, setTab] = useState("foundation");
  const [saveStatus, setSaveStatus] = useState(null);

  async function handleSave() {
    setSaveStatus("saving");
    try {
      await onSave(data);
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus(null), 3000);
    } catch {
      setSaveStatus("error");
      setTimeout(() => setSaveStatus(null), 2000);
    }
  }

  const saveLabel = saveStatus === "saving" ? "Saving…" : saveStatus === "saved" ? "Saved ✓" : saveStatus === "error" ? "Error" : "Save ✦";

  return (
    <div className="dash">
      <div className="dash-hdr">
        <div className="dash-hdr-top">
          <div>
            <div className="dash-eye">Evercrafted · Full Collection Intelligence Package</div>
            <div className="dash-name">{data.meta?.name}</div>
            <div className="dash-sub">{data.meta?.tagline}</div>
          </div>
          <div className="dash-hdr-actions">
            <button className={`save-btn${saveStatus === "saved" ? " saved" : ""}`} onClick={handleSave} disabled={saveStatus === "saving"}>
              {saveLabel}
            </button>
            <button className="reset-btn" onClick={onReset}>← New Collection</button>
          </div>
        </div>
        <div className="tabs">
          {TABS.map(t => <button key={t.id} className={`tab-btn${tab===t.id?" active":""}`} onClick={() => setTab(t.id)}>{t.label}</button>)}
        </div>
      </div>
      <div className="dash-body">
        {tab==="foundation" && <FoundationTab d={data} />}
        {tab==="hierarchy"  && <HierarchyTab  d={data} />}
        {tab==="continuity" && <ContinuityTab d={data} />}
        {tab==="release"    && <ReleaseTab    d={data} />}
        {tab==="crosssell"  && <CrossSellTab  d={data} />}
        {tab==="merch"      && <MerchTab      d={data} />}
        {tab==="render"     && <RenderTab     d={data} />}
        {tab==="guide"      && <GuideTab />}
      </div>
    </div>
  );
}

/* ── LOADING ─────────────────────────────────────── */
function Loading({ intent }) {
  const [idx, setIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setIdx(i => (i+1) % MSGS.length), 3400);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="loading">
      <div className="loading-g">✦</div>
      <div className="loading-m">{MSGS[idx]}</div>
      {intent && <div className="loading-i">"{intent}"</div>}
    </div>
  );
}

/* ── INTENT SCREEN ───────────────────────────────── */
function IntentScreen({ onGenerate, onViewSaved, savedCount, error }) {
  const [intent, setIntent] = useState("");
  return (
    <div className="intent">
      <div className="intent-mark">Evercrafted Studio · Collection Intelligence Engine</div>
      <h1 className="intent-title">What collection are you building?</h1>
      <p className="intent-sub">
        Describe your intent in plain language. The system generates the complete collection — hierarchy, continuity, release strategy, cross-sell architecture, merchandising, and Midjourney render prompts.
      </p>
      <div className="intent-form">
        <textarea
          className="intent-ta" rows={4} value={intent}
          onChange={e => setIntent(e.target.value)}
          onKeyDown={e => { if (e.key==="Enter" && (e.metaKey||e.ctrlKey) && intent.trim()) onGenerate(intent.trim()); }}
          placeholder="e.g. moody autumn wreath collection, dried botanicals, rust dahlias and aged copper, warm earthy palette, 6 products for Etsy"
        />
        {error && <div className="intent-err"><strong>Error:</strong> {error}</div>}
        <button className="intent-btn" onClick={() => intent.trim() && onGenerate(intent.trim())} disabled={!intent.trim()}>
          Generate Collection ✦
        </button>
        {savedCount > 0 && (
          <button className="intent-saved-link" onClick={onViewSaved}>
            My Saved Collections ({savedCount})
          </button>
        )}
        <div className="intent-hint">Cmd+Enter to generate · ~25 seconds</div>
      </div>
    </div>
  );
}

/* ── APP ─────────────────────────────────────────── */
export default function App() {
  const [screen,  setScreen]  = useState("intent");
  const [data,    setData]    = useState(null);
  const [error,   setError]   = useState(null);
  const [intent,  setIntent]  = useState("");
  const [savedCount, setSavedCount] = useState(0);

  useEffect(() => {
    getManifest().then(m => setSavedCount(m.length)).catch(() => {});
  }, []);

  async function handleGenerate(intentStr) {
    setIntent(intentStr); setError(null); setScreen("loading");
    try { const result = await generate(intentStr); setData(result); setScreen("done"); }
    catch(e) { setError(e.message); setScreen("intent"); }
  }

  async function handleSave(collectionData) {
    await saveToStorage(collectionData);
    const m = await getManifest();
    setSavedCount(m.length);
  }

  function handleLoad(collectionData) {
    setData(collectionData);
    setScreen("done");
  }

  function handleReset() {
    setScreen("intent"); setData(null); setError(null);
  }

  return (
    <>
      <style>{CSS}</style>
      {screen==="intent"  && <IntentScreen onGenerate={handleGenerate} onViewSaved={() => setScreen("saved")} savedCount={savedCount} error={error} />}
      {screen==="loading" && <Loading intent={intent} />}
      {screen==="done"    && <Dashboard data={data} onReset={handleReset} onSave={handleSave} />}
      {screen==="saved"   && <SavedScreen onBack={() => setScreen("intent")} onLoad={handleLoad} />}
    </>
  );
}

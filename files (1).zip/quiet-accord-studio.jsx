import { useState, useCallback } from "react";

// ─────────────────────────────────────────────────────────
// ROLE STYLES
// ─────────────────────────────────────────────────────────
const R = {
  "Premium Anchor":    { badge: "#8B4A4A", border: "#3a2020", dim: "#5a3030" },
  "Hero":              { badge: "#4A7A5E", border: "#1e3328", dim: "#2d5040" },
  "Supporting":        { badge: "#4A5E8B", border: "#1e2840", dim: "#2d3d60" },
  "Atmospheric Filler":{ badge: "#7A7050", border: "#332e1e", dim: "#504828" },
  "Gateway":           { badge: "#6A4A8B", border: "#2a1e3a", dim: "#422d60" },
  "Accent":            { badge: "#4A8080", border: "#1e3333", dim: "#2d5050" },
};

// ─────────────────────────────────────────────────────────
// COLLECTION DATA
// ─────────────────────────────────────────────────────────
const PRODUCTS = [
  {
    id: "grande",
    name: "Quiet Accord Grande",
    role: "Premium Anchor",
    scale: '28"',
    formula: "Heavy Crescent Extended",
    price: "$295–$325",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of a handcrafted luxury faux botanical wreath, an extended asymmetric crescent of five open ivory silk peonies and three velvet magnolia buds sweeping from 6 to 12 o'clock, silvery sage dusty miller and silver-dollar eucalyptus wisping outward beyond the ring edge in trailing arcs, matte slate-blue viburnum berry clusters punctuating the arc at three irregular intervals, heaviest bloom density anchored from 7 to 10 o'clock, exposed grapevine base visible through deliberate negative space from 2 to 5 o'clock, structured silk petals with natural petal memory and wired stems holding organic directional curves, dimensional layering from foliage foundation to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a wood-toned ledge, 85mm medium format, shallow depth of field, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark`,
      "Variant A": `editorial product photograph of a large handcrafted luxury faux botanical wreath, asymmetric heavy crescent of five open ivory silk peonies and velvet magnolia buds weighted from 6 to 12 o'clock, dusty miller and silver-dollar eucalyptus trailing outward, matte slate-blue viburnum berries punctuating the arc at three points, exposed grapevine through the lower right arc, soft directional interior light, hung on a natural linen-white interior door in a calm neutral entryway, wide plank floors soft in the lower frame, 85mm medium format, shallow depth of field, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, cartoon, text, watermark`,
      "Detail Crop": `close-up editorial detail photograph of a luxury faux botanical wreath focal cluster, open ivory silk peony bloom at peak, layered petal structure with natural shadow depth between petals, silvery sage dusty miller velvet leaves fanning beneath, matte slate-blue viburnum berries at right edge, wired silk stems visible at cluster base, dimensional layering with visible material depth, soft side window light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark`,
    }
  },
  {
    id: "hero",
    name: "Quiet Accord",
    role: "Hero",
    scale: '24"',
    formula: "Heavy Crescent",
    price: "$195–$225",
    done: true,
    note: "Reference render complete — use this URL as your --oref source",
    prompts: {
      "Hero": `editorial product photograph of a handcrafted luxury faux botanical wreath, an asymmetric crescent of three open ivory silk peonies and two velvet magnolia buds sweeping from 7 to 12 o'clock, silvery sage dusty miller and matte olive-leaf foliage extending outward in directional trailing wisps, matte slate-blue viburnum berry clusters punctuating the upper arc, heaviest density anchored at 8 to 10 o'clock, exposed grapevine base deliberate and visible from 1 to 6 o'clock, structured silk petals with natural petal memory, wired stems holding organic curves, dimensional layering from foliage base to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a warm wood ledge, 85mm medium format, shallow depth of field, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark`,
      "Variant A": `editorial product photograph of a handcrafted luxury faux botanical wreath on a natural linen-white front door, asymmetric crescent of ivory silk peonies and magnolia buds weighted from 7 to 12 o'clock, dusty miller and olive-leaf foliage trailing outward, slate-blue viburnum berries at the crown, exposed grapevine in the lower arc, calm neutral exterior with warm stone steps below, soft overcast daylight, 85mm, shallow depth of field, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark`,
      "Detail Crop": `close-up editorial detail of a luxury faux botanical wreath, open ivory silk peony at peak bloom, layered petal structure with natural shadow between petals, silvery dusty miller velvet leaves beneath, matte slate berry cluster at right, wired stem bases visible, dimensional material depth, soft window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark`,
    }
  },
  {
    id: "pale_interior",
    name: "Pale Interior",
    role: "Supporting",
    scale: '20"',
    formula: "Side Sweep",
    price: "$155–$175",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of a handcrafted luxury faux botanical wreath, foliage-forward asymmetric side sweep composition, two open ivory silk peonies anchoring an extended sweep of silvery sage dusty miller from 8 to 12 o'clock, matte olive-leaf foliage fanning outward along the sweep, heavier matte slate-blue viburnum berry clusters massed at 9 to 11 o'clock, no blooms in the lower arc, exposed grapevine base readable throughout the lower half and right quadrant, velvet foliage with organic directional lean along the ring edge, wired stems holding natural curves, dimensional midground depth, soft north-facing window light, hung on a warm grey limewash plaster wall, 85mm medium format, shallow depth of field, premium home decor editorial aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark`,
      "Variant A": `editorial product photograph of a small handcrafted luxury faux botanical wreath on an interior hallway door, foliage-forward asymmetric side sweep with two ivory silk peonies at the upper arc, dusty miller and olive-leaf foliage sweeping from 8 to 12 o'clock, slate-blue viburnum berries clustered at 10 o'clock, bare grapevine throughout the lower arc, calm neutral hallway with plaster walls, soft window light from the left, 85mm, shallow depth of field, premium interiors editorial --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark`,
    }
  },
  {
    id: "ledge",
    name: "The Ledge",
    role: "Supporting",
    scale: '48" Garland',
    formula: "Linear Directional",
    price: "$165–$185",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of a handcrafted luxury faux botanical garland draped naturally across a painted wood mantel shelf, linear directional arrangement densest at center with three velvet magnolia buds and a layered cluster of silvery sage dusty miller and matte olive-leaf foliage, matte slate-blue viburnum berry sprigs tucked throughout at irregular intervals, garland tapering to loose dusty miller wisps and bare stems at both ends, left end slightly denser than right with a directional left lean, natural bow at center from its own weight, organic side cascades over the mantel edge, dimensional layering from foliage base to bud surface, soft north-facing window light, matte surfaces throughout, no full peonies, grey plaster wall in background, 85mm medium format, shallow focus at center cluster, premium home decor editorial catalog --ar 3:2 --v 7 --style raw --s 150 --no symmetry, centered mass, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, stiff placement, cartoon, text, watermark`,
      "Variant A": `editorial product photograph of a luxury faux botanical garland draped over a narrow oak console table, asymmetric directional composition densest at center left, silvery sage dusty miller and magnolia buds clustered at the drape peak, slate-blue viburnum sprigs graduating outward, both ends trailing naturally toward the floor with organic looseness, ceramic vessel and folded linen in the soft background, warm grey plaster wall, north window light, 85mm, shallow depth, premium interiors editorial --ar 3:2 --v 7 --style raw --s 150 --no symmetry, fresh flowers, stiff arrangement, plastic shine, craft store, cartoon, text, watermark`,
    }
  },
  {
    id: "rings",
    name: "Still Rings",
    role: "Atmospheric Filler",
    scale: '8" × 2',
    formula: "Asymmetric Cluster",
    price: "$55–$65 / set",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of two small handcrafted luxury faux botanical candle rings on a warm-toned wood console surface, each ring a grapevine base with an asymmetric cluster of one small ivory silk peony bud at 8 o'clock, three silvery sage dusty miller leaves fanning from 6 to 11 o'clock, two matte slate-blue viburnum berry stems graduating outward, exposed grapevine visible through the lower half of each ring, two rings positioned at slightly different angles with one overlapping the other for editorial depth, no candles in frame, soft north-facing window light, warm grey plaster wall behind, 85mm medium format, shallow depth of field, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, centered cluster, matching identical pair, fresh flowers, wilting, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark`,
      "Variant A": `editorial lifestyle photograph of two small luxury faux botanical candle rings encircling natural pillar candles on a wood console surface, asymmetric ivory bud and dusty miller clusters at 8 o'clock per ring, matte slate-blue berry sprigs at the crown, exposed grapevine in the lower arcs, candles unlit, warm grey plaster wall, north window light, soft editorial composition, premium home decor styling --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, glitter, cartoon, text, watermark`,
    }
  },
  {
    id: "gateway",
    name: "First Light",
    role: "Gateway",
    scale: '14"',
    formula: "Classic Asymmetric",
    price: "$95–$115",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of a small handcrafted luxury faux botanical wreath, a single open ivory silk peony anchoring the composition at 9 o'clock, silvery sage dusty miller curving from 7 to 12 o'clock in a quiet asymmetric crescent, four matte slate-blue viburnum berry sprigs graduating in size toward the crown, no florals in the lower arc, exposed grapevine base visible and deliberate from 1 to 6 o'clock, structured silk petal with natural fold memory and velvet foliage with organic directional lean, compact and restrained, soft north-facing window light, hung on a warm grey limewash plaster wall with warm wood ledge below, 85mm medium format, shallow depth of field, premium home decor editorial catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark`,
      "Variant A": `editorial product photograph of a small luxury faux botanical wreath resting against a wrapped gift box on a warm wood surface, single ivory silk peony at 9 o'clock, quiet dusty miller crescent sweeping the upper arc, slate-blue berry sprigs at the crown, exposed grapevine in the lower half, kraft paper wrapping soft in the background, north window light, warm grey plaster wall, minimal props, premium home decor gifting aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, busy background, cartoon, text, watermark`,
    }
  },
  {
    id: "accent",
    name: "Sage + Berry Picks",
    role: "Accent",
    scale: "6-stem bundle",
    formula: "Loose bundle",
    price: "$22–$32",
    done: false,
    prompts: {
      "Hero": `editorial product photograph of a small handcrafted luxury faux botanical stem bundle, three silvery sage dusty miller stems and two matte slate-blue viburnum berry stems and one matte olive-leaf branch loosely wrapped in natural kraft paper twine, arranged with organic looseness and directional lean, stems at slightly varying heights, resting against a warm grey plaster wall on a warm wood surface, north window light, matte surfaces throughout, 85mm medium format, shallow depth of field, minimal editorial product styling, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, arranged bouquet, fresh flowers, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark`,
      "Variant A": `editorial lifestyle photograph of a loose luxury faux botanical stem bundle styled in a narrow ceramic vase on a wood console, sage dusty miller and slate-blue viburnum berries and olive leaf branch in natural organic arrangement, no full blooms, warm grey plaster wall, north window light, single white ceramic vessel, minimal styling, premium interiors catalog --ar 5:4 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, symmetry, craft store, cartoon, text, watermark`,
    }
  },
];

// ─────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────
function injectORef(prompt, url) {
  if (!url.trim()) return prompt;
  return prompt.replace("--ar", `--oref ${url.trim()} --ow 75 --ar`);
}

// ─────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────
export default function App() {
  const [orefUrl, setOrefUrl]     = useState("");
  const [orefOn, setOrefOn]       = useState(false);
  const [doneSet, setDoneSet]     = useState(() => new Set(["hero"]));
  const [tabs, setTabs]           = useState({});
  const [copied, setCopied]       = useState({});
  const [custom, setCustom]       = useState({}); // { [id]: { open, input, loading, result } }

  const finalPrompt = useCallback((base) =>
    orefOn ? injectORef(base, orefUrl) : base,
  [orefOn, orefUrl]);

  const handleCopy = useCallback(async (text, key) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(p => ({ ...p, [key]: true }));
      setTimeout(() => setCopied(p => ({ ...p, [key]: false })), 2000);
    } catch {}
  }, []);

  const toggleDone = useCallback((id) =>
    setDoneSet(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n; }),
  []);

  const activeTab = (product) =>
    tabs[product.id] || Object.keys(product.prompts)[0];

  const setTab = (id, tab) => setTabs(p => ({ ...p, [id]: tab }));

  const updateCustom = (id, patch) =>
    setCustom(p => ({ ...p, [id]: { ...(p[id] || {}), ...patch } }));

  const handleGenerate = useCallback(async (product, base) => {
    const state = custom[product.id] || {};
    if (!state.input?.trim() || state.loading) return;

    updateCustom(product.id, { loading: true, result: null });

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: `You are a luxury faux botanical render prompt specialist for the Evercrafted Quiet Accord collection. Modify Midjourney render prompts based on user instructions. Preserve Style DNA: asymmetric clock-position composition, matte silk/velvet faux materials only, editorial luxury product photography (85mm shallow DOF north window light grey plaster wall), exposed grapevine negative space. Return ONLY the modified prompt — no preamble, no explanation, no markdown, no code blocks. All --parameters must be preserved unless the modification requires changing them.`,
          messages: [{ role: "user", content: `Base prompt:\n${base}\n\nModification: ${state.input.trim()}` }]
        })
      });
      const data = await res.json();
      const result = data.content?.[0]?.text?.trim() || "No result. Try again.";
      updateCustom(product.id, { loading: false, result });
    } catch {
      updateCustom(product.id, { loading: false, result: "Network error. Please try again." });
    }
  }, [custom]);

  const handleDownload = useCallback(() => {
    const lines = PRODUCTS.map(p => {
      const header = `${"═".repeat(64)}\n${p.name.toUpperCase()} · ${p.role}\n${p.scale} · ${p.formula} · ${p.price}\n${"═".repeat(64)}`;
      const prompts = Object.entries(p.prompts)
        .map(([label, prompt]) => `── ${label} ──\n${finalPrompt(prompt)}`)
        .join("\n\n");
      return `${header}\n\n${prompts}`;
    }).join("\n\n\n");

    const blob = new Blob(
      [`QUIET ACCORD — RENDER PROMPTS\nEvercrafted Studio\n\n${lines}`],
      { type: "text/plain" }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "quiet-accord-prompts.txt";
    a.click();
    URL.revokeObjectURL(url);
  }, [finalPrompt]);

  const doneCount = doneSet.size;

  return (
    <div style={{ background: "#141416", minHeight: "100vh", fontFamily: "'Segoe UI', system-ui, sans-serif", color: "#e2ddd6" }}>

      {/* ── HEADER ── */}
      <div style={{ padding: "28px 24px 0", borderBottom: "1px solid #2a2a2e" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: "11px", letterSpacing: "0.18em", color: "#7a7670", textTransform: "uppercase", marginBottom: "6px" }}>
              Evercrafted · Collection Studio
            </div>
            <h1 style={{ fontSize: "26px", fontWeight: "400", letterSpacing: "0.12em", margin: "0 0 4px", color: "#e8e2d8" }}>
              QUIET ACCORD
            </h1>
            <div style={{ fontSize: "12px", color: "#7a7670" }}>Late Autumn → Deep Winter · Nordic Calm</div>
          </div>
          <button
            onClick={handleDownload}
            style={{ background: "#2a2a2e", border: "1px solid #3a3a3e", borderRadius: "8px", color: "#c8c2b8", fontSize: "12px", padding: "8px 16px", cursor: "pointer", fontWeight: "500", marginTop: "4px" }}
          >
            ↓ Download All
          </button>
        </div>

        {/* Progress row */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "16px 0 14px" }}>
          <div style={{ fontSize: "11px", color: "#7a7670", whiteSpace: "nowrap" }}>
            {doneCount} / {PRODUCTS.length} rendered
          </div>
          <div style={{ display: "flex", gap: "4px", flex: 1 }}>
            {PRODUCTS.map(p => (
              <div
                key={p.id}
                title={p.name}
                style={{
                  flex: 1, height: "4px", borderRadius: "2px",
                  background: doneSet.has(p.id)
                    ? R[p.role]?.badge || "#5a8a5a"
                    : "#2a2a2e",
                  transition: "background 0.3s"
                }}
              />
            ))}
          </div>
          <div style={{ fontSize: "11px", color: "#7a7670", whiteSpace: "nowrap" }}>$22–$325</div>
        </div>
      </div>

      {/* ── OREF PANEL ── */}
      <div style={{ padding: "14px 24px", background: "#1a1a1e", borderBottom: "1px solid #2a2a2e", display: "flex", alignItems: "center", gap: "12px" }}>
        <button
          onClick={() => setOrefOn(o => !o)}
          style={{
            background: orefOn ? "#2d4a35" : "#222226",
            border: `1px solid ${orefOn ? "#4a7a55" : "#3a3a3e"}`,
            borderRadius: "6px",
            color: orefOn ? "#7abf8a" : "#7a7670",
            fontSize: "11px",
            padding: "5px 12px",
            cursor: "pointer",
            fontWeight: "500",
            whiteSpace: "nowrap",
            transition: "all 0.2s"
          }}
        >
          {orefOn ? "● --oref ON" : "○ --oref OFF"}
        </button>
        <input
          value={orefUrl}
          onChange={e => setOrefUrl(e.target.value)}
          placeholder="Paste your hero render URL from Midjourney..."
          style={{
            flex: 1,
            background: "#222226",
            border: `1px solid ${orefUrl && orefOn ? "#4a7a55" : "#3a3a3e"}`,
            borderRadius: "6px",
            color: "#c8c2b8",
            fontSize: "12px",
            padding: "6px 12px",
            outline: "none",
            fontFamily: "monospace"
          }}
        />
        <div style={{ fontSize: "10px", color: "#5a5a5e", whiteSpace: "nowrap" }}>
          {orefOn && orefUrl ? "--ow 75 appended" : "adds style lock"}
        </div>
      </div>

      {/* ── PRODUCT LIST ── */}
      <div style={{ padding: "16px 24px 40px", display: "flex", flexDirection: "column", gap: "12px" }}>
        {PRODUCTS.map(product => {
          const rs = R[product.role] || R["Accent"];
          const isDone = doneSet.has(product.id);
          const tab = activeTab(product);
          const basePrompt = product.prompts[tab];
          const displayPrompt = finalPrompt(basePrompt);
          const copyKey = `${product.id}-${tab}`;
          const cState = custom[product.id] || {};

          return (
            <div
              key={product.id}
              style={{
                background: "#1c1c20",
                border: `1px solid ${isDone ? rs.dim : "#2a2a2e"}`,
                borderRadius: "12px",
                overflow: "hidden",
                transition: "border-color 0.3s"
              }}
            >
              {/* Card header */}
              <div style={{ padding: "14px 18px 12px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap", marginBottom: "5px" }}>
                    <span style={{
                      background: rs.badge,
                      color: "#fff",
                      fontSize: "9px",
                      fontWeight: "600",
                      padding: "2px 8px",
                      borderRadius: "3px",
                      letterSpacing: "0.08em",
                      textTransform: "uppercase"
                    }}>
                      {product.role}
                    </span>
                    {isDone && (
                      <span style={{ fontSize: "10px", color: "#7abf8a", fontWeight: "500" }}>✓ Rendered</span>
                    )}
                    {product.note && (
                      <span style={{ fontSize: "10px", color: "#6a9e7a" }}>{product.note}</span>
                    )}
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: "500", color: "#e8e2d8", marginBottom: "2px" }}>{product.name}</div>
                  <div style={{ fontSize: "11px", color: "#6a6a6e" }}>{product.scale} · {product.formula} · {product.price}</div>
                </div>
                <button
                  onClick={() => toggleDone(product.id)}
                  style={{
                    background: isDone ? "#1e3028" : "transparent",
                    border: `1px solid ${isDone ? rs.dim : "#3a3a3e"}`,
                    borderRadius: "6px",
                    color: isDone ? "#7abf8a" : "#5a5a5e",
                    fontSize: "11px",
                    padding: "4px 12px",
                    cursor: "pointer",
                    flexShrink: 0,
                    marginLeft: "12px",
                    fontWeight: "500",
                    transition: "all 0.2s"
                  }}
                >
                  {isDone ? "✓ Done" : "Mark Done"}
                </button>
              </div>

              {/* Tabs */}
              <div style={{ display: "flex", borderTop: "1px solid #242428", borderBottom: "1px solid #242428" }}>
                {Object.keys(product.prompts).map(t => (
                  <button
                    key={t}
                    onClick={() => setTab(product.id, t)}
                    style={{
                      flex: 1,
                      padding: "7px 4px",
                      background: "transparent",
                      border: "none",
                      borderBottom: t === tab ? `2px solid ${rs.badge}` : "2px solid transparent",
                      color: t === tab ? "#e2ddd6" : "#6a6a6e",
                      fontSize: "11px",
                      cursor: "pointer",
                      fontWeight: t === tab ? "500" : "400",
                      transition: "color 0.15s",
                    }}
                  >
                    {t}
                  </button>
                ))}
              </div>

              {/* Prompt area */}
              <div style={{ padding: "12px 18px 0" }}>
                <textarea
                  readOnly
                  value={displayPrompt}
                  onClick={e => e.target.select()}
                  style={{
                    width: "100%",
                    height: "108px",
                    background: "#111114",
                    border: "1px solid #2a2a2e",
                    borderRadius: "6px",
                    color: "#b8b2a8",
                    fontSize: "11px",
                    lineHeight: "1.65",
                    padding: "10px 12px",
                    resize: "none",
                    fontFamily: "monospace",
                    boxSizing: "border-box",
                    cursor: "text"
                  }}
                />
                <button
                  onClick={() => handleCopy(displayPrompt, copyKey)}
                  style={{
                    marginTop: "6px",
                    width: "100%",
                    background: copied[copyKey] ? "#1e3028" : "#222226",
                    border: `1px solid ${copied[copyKey] ? rs.dim : "#3a3a3e"}`,
                    borderRadius: "6px",
                    color: copied[copyKey] ? "#7abf8a" : "#c8c2b8",
                    fontSize: "12px",
                    padding: "8px",
                    cursor: "pointer",
                    fontWeight: "500",
                    transition: "all 0.2s"
                  }}
                >
                  {copied[copyKey] ? "✓ Copied to clipboard" : "Copy Prompt"}
                </button>
              </div>

              {/* Customize / Generate Variant */}
              <div style={{ padding: "10px 18px 16px" }}>
                <button
                  onClick={() => updateCustom(product.id, { open: !cState.open })}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "#5a5a62",
                    fontSize: "11px",
                    cursor: "pointer",
                    padding: "0",
                    display: "flex",
                    alignItems: "center",
                    gap: "6px",
                    letterSpacing: "0.04em"
                  }}
                >
                  <span style={{ transition: "transform 0.2s", display: "inline-block", transform: cState.open ? "rotate(90deg)" : "rotate(0deg)" }}>›</span>
                  Generate Custom Variant
                </button>

                {cState.open && (
                  <div style={{ marginTop: "10px" }}>
                    <textarea
                      value={cState.input || ""}
                      onChange={e => updateCustom(product.id, { input: e.target.value })}
                      placeholder={`Describe changes... e.g. "adapt for spring with blush ranunculus" or "door context, evening light"`}
                      style={{
                        width: "100%",
                        height: "56px",
                        background: "#111114",
                        border: "1px solid #2a2a2e",
                        borderRadius: "6px",
                        color: "#c8c2b8",
                        fontSize: "11px",
                        lineHeight: "1.5",
                        padding: "9px 12px",
                        resize: "none",
                        fontFamily: "system-ui, sans-serif",
                        boxSizing: "border-box",
                        outline: "none"
                      }}
                    />
                    <button
                      onClick={() => handleGenerate(product, basePrompt)}
                      disabled={cState.loading || !cState.input?.trim()}
                      style={{
                        marginTop: "6px",
                        width: "100%",
                        background: cState.loading ? "#111114" : "#1e2830",
                        border: `1px solid ${cState.loading ? "#2a2a2e" : "#2a4050"}`,
                        borderRadius: "6px",
                        color: cState.loading ? "#5a5a5e" : "#8ab8d8",
                        fontSize: "11px",
                        padding: "8px",
                        cursor: cState.loading ? "wait" : "pointer",
                        fontWeight: "500",
                        transition: "all 0.2s"
                      }}
                    >
                      {cState.loading ? "Generating variant..." : "Generate with Claude →"}
                    </button>

                    {cState.result && (
                      <div style={{ marginTop: "8px" }}>
                        <textarea
                          readOnly
                          value={cState.result}
                          onClick={e => e.target.select()}
                          style={{
                            width: "100%",
                            height: "108px",
                            background: "#0e1a14",
                            border: "1px solid #2a4038",
                            borderRadius: "6px",
                            color: "#98c8a8",
                            fontSize: "11px",
                            lineHeight: "1.65",
                            padding: "10px 12px",
                            resize: "none",
                            fontFamily: "monospace",
                            boxSizing: "border-box"
                          }}
                        />
                        <button
                          onClick={() => handleCopy(cState.result, `${product.id}-custom`)}
                          style={{
                            marginTop: "4px",
                            width: "100%",
                            background: copied[`${product.id}-custom`] ? "#1a3028" : "#0e1a14",
                            border: "1px solid #2a4038",
                            borderRadius: "6px",
                            color: "#7abf8a",
                            fontSize: "11px",
                            padding: "7px",
                            cursor: "pointer",
                            fontWeight: "500"
                          }}
                        >
                          {copied[`${product.id}-custom`] ? "✓ Copied" : "Copy Custom Variant"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid #1e1e22", padding: "16px 24px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontSize: "10px", color: "#4a4a4e", letterSpacing: "0.06em" }}>
          EVERCRAFTED · QUIET ACCORD COLLECTION · LATE AUTUMN → DEEP WINTER
        </div>
        <div style={{ fontSize: "10px", color: "#4a4a4e" }}>
          {doneCount} of {PRODUCTS.length} renders complete
        </div>
      </div>
    </div>
  );
}

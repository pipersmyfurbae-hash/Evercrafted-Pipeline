import { useState, useEffect, useCallback } from "react";

// ══════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════

const RS = {
  "Premium Anchor":     { badge: "#8B4A4A", border: "#3a1e1e", dim: "#5a2a2a" },
  "Hero":               { badge: "#4A7A5E", border: "#1e3328", dim: "#2d5040" },
  "Supporting":         { badge: "#4A5E8B", border: "#1e2840", dim: "#2d3d60" },
  "Atmospheric Filler": { badge: "#7A7050", border: "#32301a", dim: "#504828" },
  "Gateway":            { badge: "#6A4A8B", border: "#2a1e3a", dim: "#422d60" },
  "Accent":             { badge: "#4A8080", border: "#1e3333", dim: "#2d5050" },
};

const GEN_STEPS = [
  "Reading your collection intent...",
  "Mapping emotional palette and atmosphere...",
  "Building product hierarchy...",
  "Writing Hero render prompts...",
  "Writing Supporting and Variant prompts...",
  "Finalizing collection architecture...",
];

const SYSTEM_PROMPT = `You are the Evercrafted Collection Intelligence Engine and Wreath Prompt Studio. Generate a complete 7-product luxury faux botanical collection with Midjourney render prompts from a user's collection intent brief.

COLLECTION HIERARCHY — generate exactly 7 products in this order:
1. Premium Anchor: largest (26-30in), most complex, highest price, sets value ceiling
2. Hero: emotional centerpiece, signature formula, 22-26in wreath
3. Supporting A: different formula, same atmosphere, 18-22in wreath
4. Supporting B: garland, linear form, 36-60in
5. Atmospheric Filler: two 8in candle rings
6. Gateway: entry-level wreath, 12-16in, compressed atmosphere
7. Accent: small stem bundle or botanical pick set

RENDER PROMPT GRAMMAR — every wreath prompt must follow this structure:
- Open: "editorial product photograph of a handcrafted luxury faux botanical wreath"
- Hero species + material (silk/velvet/parchment) + clock-position cluster e.g. "sweeping from 7 to 10 o'clock"
- Supporting foliage with directional language
- "exposed grapevine base visible through deliberate negative space from [X] to [X] o'clock"
- "structured silk petals with natural petal memory and wired stems holding organic curves, dimensional layering from foliage foundation to focal bloom surface"
- "soft north-facing window light with directional shadow falloff"
- Believable surface context: grey limewash plaster wall, wood ledge, front door, interior door, console table
- "85mm medium format, shallow depth of field, premium home decor editorial catalog aesthetic"
- End: "--ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark"

ADJUSTMENTS BY FORM:
Garland (Supporting B): change "wreath" to "garland", use linear directional language instead of clock positions, "draped naturally across [mantel/console/ledge]", use --ar 3:2
Candle rings (Atmospheric Filler): "two small handcrafted luxury faux botanical candle rings on [surface]", 1 small bud + 3 foliage leaves + 2 berry stems per ring, "two rings positioned at slightly different angles with one overlapping the other for editorial depth", use --ar 5:4
Detail Crop: "close-up editorial detail photograph of a luxury faux botanical wreath focal cluster", lead with texture of hero species, --ar 4:5
Accent (bundle): "editorial product photograph of a luxury faux botanical stem bundle", "loosely wrapped in natural kraft paper twine", --ar 5:4

STYLE DNA — non-negotiable in every prompt:
- Asymmetric clock-position compositions (never symmetrical, never centered, never radial)
- Faux materials only (silk, velvet, parchment — no fresh flower language)
- Exposed grapevine negative space always explicitly named
- Stems radiate along ring, never converge to center
- Luxury editorial level: Anthropologie campaign, premium home decor catalog
- No cherry blossom, no pussy willow, no twig-blossom species ever

Each product needs exactly 3 prompts:
- "Hero": primary product shot on grey wall with wood ledge
- "Variant A": same product in a different believable context (different surface, different room)
- "Detail Crop": macro of the focal cluster, --ar 4:5

PRICING: Accent $18-$38 | Gateway $85-$125 | Atmospheric Filler $45-$75 | Supporting $145-$195 | Hero $175-$235 | Premium Anchor $265-$345

Return ONLY a valid JSON object with this structure. No markdown, no explanation, no text before or after the JSON:

{"id":"snake_case_id","collectionName":"Name","season":"Season timing","atmosphere":"Archetype","priceRange":"$X - $Y","palette":["Color1","Color2","Color3","Color4"],"products":[{"id":"prod_id","name":"Name","role":"Premium Anchor","scale":"28in","formula":"Formula","price":"$265-$345","done":false,"prompts":{"Hero":"full prompt...--ar 5:4 --v 7 --style raw --s 150 --no ...","Variant A":"full prompt...--ar 5:4 --v 7 --style raw --s 150 --no ...","Detail Crop":"close-up prompt...--ar 4:5 --v 7 --style raw --s 150 --no ..."}}]}`;

// ══════════════════════════════════════════════════════════
// INITIAL COLLECTION — QUIET ACCORD
// ══════════════════════════════════════════════════════════

const QUIET_ACCORD = {
  id: "quiet_accord",
  collectionName: "Quiet Accord",
  season: "Late Autumn → Deep Winter",
  atmosphere: "Nordic Calm",
  priceRange: "$22 — $325",
  palette: ["Ivory Mist", "Sage Smoke", "Slate Berry", "Warm Bark"],
  products: [
    {
      id: "grande", name: "Quiet Accord Grande", role: "Premium Anchor",
      scale: "28in", formula: "Heavy Crescent Extended", price: "$295–$325", done: false,
      prompts: {
        "Hero": "editorial product photograph of a handcrafted luxury faux botanical wreath, an extended asymmetric crescent of five open ivory silk peonies and three velvet magnolia buds sweeping from 6 to 12 o'clock, silvery sage dusty miller and silver-dollar eucalyptus wisping outward beyond the ring edge in trailing arcs, matte slate-blue viburnum berry clusters punctuating the arc at three irregular intervals, heaviest bloom density anchored from 7 to 10 o'clock, exposed grapevine base visible through deliberate negative space from 2 to 5 o'clock, structured silk petals with natural petal memory and wired stems holding organic curves, dimensional layering from foliage foundation to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a wood-toned ledge, 85mm medium format, shallow depth of field, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark",
        "Variant A": "editorial product photograph of a large handcrafted luxury faux botanical wreath, asymmetric heavy crescent of five open ivory silk peonies and velvet magnolia buds weighted from 6 to 12 o'clock, dusty miller and silver-dollar eucalyptus trailing outward, matte slate-blue viburnum berries punctuating the arc at three points, exposed grapevine through the lower right arc, soft directional interior light, hung on a natural linen-white interior door in a calm neutral entryway, wide plank floors soft in the lower frame, 85mm medium format, shallow depth of field, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail photograph of a luxury faux botanical wreath focal cluster, open ivory silk peony bloom at peak, layered petal structure with natural shadow depth between petals, silvery sage dusty miller velvet leaves fanning beneath, matte slate-blue viburnum berries at right edge, wired silk stems visible at cluster base, dimensional layering, soft side window light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "hero", name: "Quiet Accord", role: "Hero",
      scale: "24in", formula: "Heavy Crescent", price: "$195–$225", done: true,
      note: "Reference render complete — use this URL as your --oref source",
      prompts: {
        "Hero": "editorial product photograph of a handcrafted luxury faux botanical wreath, an asymmetric crescent of three open ivory silk peonies and two velvet magnolia buds sweeping from 7 to 12 o'clock, silvery sage dusty miller and matte olive-leaf foliage extending outward in directional trailing wisps, matte slate-blue viburnum berry clusters punctuating the upper arc, heaviest density anchored at 8 to 10 o'clock, exposed grapevine base deliberate and visible from 1 to 6 o'clock, structured silk petals with natural petal memory, wired stems holding organic curves, dimensional layering from foliage base to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a warm wood ledge, 85mm medium format, shallow depth of field, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark",
        "Variant A": "editorial product photograph of a handcrafted luxury faux botanical wreath on a natural linen-white front door, asymmetric crescent of ivory silk peonies and magnolia buds weighted from 7 to 12 o'clock, dusty miller and olive-leaf foliage trailing outward, slate-blue viburnum berries at the crown, exposed grapevine in the lower arc, calm neutral exterior with warm stone steps below, soft overcast daylight, 85mm, shallow depth of field, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical wreath, open ivory silk peony at peak bloom, layered petal structure with natural shadow between petals, silvery dusty miller velvet leaves beneath, matte slate berry cluster at right, dimensional material depth, soft window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "pale_interior", name: "Pale Interior", role: "Supporting",
      scale: "20in", formula: "Side Sweep", price: "$155–$175", done: false,
      prompts: {
        "Hero": "editorial product photograph of a handcrafted luxury faux botanical wreath, foliage-forward asymmetric side sweep composition, two open ivory silk peonies anchoring an extended sweep of silvery sage dusty miller from 8 to 12 o'clock, matte olive-leaf foliage fanning outward along the sweep, heavier matte slate-blue viburnum berry clusters massed at 9 to 11 o'clock, no blooms in the lower arc, exposed grapevine base readable throughout the lower half and right quadrant, velvet foliage with organic directional lean, wired stems holding natural curves, dimensional midground depth, soft north-facing window light, hung on a warm grey limewash plaster wall, 85mm medium format, shallow depth of field, premium home decor editorial aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark",
        "Variant A": "editorial product photograph of a small handcrafted luxury faux botanical wreath on an interior hallway door, foliage-forward asymmetric side sweep with two ivory silk peonies at the upper arc, dusty miller and olive-leaf foliage sweeping from 8 to 12 o'clock, slate-blue viburnum berries clustered at 10 o'clock, bare grapevine throughout the lower arc, calm neutral hallway with plaster walls, soft window light from the left, 85mm, shallow depth of field, premium interiors editorial --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical wreath, silvery sage dusty miller velvet leaf surface in focus, matte slate-blue viburnum berries nestled at the foliage edge, wired stems showing organic direction, dimensional material depth, soft diffused window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "ledge", name: "The Ledge", role: "Supporting",
      scale: "48in Garland", formula: "Linear Directional", price: "$165–$185", done: false,
      prompts: {
        "Hero": "editorial product photograph of a handcrafted luxury faux botanical garland draped naturally across a painted wood mantel shelf, linear directional arrangement densest at center with three velvet magnolia buds and a layered cluster of silvery sage dusty miller and matte olive-leaf foliage, matte slate-blue viburnum berry sprigs tucked throughout at irregular intervals, garland tapering to loose dusty miller wisps and bare stems at both ends, left end slightly denser than right, natural bow at center from its own weight, organic side cascades over the mantel edge, dimensional layering from foliage base to bud surface, soft north-facing window light, grey plaster wall in background, 85mm medium format, shallow focus at center cluster, premium home decor editorial catalog --ar 3:2 --v 7 --style raw --s 150 --no symmetry, centered mass, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, stiff placement, cartoon, text, watermark",
        "Variant A": "editorial product photograph of a luxury faux botanical garland draped over a narrow oak console table, asymmetric directional composition densest at center left, silvery sage dusty miller and magnolia buds clustered at the drape peak, slate-blue viburnum sprigs graduating outward, both ends trailing naturally toward the floor with organic looseness, ceramic vessel and folded linen in the soft background, warm grey plaster wall, north window light, 85mm, shallow depth, premium interiors editorial --ar 3:2 --v 7 --style raw --s 150 --no symmetry, fresh flowers, stiff arrangement, plastic shine, craft store, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical garland center cluster, velvet magnolia bud at peak surrounded by silvery dusty miller, matte viburnum berries nestled at foliage base, layered stem structure visible beneath, soft directional light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "rings", name: "Still Rings", role: "Atmospheric Filler",
      scale: "8in × 2", formula: "Asymmetric Cluster", price: "$55–$65 / set", done: false,
      prompts: {
        "Hero": "editorial product photograph of two small handcrafted luxury faux botanical candle rings on a warm-toned wood console surface, each ring a grapevine base with an asymmetric cluster of one small ivory silk peony bud at 8 o'clock, three silvery sage dusty miller leaves fanning from 6 to 11 o'clock, two matte slate-blue viburnum berry stems graduating outward, exposed grapevine visible through the lower half of each ring, two rings positioned at slightly different angles with one overlapping the other for editorial depth, no candles in frame, soft north-facing window light, warm grey plaster wall behind, 85mm medium format, shallow depth of field, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, centered cluster, matching identical pair, fresh flowers, wilting, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark",
        "Variant A": "editorial lifestyle photograph of two small luxury faux botanical candle rings encircling natural pillar candles on a wood console surface, asymmetric ivory bud and dusty miller clusters at 8 o'clock per ring, matte slate-blue berry sprigs at the crown, exposed grapevine in the lower arcs, candles unlit, warm grey plaster wall, north window light, soft editorial composition, premium home decor styling --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, glitter, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a small luxury faux botanical candle ring, ivory silk peony bud at 8 o'clock in focus, silvery dusty miller fanning beneath, matte viburnum berries at the edge, exposed grapevine base visible, layered materials, soft window light, macro product detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "gateway", name: "First Light", role: "Gateway",
      scale: "14in", formula: "Classic Asymmetric", price: "$95–$115", done: false,
      prompts: {
        "Hero": "editorial product photograph of a small handcrafted luxury faux botanical wreath, a single open ivory silk peony anchoring the composition at 9 o'clock, silvery sage dusty miller curving from 7 to 12 o'clock in a quiet asymmetric crescent, four matte slate-blue viburnum berry sprigs graduating in size toward the crown, no florals in the lower arc, exposed grapevine base visible and deliberate from 1 to 6 o'clock, structured silk petal with natural fold memory and velvet foliage with organic directional lean, compact and restrained, soft north-facing window light, hung on a warm grey limewash plaster wall with warm wood ledge below, 85mm medium format, shallow depth of field, premium home decor editorial catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark",
        "Variant A": "editorial product photograph of a small luxury faux botanical wreath resting against a wrapped gift box on a warm wood surface, single ivory silk peony at 9 o'clock, quiet dusty miller crescent sweeping the upper arc, slate-blue berry sprigs at the crown, exposed grapevine in the lower half, kraft paper wrapping soft in the background, north window light, warm grey plaster wall, minimal props, premium home decor gifting aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, busy background, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a small luxury faux botanical wreath, single open ivory silk peony in focus, silvery dusty miller velvet leaves fanning behind, matte slate berry sprigs at the edge, dimensional petal texture with natural fold lines, soft side window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
    {
      id: "accent", name: "Sage + Berry Picks", role: "Accent",
      scale: "6-stem bundle", formula: "Loose bundle", price: "$22–$32", done: false,
      prompts: {
        "Hero": "editorial product photograph of a small handcrafted luxury faux botanical stem bundle, three silvery sage dusty miller stems and two matte slate-blue viburnum berry stems and one matte olive-leaf branch loosely wrapped in natural kraft paper twine, arranged with organic looseness and directional lean, stems at slightly varying heights, resting against a warm grey plaster wall on a warm wood surface, north window light, matte surfaces throughout, 85mm medium format, shallow depth of field, minimal editorial product styling, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, arranged bouquet, fresh flowers, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark",
        "Variant A": "editorial lifestyle photograph of a loose luxury faux botanical stem bundle styled in a narrow ceramic vase on a wood console, sage dusty miller and slate-blue viburnum berries and olive leaf branch in natural organic arrangement, warm grey plaster wall, north window light, single white ceramic vessel, minimal styling, premium interiors catalog --ar 5:4 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, symmetry, craft store, cartoon, text, watermark",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical stem bundle, silvery dusty miller velvet leaf surface in focus, matte slate-blue viburnum berry cluster beside it, natural kraft twine wrapping visible at base, organic loose arrangement, soft directional light, macro botanical product detail --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark",
      }
    },
  ]
};

// ══════════════════════════════════════════════════════════
// APP
// ══════════════════════════════════════════════════════════

export default function App() {
  const [collections, setCollections] = useState([QUIET_ACCORD]);
  const [activeIdx, setActiveIdx] = useState(0);

  // Per-collection tracked state — keyed by `collId|prodId`
  const [doneMap, setDoneMap]   = useState({ "quiet_accord|hero": true });
  const [tabMap, setTabMap]     = useState({});
  const [customMap, setCustomMap] = useState({});
  const [copied, setCopied]     = useState({});

  // ORef (global)
  const [orefUrl, setOrefUrl]   = useState("");
  const [orefOn, setOrefOn]     = useState(false);

  // Intent panel
  const [showIntent, setShowIntent]   = useState(false);
  const [intentForm, setIntentForm]   = useState({ name: "", season: "", brief: "", hero: "" });
  const [isGenerating, setIsGenerating] = useState(false);
  const [genStepIdx, setGenStepIdx]   = useState(0);
  const [genError, setGenError]       = useState("");

  const coll = collections[activeIdx];

  // Animate gen steps
  useEffect(() => {
    if (!isGenerating) return;
    setGenStepIdx(0);
    const iv = setInterval(() => setGenStepIdx(i => (i + 1) % GEN_STEPS.length), 1800);
    return () => clearInterval(iv);
  }, [isGenerating]);

  // Helpers
  const fp = useCallback((base) => {
    if (!orefOn || !orefUrl.trim()) return base;
    return base.replace("--ar", `--oref ${orefUrl.trim()} --ow 75 --ar`);
  }, [orefOn, orefUrl]);

  const key = (prodId, suffix = "") => `${coll.id}|${prodId}${suffix ? "|" + suffix : ""}`;

  const isDone = (prodId) => !!doneMap[key(prodId)];
  const toggleDone = (prodId) => setDoneMap(p => ({ ...p, [key(prodId)]: !p[key(prodId)] }));

  const getTab = (prod) => tabMap[key(prod.id)] || Object.keys(prod.prompts)[0];
  const setTab = (prodId, tab) => setTabMap(p => ({ ...p, [key(prodId)]: tab }));

  const getCustom = (prodId) => customMap[key(prodId)] || {};
  const updCustom = (prodId, patch) => setCustomMap(p => ({
    ...p, [key(prodId)]: { ...p[key(prodId)], ...patch }
  }));

  const doCopy = async (text, ck) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(p => ({ ...p, [ck]: true }));
      setTimeout(() => setCopied(p => ({ ...p, [ck]: false })), 2000);
    } catch {}
  };

  const doneCount = coll.products.filter(p => isDone(p.id)).length;

  // Generate collection
  const handleGenerate = async () => {
    if (!intentForm.brief.trim()) return;
    setIsGenerating(true); setGenError("");

    const userMsg = [
      intentForm.name && `Collection working name: ${intentForm.name}`,
      intentForm.season && `Season and timing: ${intentForm.season}`,
      `Collection intent: ${intentForm.brief}`,
      intentForm.hero && `Hero floral(s): ${intentForm.hero}`,
    ].filter(Boolean).join("\n");

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 8000,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: userMsg }],
        }),
      });

      const data = await res.json();
      const raw = data.content?.[0]?.text?.trim() || "";
      const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
      if (s === -1 || e === -1) throw new Error("Response did not contain valid JSON");

      const parsed = JSON.parse(raw.slice(s, e + 1));
      if (!Array.isArray(parsed.products) || parsed.products.length === 0)
        throw new Error("Generated collection has no products");

      const newId = parsed.id || `coll_${Date.now()}`;
      const newColl = { ...parsed, id: newId };

      setCollections(prev => [...prev, newColl]);
      setActiveIdx(collections.length);
      setShowIntent(false);
      setIntentForm({ name: "", season: "", brief: "", hero: "" });
    } catch (err) {
      setGenError(err.message || "Unknown error. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate custom variant
  const handleCustomVariant = async (prod, basePrompt) => {
    const cs = getCustom(prod.id);
    if (!cs.input?.trim() || cs.loading) return;
    updCustom(prod.id, { loading: true, result: null });
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          system: "You are a luxury faux botanical render prompt specialist for the Evercrafted system. Modify Midjourney render prompts per user instructions. Preserve Style DNA: asymmetric clock-position composition, matte silk/velvet faux materials, editorial product photography direction, exposed grapevine negative space, all --parameters. Return ONLY the modified prompt — no preamble, no markdown, no explanation.",
          messages: [{ role: "user", content: `Base prompt:\n${basePrompt}\n\nModification: ${cs.input.trim()}` }],
        }),
      });
      const data = await res.json();
      updCustom(prod.id, { loading: false, result: data.content?.[0]?.text?.trim() || "No result." });
    } catch {
      updCustom(prod.id, { loading: false, result: "Network error. Please try again." });
    }
  };

  // Download
  const handleDownload = () => {
    const content = coll.products.map(p => {
      const hdr = `${"═".repeat(60)}\n${p.name.toUpperCase()} · ${p.role}\n${p.scale} · ${p.formula} · ${p.price}\n${"═".repeat(60)}`;
      const pts = Object.entries(p.prompts).map(([l, t]) => `── ${l} ──\n${fp(t)}`).join("\n\n");
      return `${hdr}\n\n${pts}`;
    }).join("\n\n\n");

    const blob = new Blob([`${coll.collectionName.toUpperCase()} — RENDER PROMPTS\nEvercrafted Studio\n\n${content}`], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    Object.assign(document.createElement("a"), { href: url, download: `${coll.id}-prompts.txt` }).click();
    URL.revokeObjectURL(url);
  };

  const removeCollection = (idx) => {
    if (collections.length <= 1) return;
    setCollections(p => p.filter((_, i) => i !== idx));
    setActiveIdx(p => p >= idx ? Math.max(0, p - 1) : p);
  };

  // ─── RENDER ───────────────────────────────────────────
  return (
    <div style={{ background: "#141416", minHeight: "100vh", color: "#e2ddd6", fontFamily: "system-ui, -apple-system, sans-serif" }}>

      {/* ── HEADER ── */}
      <div style={{ padding: "22px 24px 0", borderBottom: "1px solid #242428" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: "10px", letterSpacing: "0.18em", color: "#5a5a62", textTransform: "uppercase", marginBottom: "5px" }}>
              Evercrafted · Collection Render Studio
            </div>
            <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.1em", color: "#e8e2d8" }}>
              {coll.collectionName.toUpperCase()}
            </div>
            <div style={{ fontSize: "11px", color: "#5a5a62", marginTop: "3px" }}>
              {coll.season} · {coll.atmosphere} · {coll.priceRange}
            </div>
            {coll.palette && (
              <div style={{ display: "flex", gap: "6px", marginTop: "8px", flexWrap: "wrap" }}>
                {coll.palette.map(c => (
                  <span key={c} style={{ fontSize: "10px", color: "#7a7a82", background: "#1e1e22", border: "1px solid #2a2a2e", borderRadius: "3px", padding: "2px 8px", letterSpacing: "0.04em" }}>{c}</span>
                ))}
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: "8px", marginTop: "4px" }}>
            <button onClick={handleDownload} style={btnStyle("#2a2a2e", "#3a3a3e", "#c8c2b8")}>↓ Export</button>
            <button onClick={() => { setShowIntent(true); setGenError(""); }} style={btnStyle("#1e2a20", "#2d4030", "#8abf98")}>+ New Collection</button>
          </div>
        </div>

        {/* ── COLLECTION TABS ── */}
        <div style={{ display: "flex", gap: "0", marginTop: "16px", overflowX: "auto" }}>
          {collections.map((c, i) => (
            <div
              key={c.id}
              style={{
                display: "flex", alignItems: "center", gap: "6px",
                padding: "8px 14px",
                borderBottom: i === activeIdx ? "2px solid #6a9e7a" : "2px solid transparent",
                color: i === activeIdx ? "#e2ddd6" : "#6a6a72",
                cursor: "pointer", fontSize: "12px", whiteSpace: "nowrap",
                fontWeight: i === activeIdx ? "500" : "400",
                transition: "color 0.15s"
              }}
              onClick={() => setActiveIdx(i)}
            >
              {c.collectionName}
              {collections.length > 1 && (
                <span
                  onClick={e => { e.stopPropagation(); removeCollection(i); }}
                  style={{ color: "#4a4a52", fontSize: "13px", lineHeight: 1, padding: "0 2px", cursor: "pointer" }}
                  title="Remove collection"
                >×</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* ── OREF PANEL ── */}
      <div style={{ padding: "12px 24px", background: "#1a1a1e", borderBottom: "1px solid #222226", display: "flex", alignItems: "center", gap: "10px" }}>
        <button
          onClick={() => setOrefOn(o => !o)}
          style={{ ...btnStyle(orefOn ? "#1e3028" : "#222226", orefOn ? "#3a6048" : "#2e2e32", orefOn ? "#7abf8a" : "#6a6a72"), whiteSpace: "nowrap", fontSize: "11px" }}
        >
          {orefOn ? "● --oref on" : "○ --oref off"}
        </button>
        <input
          value={orefUrl}
          onChange={e => setOrefUrl(e.target.value)}
          placeholder="Paste Midjourney hero render URL here to lock style across collection..."
          style={{ flex: 1, background: "#1e1e22", border: `1px solid ${orefUrl && orefOn ? "#3a6048" : "#2e2e32"}`, borderRadius: "6px", color: "#c8c2b8", fontSize: "11px", padding: "6px 10px", outline: "none", fontFamily: "monospace" }}
        />
        <div style={{ fontSize: "10px", color: "#3e3e42", whiteSpace: "nowrap" }}>
          {orefOn && orefUrl.trim() ? "--ow 75 appended" : "adds style consistency"}
        </div>
      </div>

      {/* ── PROGRESS ── */}
      <div style={{ padding: "10px 24px 0", display: "flex", alignItems: "center", gap: "10px" }}>
        <span style={{ fontSize: "10px", color: "#5a5a62", whiteSpace: "nowrap" }}>{doneCount}/{coll.products.length} rendered</span>
        <div style={{ display: "flex", gap: "3px", flex: 1 }}>
          {coll.products.map(p => (
            <div key={p.id} style={{
              flex: 1, height: "3px", borderRadius: "2px",
              background: isDone(p.id) ? (RS[p.role]?.badge || "#5a8a5a") : "#222226",
              transition: "background 0.3s"
            }} />
          ))}
        </div>
        <span style={{ fontSize: "10px", color: "#5a5a62" }}>{coll.priceRange}</span>
      </div>

      {/* ── PRODUCT CARDS ── */}
      <div style={{ padding: "14px 24px 40px", display: "flex", flexDirection: "column", gap: "10px" }}>
        {coll.products.map(prod => {
          const rs = RS[prod.role] || RS["Accent"];
          const done = isDone(prod.id);
          const tab = getTab(prod);
          const base = prod.prompts[tab] || "";
          const display = fp(base);
          const ck = key(prod.id, tab);
          const cs = getCustom(prod.id);

          return (
            <div key={prod.id} style={{ background: "#1c1c20", border: `1px solid ${done ? rs.dim : "#242428"}`, borderRadius: "10px", overflow: "hidden", transition: "border-color 0.3s" }}>

              {/* Card header */}
              <div style={{ padding: "13px 16px 10px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "7px", flexWrap: "wrap", marginBottom: "4px" }}>
                    <span style={{ background: rs.badge, color: "#fff", fontSize: "9px", fontWeight: "600", padding: "2px 7px", borderRadius: "3px", letterSpacing: "0.06em", textTransform: "uppercase" }}>{prod.role}</span>
                    {done && <span style={{ fontSize: "10px", color: "#7abf8a" }}>✓ Rendered</span>}
                    {prod.note && <span style={{ fontSize: "10px", color: "#6a9e7a" }}>{prod.note}</span>}
                  </div>
                  <div style={{ fontSize: "14px", fontWeight: "500", color: "#e8e2d8" }}>{prod.name}</div>
                  <div style={{ fontSize: "10px", color: "#5a5a62", marginTop: "2px" }}>{prod.scale} · {prod.formula} · {prod.price}</div>
                </div>
                <button onClick={() => toggleDone(prod.id)} style={{ ...btnStyle(done ? "#1e3028" : "transparent", done ? rs.dim : "#303034", done ? "#7abf8a" : "#5a5a5e"), fontSize: "11px", flexShrink: 0, marginLeft: "10px" }}>
                  {done ? "✓ Done" : "Mark Done"}
                </button>
              </div>

              {/* Prompt tabs */}
              <div style={{ display: "flex", borderTop: "1px solid #222226", borderBottom: "1px solid #222226" }}>
                {Object.keys(prod.prompts).map(t => (
                  <button key={t} onClick={() => setTab(prod.id, t)} style={{
                    flex: 1, padding: "6px 4px", background: "transparent", border: "none",
                    borderBottom: t === tab ? `2px solid ${rs.badge}` : "2px solid transparent",
                    color: t === tab ? "#e2ddd6" : "#5a5a62", fontSize: "10px", cursor: "pointer",
                    fontWeight: t === tab ? "500" : "400", transition: "color 0.15s",
                  }}>{t}</button>
                ))}
              </div>

              {/* Prompt display */}
              <div style={{ padding: "11px 16px 0" }}>
                <textarea
                  readOnly value={display}
                  onClick={e => e.target.select()}
                  style={{ width: "100%", height: "100px", background: "#111114", border: "1px solid #222226", borderRadius: "6px", color: "#a8a2a0", fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box", cursor: "text" }}
                />
                <button
                  onClick={() => doCopy(display, ck)}
                  style={{ ...btnStyle(copied[ck] ? "#1e3028" : "#1e1e22", copied[ck] ? rs.dim : "#2a2a2e", copied[ck] ? "#7abf8a" : "#c8c2b8"), marginTop: "6px", width: "100%", fontSize: "11px", padding: "8px" }}
                >
                  {copied[ck] ? "✓ Copied" : "Copy Prompt"}
                </button>
              </div>

              {/* Custom variant */}
              <div style={{ padding: "8px 16px 14px" }}>
                <button onClick={() => updCustom(prod.id, { open: !cs.open })} style={{ background: "transparent", border: "none", color: "#484850", fontSize: "10px", cursor: "pointer", padding: "0", display: "flex", alignItems: "center", gap: "5px" }}>
                  <span style={{ display: "inline-block", transition: "transform 0.2s", transform: cs.open ? "rotate(90deg)" : "none" }}>›</span>
                  Generate Custom Variant via Claude
                </button>

                {cs.open && (
                  <div style={{ marginTop: "8px" }}>
                    <textarea
                      value={cs.input || ""}
                      onChange={e => updCustom(prod.id, { input: e.target.value })}
                      placeholder={`e.g. "adapt for spring with blush ranunculus" · "evening moody light" · "burgundy and dusty rose"`}
                      style={{ width: "100%", height: "50px", background: "#111114", border: "1px solid #222226", borderRadius: "6px", color: "#b8b2b0", fontSize: "10.5px", lineHeight: "1.5", padding: "8px 10px", resize: "none", fontFamily: "system-ui, sans-serif", boxSizing: "border-box", outline: "none" }}
                    />
                    <button
                      onClick={() => handleCustomVariant(prod, base)}
                      disabled={cs.loading || !cs.input?.trim()}
                      style={{ ...btnStyle(cs.loading ? "#111114" : "#141e1a", cs.loading ? "#222226" : "#243430", cs.loading ? "#484850" : "#7ab8a8"), marginTop: "5px", width: "100%", fontSize: "11px", padding: "7px", cursor: cs.loading ? "wait" : "pointer" }}
                    >
                      {cs.loading ? "Generating..." : "Generate →"}
                    </button>
                    {cs.result && (
                      <div style={{ marginTop: "7px" }}>
                        <textarea
                          readOnly value={cs.result}
                          onClick={e => e.target.select()}
                          style={{ width: "100%", height: "100px", background: "#0d1a12", border: "1px solid #243430", borderRadius: "6px", color: "#7abf9a", fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box" }}
                        />
                        <button
                          onClick={() => doCopy(cs.result, key(prod.id, "custom"))}
                          style={{ ...btnStyle("#0d1a12", "#243430", "#7abf8a"), marginTop: "4px", width: "100%", fontSize: "11px", padding: "6px" }}
                        >
                          {copied[key(prod.id, "custom")] ? "✓ Copied" : "Copy Custom Variant"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid #1e1e22", padding: "12px 24px", display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: "10px", color: "#3a3a42", letterSpacing: "0.06em" }}>EVERCRAFTED · COLLECTION RENDER STUDIO</span>
        <span style={{ fontSize: "10px", color: "#3a3a42" }}>{doneCount} of {coll.products.length} complete</span>
      </div>

      {/* ════════════════════════════════════════════════════
          INTENT PANEL OVERLAY
      ════════════════════════════════════════════════════ */}
      {showIntent && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(10,10,12,0.88)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: "20px" }}>
          <div style={{ background: "#1a1a1e", border: "1px solid #2e2e34", borderRadius: "14px", width: "100%", maxWidth: "560px", overflow: "hidden" }}>

            {isGenerating ? (
              /* Generating state */
              <div style={{ padding: "48px 40px", textAlign: "center" }}>
                <div style={{ fontSize: "10px", letterSpacing: "0.16em", color: "#5a5a62", textTransform: "uppercase", marginBottom: "24px" }}>
                  Evercrafted · Building Collection
                </div>
                <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.08em", color: "#c8c2b8", marginBottom: "8px" }}>
                  {intentForm.name ? intentForm.name.toUpperCase() : "NEW COLLECTION"}
                </div>
                <div style={{ fontSize: "12px", color: "#5a5a62", marginBottom: "32px" }}>{intentForm.season || "Seasonal collection"}</div>

                {/* Animated steps */}
                <div style={{ display: "flex", flexDirection: "column", gap: "10px", maxWidth: "360px", margin: "0 auto 32px" }}>
                  {GEN_STEPS.map((step, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: i <= genStepIdx ? 1 : 0.2, transition: "opacity 0.4s" }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: i === genStepIdx ? "#6a9e7a" : i < genStepIdx ? "#3a6048" : "#2a2a2e", flexShrink: 0, transition: "background 0.4s" }} />
                      <span style={{ fontSize: "12px", color: i === genStepIdx ? "#c8c2b8" : i < genStepIdx ? "#4a6a52" : "#3a3a42", textAlign: "left" }}>{step}</span>
                    </div>
                  ))}
                </div>

                {/* Subtle pulse bar */}
                <div style={{ height: "2px", background: "#1e1e22", borderRadius: "1px", overflow: "hidden", maxWidth: "200px", margin: "0 auto" }}>
                  <div style={{ height: "100%", background: "#4a7a5e", borderRadius: "1px", animation: "pulse-bar 1.8s ease-in-out infinite" }} />
                </div>
                <style>{`@keyframes pulse-bar { 0%{width:0%} 50%{width:80%} 100%{width:100%} }`}</style>

                {genError && (
                  <div style={{ marginTop: "20px", padding: "10px 14px", background: "#1a1010", border: "1px solid #5a2a2a", borderRadius: "6px", color: "#c87a7a", fontSize: "11px" }}>
                    {genError}
                    <button onClick={() => setIsGenerating(false)} style={{ ...btnStyle("#2a1010", "#5a2a2a", "#c87a7a"), marginTop: "10px", width: "100%", fontSize: "11px" }}>
                      Try Again
                    </button>
                  </div>
                )}
              </div>
            ) : (
              /* Intent form */
              <div>
                <div style={{ padding: "22px 24px 18px", borderBottom: "1px solid #242428", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "10px", letterSpacing: "0.14em", color: "#5a5a62", textTransform: "uppercase", marginBottom: "4px" }}>Evercrafted</div>
                    <div style={{ fontSize: "16px", fontWeight: "500", color: "#e8e2d8" }}>Create New Collection</div>
                  </div>
                  <button onClick={() => setShowIntent(false)} style={{ background: "transparent", border: "none", color: "#5a5a62", fontSize: "20px", cursor: "pointer", lineHeight: 1 }}>×</button>
                </div>

                <div style={{ padding: "20px 24px" }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "14px" }}>
                    <div>
                      <label style={labelStyle}>Working name</label>
                      <input
                        value={intentForm.name}
                        onChange={e => setIntentForm(p => ({ ...p, name: e.target.value }))}
                        placeholder="e.g. Winter Solstice"
                        style={inputStyle}
                      />
                    </div>
                    <div>
                      <label style={labelStyle}>Season & timing</label>
                      <input
                        value={intentForm.season}
                        onChange={e => setIntentForm(p => ({ ...p, season: e.target.value }))}
                        placeholder="e.g. Late winter, Jan–Mar"
                        style={inputStyle}
                      />
                    </div>
                  </div>

                  <div style={{ marginBottom: "14px" }}>
                    <label style={{ ...labelStyle, display: "flex", justifyContent: "space-between" }}>
                      <span>Collection intent <span style={{ color: "#8B4A4A" }}>*</span></span>
                      <span style={{ color: "#4a4a52", fontWeight: "400" }}>Required — be evocative</span>
                    </label>
                    <textarea
                      value={intentForm.brief}
                      onChange={e => setIntentForm(p => ({ ...p, brief: e.target.value }))}
                      placeholder="Describe the feeling, atmosphere, mood, and world of this collection. Think emotion, season, materials, palette, and who lives in this space. E.g. 'Moody late winter at a Scandinavian farmhouse. Deep burgundy ranunculus and dried seed pods in slate-grey. The feeling of the last cold morning before spring arrives. Restrained, poetic, intentionally quiet.'"
                      style={{ ...inputStyle, height: "110px", resize: "none" }}
                    />
                  </div>

                  <div style={{ marginBottom: "20px" }}>
                    <label style={labelStyle}>Hero floral(s) <span style={{ color: "#4a4a52", fontWeight: "400" }}>optional</span></label>
                    <input
                      value={intentForm.hero}
                      onChange={e => setIntentForm(p => ({ ...p, hero: e.target.value }))}
                      placeholder="e.g. burgundy dahlias, moody ranunculus, dried protea"
                      style={inputStyle}
                    />
                  </div>

                  {genError && !isGenerating && (
                    <div style={{ marginBottom: "12px", padding: "10px 14px", background: "#1a1010", border: "1px solid #5a2a2a", borderRadius: "6px", color: "#c87a7a", fontSize: "11px" }}>
                      {genError}
                    </div>
                  )}

                  <div style={{ display: "flex", gap: "8px" }}>
                    <button onClick={() => setShowIntent(false)} style={{ ...btnStyle("#1a1a1e", "#2a2a2e", "#6a6a72"), flex: "0 0 auto", padding: "10px 18px", fontSize: "12px" }}>
                      Cancel
                    </button>
                    <button
                      onClick={handleGenerate}
                      disabled={!intentForm.brief.trim()}
                      style={{ ...btnStyle("#1a2e22", "#2d5038", "#7abf8a"), flex: 1, fontSize: "13px", fontWeight: "500", padding: "10px", opacity: intentForm.brief.trim() ? 1 : 0.4 }}
                    >
                      Generate Collection with Claude →
                    </button>
                  </div>
                  <div style={{ marginTop: "10px", fontSize: "10px", color: "#3a3a42", textAlign: "center" }}>
                    Generates 7 products · 21 render prompts · full hierarchy — takes 15–30 seconds
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Shared style helpers ──────────────────────────────────
const btnStyle = (bg, border, color) => ({
  background: bg, border: `1px solid ${border}`, borderRadius: "6px",
  color, cursor: "pointer", padding: "5px 12px", transition: "all 0.15s"
});

const labelStyle = {
  display: "block", fontSize: "10px", letterSpacing: "0.06em",
  textTransform: "uppercase", color: "#5a5a62", marginBottom: "6px", fontWeight: "500"
};

const inputStyle = {
  width: "100%", background: "#111114", border: "1px solid #2a2a2e",
  borderRadius: "6px", color: "#c8c2b8", fontSize: "12px",
  padding: "8px 12px", outline: "none", fontFamily: "system-ui, sans-serif",
  boxSizing: "border-box"
};

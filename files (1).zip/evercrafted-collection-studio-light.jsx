import { useState, useEffect, useCallback } from "react";

// ==========================================================
// ROLE STYLES -- light palette
// ==========================================================
const RS = {
  "Premium Anchor":     { badge: "#8B4A4A", bg: "#FDF0F0", border: "#EAD4D4", dim: "#C8A0A0" },
  "Hero":               { badge: "#3A6B4A", bg: "#EFF5EF", border: "#C0D8C0", dim: "#80B890" },
  "Supporting":         { badge: "#3A4F7A", bg: "#EFF2F8", border: "#C0CAE0", dim: "#8098C0" },
  "Atmospheric Filler": { badge: "#6B6032", bg: "#F5F2E8", border: "#D8D0B0", dim: "#B0A870" },
  "Gateway":            { badge: "#5A3A7A", bg: "#F2EFF8", border: "#D4C8E8", dim: "#A090C8" },
  "Accent":             { badge: "#3A7272", bg: "#EEF5F5", border: "#B8D4D4", dim: "#70B0B0" },
  "Lifestyle Render":   { badge: "#7A5A3A", bg: "#F8F3ED", border: "#D8C8B0", dim: "#B09870" },
};

const GEN_STEPS = [
  "Reading your collection intent...",
  "Building floral hierarchy and color movement...",
  "Mapping greenery suite and ribbon journey...",
  "Writing Layer 1 entry prompts...",
  "Writing Layer 2 draw and Layer 3 anchor prompts...",
  "Writing Layer 4 discovery prompts...",
  "Generating lifestyle room renders...",
  "Finalizing the full collection intelligence...",
];

const SYSTEM_PROMPT = `You are the Evercrafted Collection Intelligence Engine -- a complete home botanical design system that generates full-home luxury faux botanical collections with Midjourney render prompts and architectural pencil illustration prompts. You select the right products from a 30-form library based on the collection intent, rather than generating a fixed product list every time.

==========================================
EVERCRAFTED SIGHTLINE PHILOSOPHY
==========================================
Every collection tells a sightline story. When the front door opens the eye travels through four layers:
Layer 1 ENTRY: Front door, foyer, threshold, entry lamps. First impression, boldest botanical expression.
Layer 2 DRAW: Staircase, newel post, interior doorways. Pulls the eye deeper into the home.
Layer 3 ANCHOR: Mantel, chandelier, bookcase, kitchen. Room centerpieces.
Layer 4 DISCOVERY: Chair wreaths, cabinet wreaths, lamp wreaths, candle rings, window wreaths. Found when you look closely.

==========================================
COMPLETE PRODUCT LIBRARY -- 30 forms
==========================================

LAYER 1 -- ENTRY STATEMENT:
E1. Grande Wreath 26-30in -- heavy crescent, front door or entry wall, hero florals Tier 1 full expression, 3-ribbon layered bow
E2. Hero Wreath 22-26in -- standard crescent, front door or primary interior door, Tier 1 featured, 3-ribbon bow
E3. Entry Tree Pair -- two matching cone topiary trees in decorative pots flanking the front entry, botanical-wrapped frame, symmetry is intentional and appropriate here only, sold as pair, 3-ribbon bow on each
E4. Foyer Arrangement -- tall asymmetric vessel arrangement 24-36in on entry console, Tier 1 florals at mid expression, 3-ribbon bow at vessel neck
E5. Threshold Treatment -- full interior door frame: asymmetric header swag + focal bloom cluster at one upper corner + botanical drop one jamb + ribbon-dominant drop other jamb + 3-ribbon layered bows at corner anchors
E6. Lamp Neck Wreath Pair -- two 8-10in botanical collars worn on entry table lamp necks via ribbon loops, small 2-ribbon bow at top, set of 2
E7. Door Swag -- elongated asymmetric spray 18-30in for narrow doors or sidelights, no ring base, stems gathered at center knot, foliage and ribbon trails cascade up and down, 3-ribbon bow at knot

LAYER 2 -- THE DRAW:
D1. Puddle Post Pair -- newel post: dense crown cluster + botanical cascade down one face of post + floor puddle spreading outward, GREENERY-DOMINANT or greenery-only, glass icicles if winter, 3-ribbon bow at crown-to-drop transition, sold as pair
D2. Interior Threshold -- lighter version of Threshold Treatment for room-to-room passages, header swag only or header + light drops, Tier 2 florals
D3. Staircase Cascade -- botanical treatment running along banister or railing, asymmetric directional, heavier at newel post end tapering along railing, greenery dominant, 3-ribbon bow at heaviest point

LAYER 3 -- THE ANCHOR:
A1. Mantel Garland 48-60in -- linear directional, fireplace mantel, Tier 2 florals, glass icicles if winter, 3-ribbon layered bow at center drape
A2. Chandelier Treatment -- botanical wrapping on fixture arms + cascading botanical drops below + glass icicle clusters catching fixture light, 3-ribbon bow at top gathering point
A3. Bookcase Cascade -- botanical treatment at top of tall bookcase cascading down outer face, greenery-dominant, textural discovery florals, 2-ribbon bow at crown
A4. Bookcase Shelf Drape -- small botanical cluster trailing over one or two shelf edges inside a bookcase, no bow, pure greenery and Tier 3 discovery elements
A5. Stove Surround Garland -- botanical garland across wooden range hood surround or kitchen ledge above range, pure greenery dominant, 2-ribbon bow
A6. Kitchen Ledge Garland 24-36in -- simpler shelf garland above range or on kitchen shelf, shorter scale than A5, greenery-only or minimal Tier 2

LAYER 4 -- DISCOVERY:
R1. Chair Wreath Set -- set of 4 x 10in grapevine wreaths on dining chair backs via ribbon loops, Tier 3 florals only, small 2-ribbon bow at ribbon loop top
R2. Cabinet Wreath Pair -- two 8-10in wreaths on kitchen or built-in cabinet door faces, greenery-dominant or greenery-only, 1 simple ribbon loop
R3. Lamp Neck Wreath Set -- pair of 8in botanical collars on table or floor lamp necks, lighter than E6, Tier 3 discovery florals, 1 simple ribbon bow
R4. Window Wreath 8-12in -- hung within kitchen sink window frame, designed to read from both interior and exterior, greenery-dominant, no heavy florals
R5. Pantry Door Wreath 8-10in -- hung on interior face of pantry door, intimate discovery scale, Tier 3 only, simple grosgrain ribbon
R6. Candle Ring Set 2x8in -- grapevine table rings with asymmetric Tier 3 cluster, NO BOW EVER, NO florals above Tier 3
R7. Lantern Collar -- asymmetric greenery and Tier 3 florals spreading around lantern base, heavier one side, 2-ribbon bow at gathering point
R8. Table Centerpiece -- low vessel arrangement 8-14in height for dining or coffee table, Tier 2 florals quiet, 2-ribbon bow at vessel base

SPECIALTY FORMS:
S1. Tabletop Tree -- cone wire frame 12-24in, wrapped botanically: pure greenery at base graduating to Tier 2 florals near crown, 3-ribbon bow at base
S2. Kissing Ball -- botanical sphere 8-14in, massed florals and foliage, hung from ribbon loop with large droopy bow at top where ribbon attaches
S3. Dough Bowl Arrangement -- low sprawling botanical cluster in reclaimed wood or aged dough bowl, organic and asymmetric, no ribbon or subtle 1-ribbon accent
S4. Bottle Brush Tree Cluster -- set of 3 bottle-brush style trees in graduated sizes 3/6/9in, grouped as tabletop vignette, no bow on individual trees
S5. Moon Wreath -- half-crescent grapevine base, botanical cluster concentrated at lower arc, bare upper arc deliberate, same rules as standard wreath but crescent base
S6. Hoop Wreath -- thin metal or wire ring, asymmetric botanical cluster one side only, modern minimal, long ribbon tail not a full bow

ACCENT PACKS:
P1. Icicle Accent Pack -- clusters of glass icicles sold separately, added to staircase greenery (emerging upward), mantel garland (draping downward), or chandelier (hanging below)
P2. Stem Bundle -- 6-stem coordinating botanical pick bundle loosely wrapped in kraft paper twine, small coordinating ribbon bow at wrap point

==========================================
COLLECTION SELECTION ENGINE
==========================================
Do NOT generate a fixed product list. Read the collection intent, infer the home profile, then SELECT 10-16 products from the library above.

HOME SCALE INFERENCE -- read intent signals:
APARTMENT/SMALL (select 8-10): Avoid D1/D3/A2/A3. Prefer E2, E7 or S5/S6, D2, A1 or A5, R6, R7, R8.
STANDARD HOME (select 10-13): E1-E2, D1 or D2, A1, plus 4-6 discovery and accent products.
LARGE HOME (select 13-16): Full E-tier selectively, D1+D2 or D1+D3, 2-3 A-tier, 5-6 R-tier, 1-2 S-tier.
ESTATE (select 16+): Near-complete library. All layers represented. Specialty forms included.

PRODUCT TRIGGER SIGNALS -- include these products when intent contains these signals:
"grand entry / estate / arrival" -> include E3 (Entry Trees) + E5 (Threshold)
"staircase / foyer / traditional / tall ceilings" -> include D1 (Puddle Post)
"banister / railing" -> include D3 (Staircase Cascade)
"dining room / entertaining / hosting / tablescape" -> include A2 (Chandelier) + R1 (Chair Wreaths) + R8 (Centerpiece)
"kitchen / farmhouse / gathering / range / stove" -> include A5 or A6
"library / study / books / bookcase" -> include A3 or A4
"lamps / entry table / side table" -> include E6 or R3
"window / sink / kitchen window" -> include R4 (Window Wreath)
"pantry / discovery / intimate" -> include R5
"minimal / modern / editorial / apartment" -> prefer S5 or S6 over E1; use A5 or A6 not A2
"Christmas / holiday / festive" -> include S1 (Tabletop Tree) + S4 (Bottle Brush) + P1 (Icicle Pack) + R1
"winter / nordic / icy / snow" -> include P1 (Icicle Pack) with any staircase or mantel products
"cottage / farmhouse / rustic / organic" -> include S3 (Dough Bowl) + A5
"romantic / wedding / abundant" -> include S2 (Kissing Ball) + E4 (Foyer Arrangement)
"large door / entry door" -> include E5 (Threshold Treatment)
"cabinet / built-in / kitchen storage" -> include R2 (Cabinet Wreath Pair)

ALWAYS INCLUDE (minimum every collection):
-- At least one primary wreath (E1, E2, S5, or S6)
-- At least one Layer 2 draw product (D1, D2, or D3)
-- At least one Layer 3 anchor product (A1-A6)
-- At least one Layer 4 discovery product (R1-R8)
-- At least one lifestyle render

NEVER include S4 (Bottle Brush Trees) without a Christmas or holiday signal.
NEVER include A2 (Chandelier) for apartment or small home signals.
NEVER put a bow on R6 (Candle Rings) or R4 (Window Wreath).

==========================================
FLORAL HIERARCHY -- resolve before any prompts
==========================================
Tier 1 SIGNATURE: One hero species. Full open bloom expression ONLY at Layer 1. Appears as single buds or accents in Layers 2-3. Completely absent from Layer 4.
Tier 2 SUPPORTING: 2-3 secondary species. Carry the collection through Layers 2 and 3.
Tier 3 DISCOVERY: Small textural species only. ONLY in Layer 4 micro-placement products. Absent from Layer 1.

FLORAL COUNT RULE: Odd numbers always -- 1, 3, 5, 7, or 9 per species. Never 2, 4, 6, or 8.
SPECIES DIVERSITY: Layer 1: 5 species min. Layer 2-3: 4 species. Layer 4: 3 species. Min 7 distinct species across the full collection.

COLOR MOVEMENT:
FULL SATURATION at Layer 1 -- richest boldest palette. MIDTONE at Layers 2-3 -- quieter, more foliage. WHISPER TONE at Layer 4 -- single accent of the palette color. NEUTRAL ANCHOR throughout -- the greenery, constant at all layers.

GREENERY OPTIONS (use multiple species, vary darkness):
Darks: cedar, noble fir, Douglas fir, boxwood, magnolia leaf, bay laurel, seeded eucalyptus
Mids: Fraser fir, pine, olive branch, salal leaf, lemon leaf
Lights/Silver: dusty miller, silver dollar eucalyptus, juniper, blue spruce, lamb's ear
Texturals: pampas grass, dried fern, cotton stem, thistle, dried lavender, seed pods
Winter specials: flocked noble fir, iced cedar tips, frosted eucalyptus, snow-dusted boxwood, glass icicle clusters

GREENERY-ONLY PRODUCTS: D1 Puddle Post, A5/A6 Kitchen Garlands, A4 Shelf Drape, R2 Cabinet Wreath Pair, R4 Window Wreath, R7 Lantern Collar.

==========================================
MULTI-RIBBON SYSTEM
==========================================
Up to 3 ribbons per product, always different widths. NEVER two patterns together.
STATEMENT: widest (5-6in large, 3-4in medium, 2-2.5in small). Solid or subtle texture. Sets the color.
CHARACTER: mid-width (2-2.5in large, 1.5-2in small). THE PATTERN ribbon: plaid, stripe, check, houndstooth, tartan, toile.
ACCENT: narrowest (always 1.5in). Satin, sheer, metallic, organza. Longest tails. Movement ribbon.
DESCRIBE ALL RIBBONS EXPLICITLY in every bow: name each ribbon width, material, color, and pattern.
RIBBON JOURNEY: Entry = lightest (ivory cream pale gold) -> Anchor = richest (deep velvet plaid) -> Discovery = quietest (thin grosgrain single satin).
BOW ON ALL products EXCEPT: Candle Rings (R6), Window Wreath (R4), Shelf Drape (A4), Bottle Brush Trees (S4), Hoop Wreath (S6 uses long tail only, no loops).

==========================================
RENDER PROMPT GRAMMAR -- room first always
==========================================
CONSTANTS ACROSS ALL PRODUCTS: warm light oak herringbone parquet floors visible, tall dark iron steel-frame arched windows if room context, candlelight from wall sconces present in lifestyle renders, large-scale live plants in stone or ceramic pots in room scenes.

WREATH (E1/E2/S5/S6/R1-R5): "editorial product photograph of [room -- warm grey limewash wall above wood ledge / front door / entryway], a handcrafted luxury faux botanical [SIZE]-inch wreath hung at center, [surface] visible above and below establishing scale, [asymmetric crescent species at odd counts with clock positions], [exposed grapevine from X to X o'clock], [layered multi-ribbon bow with all ribbon widths materials colors and pattern named explicitly], florals proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 100 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, oversized blooms, enlarged petals, cartoon, text, watermark"

GARLAND (A1/A5/A6/D3): "editorial product photograph of [surface -- mantel shelf / kitchen range surround / staircase railing], a handcrafted luxury faux botanical garland draped naturally across [surface], linear directional [composition description], [species in odd counts], [multi-ribbon bow with all ribbons named], full [surface] visible establishing garland scale, 85mm medium format, medium-distance product photography, full garland visible within frame --ar 3:2 --v 7 --style raw --s 100 --no symmetry, fresh flowers, plastic shine, craft store, cartoon, text, watermark"

PUDDLE POST (D1): "editorial product photograph of [staircase / foyer room context], a handcrafted luxury faux botanical installation on a [finish] wood newel post, full post height visible from crown to floor puddle establishing architectural scale, [crown cluster species], [cascade down one face], [floor puddle spreading outward], [3-ribbon bow at crown-to-drop transition with all ribbons named], glass icicle clusters if winter, 85mm medium format, full post and floor visible --ar 4:5 --v 7 --style raw --s 100 --no symmetry, florals unless Tier 2, fresh flowers, plastic shine, cartoon, text, watermark"

THRESHOLD (E5/D2): "editorial product photograph of [hallway / doorway room context], handcrafted luxury faux botanical threshold treatment on interior door frame, full door frame height visible, [header swag asymmetrically weighted], [Tier 1 or 2 florals at corner anchors], [botanical drop one jamb], [ribbon drop other jamb], [3-ribbon bows at corner anchors with all ribbons named], full threshold height visible within frame --ar 4:5 --v 7 --style raw --s 100 --no symmetry, fresh flowers, plastic shine, craft store, cartoon, text, watermark"

CHANDELIER (A2): "editorial product photograph of a [room type] interior, handcrafted luxury faux botanical treatment on a [fixture type], room and table visible below establishing ceiling height, [greenery and florals on arms], [botanical drops below fixture at varying lengths], [glass icicle clusters in cascade], [3-ribbon bow at top with all ribbons named], 35mm medium format, full room scene --ar 3:2 --v 7 --style raw --s 100 --no symmetry, fresh flowers, plastic shine, craft store, cartoon, text, watermark"

FOYER ARRANGEMENT (E4): "editorial product photograph of foyer console table against [wall], handcrafted luxury faux botanical [HEIGHT]-inch arrangement in [vessel], full console visible, [species in odd counts], [multi-ribbon bow with all ribbons named], room and floor visible around console, 85mm medium format --ar 5:4 --v 7 --style raw --s 100 --no symmetry, fresh flowers, plastic shine, craft store, oversized blooms, cartoon, text, watermark"

TABLETOP TREE (S1): "editorial product photograph of [surface -- console / sideboard / entry table], a handcrafted luxury faux botanical cone topiary tree [HEIGHT] inches tall on [surface], full tree and surface visible establishing scale, [base greenery species graduating to Tier 2 florals near crown], [3-ribbon bow at base with all ribbons named], warm directional light, 85mm medium format, full tree visible within frame --ar 4:5 --v 7 --style raw --s 100 --no symmetry, fresh flowers, plastic shine, craft store, oversized, cartoon, text, watermark"

ENTRY TREE PAIR (E3): "editorial product photograph of a front entry with [door description], two matching handcrafted luxury faux botanical cone topiary trees in [pot description] flanking the doorway symmetrically, full door and both trees visible establishing entry scale, [botanical species on trees in odd counts], [3-ribbon bow at base of each tree with all ribbons named], exterior light or covered entry light, 85mm medium format, full entry scene within frame --ar 3:2 --v 7 --style raw --s 100 --no asymmetric (entry pair is intentionally symmetric), fresh flowers, plastic shine, craft store, cartoon, text, watermark"

LIFESTYLE ROOM RENDER -- choose register based on collection atmosphere:
REGISTER 1 DARK DRAMA (Christmas, deep winter, moody): near-black lacquered walls, dark coffered ceiling, cognac leather Chesterfield or dark sectional, iron wall sconces, pillar candles on trunk table, arched doorway framing room beyond
REGISTER 2 EUROPEAN WARMTH (Nordic calm, autumn, transitional): warm putty greige panel walls, coffered beamed ceiling, linen sectional, antique trunk table, afternoon light through arched steel-frame windows, olive tree in terracotta
REGISTER 3 AGED PLASTER (quiet luxury, spring, artisan): raw weathered plaster walls, dark coffered beamed ceiling, glass lantern pendant, ceramic urn lamps, grey linen seating, arched door to exterior courtyard
"editorial interior lifestyle photograph in the style of [register] campaign photography, [room] with [architectural features], [furnishings], [botanical treatment placed naturally], [light quality], full room visible, botanical treatment discovered not spotlit, 35mm medium format --ar 3:2 --v 7 --style raw --s 100 --no staged, white background, product photography, fresh flowers, plastic shine, craft store, cartoon, text, watermark"

SKETCH PROMPT (every product gets one): "pencil and ink architectural interior illustration, [product in complete room context -- never a close-up], fine cross-hatched ink line work for shadows and architectural detail, [botanical elements in loose gestural strokes], [ribbon bow if product has one in elegant flowing lines], cream sepia paper background, warm shadow hatching, editorial botanical architectural illustration --ar [same as Hero] --v 7 --style raw --s 200 --no color, photograph, realistic rendering, digital painting, watercolor"

PHASE-STACK RENDERS (wreath products only -- E1/E2/S5/S6 and all ring forms):
Generate 3 additional prompts -- Phase 1, Phase 2, Phase 3 -- alongside Hero/Variant A/Detail Crop/Sketch.
These are the production-quality render method. Single-shot Hero is for testing only.

PHASE 1 -- Greenery + Base (no florals, no accents, no bow):
Same room-first opening and ASYMMETRIC CRESCENT COMPOSITION language as Hero. Include ALL foliage species with visual descriptions (dusty miller silver-felt velvet leaves, grey eucalyptus round oval leaves, etc). Include silence arc language. NO floral species mentioned anywhere. End with: --ar 1:1 --style raw --s 50 --v 7 plus --no block. No --iw parameter.

PHASE 2 -- Hero Florals (florals and buds only -- greenery already locked in Phase 1):
Open with product/photography register. Name ONLY the hero floral species with full silk physics language (fabric grain, petal drape, woven texture, petal memory). Clock positions, bloom stages, exact sizes. Three supporting buds. No foliage language (already locked). End with: --iw [PASTE PHASE 1 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7 plus --no block including "no dried no papery no plastic sheen".

PHASE 3 -- Complete Finished Wreath (CRITICAL RULE: Phase 3 must describe THE COMPLETE WREATH -- every element from Phase 1 AND Phase 2 AND the new Phase 3 additions. --iw locks composition and style but NOT content. If Phase 3 only names the new elements MJ will drop everything from previous phases):
Open with product/photography register. Then describe IN FULL: (1) the foliage background briefly, (2) ALL hero florals from Phase 2 with clock positions and silk physics, (3) ALL supporting buds from Phase 2, (4) the new accent species with visual descriptions, (5) the full multi-ribbon bow with ALL ribbon widths materials colors and patterns named explicitly, (6) the silence arc as designed feature. End with: --iw [PASTE PHASE 2 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7 plus --no block including "no symmetrical bow no stiff ribbon no bow at top".

IMPORTANT: In Phase 2 and Phase 3 prompts, write the placeholder text exactly as shown -- [PASTE PHASE 1 URL HERE] and [PASTE PHASE 2 URL HERE] -- so users know where to insert the URL from the previous phase result.

==========================================
COLLECTION METADATA -- include in every JSON
==========================================
sightlineStory: one sentence describing what you see from the front door inward
floralHierarchy: tier1Signature, tier2Supporting (array), tier3Discovery (array)
greenerySuite: darks, mids, lights, texturals, snowTreatment
ribbonJourney: entry, draw, anchor, discovery (each with statement, character, accent)
colorMovement: fullSaturation, midTone, whisperTone, neutralAnchor
greenerOnlyProducts: array of product names with zero florals
selectedForms: array of form codes from library (e.g. ["E1","E2","D1","A1","A2","R1","R6","R7","P1"])

==========================================
OUTPUT FORMAT
==========================================
Return ONLY valid JSON. No markdown. No explanation. No text before or after.
For each product generate: id, name, role, layer (1-4), formCode (from library e.g. "E1"), scale, formula, price, done:false, prompts with Hero + Variant A + Detail Crop + Sketch.

{"id":"...","collectionName":"...","season":"...","atmosphere":"...","priceRange":"...","palette":[...],"sightlineStory":"...","floralHierarchy":{...},"greenerySuite":{...},"ribbonJourney":{...},"colorMovement":{...},"greenerOnlyProducts":[...],"selectedForms":[...],"products":[...variable count based on selection engine...]}`;

// ==========================================================
// INITIAL COLLECTION -- QUIET ACCORD
// ==========================================================
const QUIET_ACCORD = {
  id: "quiet_accord", collectionName: "Quiet Accord",
  season: "Late Autumn -> Deep Winter", atmosphere: "Nordic Calm",
  priceRange: "$22 -- $325",
  palette: ["Ivory Mist", "Sage Smoke", "Slate Berry", "Warm Bark"],
  products: [
    {
      id: "grande", name: "Quiet Accord Grande", role: "Premium Anchor",
      scale: "28in", formula: "Heavy Crescent Extended", price: "$295-$325", done: false,
      prompts: {
        "Hero": "editorial product photograph of a warm grey limewash plaster wall above a warm wood ledge, a handcrafted luxury faux botanical 28-inch wreath hung at center, wall clearly visible above and below the wreath establishing its scale, an extended asymmetric crescent of five open ivory silk peonies and three velvet magnolia buds sweeping from 6 to 12 o'clock, silvery sage dusty miller and silver-dollar eucalyptus wisping outward beyond the ring edge in trailing arcs, matte slate-blue viburnum berry clusters punctuating the arc at three irregular intervals, heaviest bloom density anchored from 7 to 10 o'clock, exposed grapevine base visible through deliberate negative space from 2 to 5 o'clock, structured silk petals with natural petal memory and wired stems holding organic directional curves, dimensional layering from foliage foundation to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a wood-toned ledge, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial product photograph of a calm neutral entryway, a large handcrafted luxury faux botanical 28-inch wreath hung on a natural linen-white interior door, full door frame visible above and below establishing wreath scale, asymmetric heavy crescent of five open ivory silk peonies and velvet magnolia buds weighted from 6 to 12 o'clock, dusty miller and silver-dollar eucalyptus trailing outward, matte slate-blue viburnum berries punctuating the arc, exposed grapevine through the lower right arc, soft directional interior light, hung on a natural linen-white interior door in a calm neutral entryway, wide plank floors soft in the lower frame, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail photograph of a luxury faux botanical wreath focal cluster, open ivory silk peony bloom at peak, layered petal structure with natural shadow depth between petals, silvery sage dusty miller velvet leaves fanning beneath, matte slate-blue viburnum berries at right edge, wired silk stems visible at cluster base, dimensional layering, soft side window light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Sketch": "pencil and ink architectural interior illustration, luxury faux botanical wreath on a wall above a wood ledge, fine cross-hatched pencil line work showing wreath ring and asymmetric botanical cascade, ivory peony blooms rendered in loose gestural line, dusty miller leaves in light hatching, viburnum berry clusters as small ink dots, wall sconce to the left, exposed grapevine arc visible, cream sepia paper background, warm shadow cross-hatching on wall and floor, editorial botanical illustration style --ar 5:4 --v 7 --style raw --s 200 --no color, photograph, realistic rendering, digital painting, harsh lines",
        "Phase 1": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester botanicals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 28-inch wreath visible in frame true-to-life scale, complete circular grapevine ring base forming a full unbroken 28-inch loop warm rich dark brown grapevine texture visible and prominent, ASYMMETRIC CRESCENT COMPOSITION -- foliage covers ONLY the lower-left arc from 6:30 through 9 to 12:30 o'clock, upper-right arc from 1:30 through 5:30 is completely bare warm dark grapevine intentional silence arc no foliage, five grey eucalyptus stems background depth -- grey eucalyptus smooth round oval leaves dusty blue-grey-green matte silver-toned each leaf 1 to 1.5 inches not bright green, three matte olive leaf branches 8 through 11 o'clock deep structural background long narrow pointed dark sage-green, seven silvery sage dusty miller clusters 7 to 11:30 o'clock -- silvery-white felt-like velvet surface pale silver-sage each leaf 1 inch distinctly silver not green, three eucalyptus pod sprays 9 to 10 o'clock textural mid-layer, foliage wisps breaking outer silhouette at 12 and 12:30, each stem entering grapevine at unique individual angle organic irregularity front-to-back layering, photographed flat against pale warm grey textured plaster wall front-facing full ring in frame, soft studio daylight from upper left, 85mm lens, no ivy no vine no full ring coverage no symmetrical arrangement no real plants no wilting no bright green no dried foliage --ar 1:1 --style raw --s 50 --v 7",
        "Phase 2": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester florals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 28-inch wreath visible in frame true-to-life scale, five ivory cream faux silk peonies DOMINANT COMMANDING HERO ELEMENT -- primary fully open at 9 o'clock facing viewer 4.5 inches across, secondary mid-open at 8 o'clock 4 inches angled inward, third fully open at 10 o'clock 4 inches, fourth mid-open at 7:30 o'clock 3.5 inches drama pole, fifth bud-stage at 11 o'clock 2 inches ascending -- silk fabric construction visible woven grain, buttery ivory cream not bright white, soft silk petals visible fabric grain gentle light diffusion dimensional curl at outer edges petals have weight and natural soft drape not dried not papery not flat not plastic not crispy not wilted, three sculptural tightly-closed velvet ivory magnolia buds smooth egg-shaped closed form not open -- one at 7 o'clock 1.5 inches, one at 11:30 o'clock 1.8 inches, one at 8:30 o'clock 1.5 inches deep layer, each stem unique individual angle organic irregularity, photographed flat pale warm grey plaster wall soft studio daylight upper left 85mm, no fresh flowers no dew no dried no papery no plastic sheen no open magnolia --iw [PASTE PHASE 1 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7",
        "Phase 3": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester botanicals and florals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 28-inch wreath visible in frame true-to-life scale, complete circular grapevine ring base warm rich dark brown, ASYMMETRIC CRESCENT COMPOSITION botanical mass from 6:30 through 9 to 12:30 o'clock, silence arc from 1:30 through 5:30 o'clock raw exposed dark brown grapevine only -- designed structural feature equal visual value to the botanical mass, grey eucalyptus and silvery sage dusty miller as background foliage layer throughout the botanical arc terminating before the silence arc, five ivory cream faux silk peonies DOMINANT HERO ELEMENT -- primary fully open at 9 o'clock 4.5 inches across, secondary mid-open at 8 o'clock 4 inches angled inward, third fully open at 10 o'clock 4 inches, fourth mid-open at 7:30 o'clock 3.5 inches drama pole heaviest mass point, fifth bud-stage at 11 o'clock 2 inches ascending, all five silk fabric construction visible woven grain buttery ivory cream not bright white soft petal drape not dried not papery not plastic, three sculptural tightly-closed velvet ivory magnolia buds -- one at 7 o'clock ascending, one at 11:30 crown transition, one at 8:30 deep layer, one baby blue hydrangea cluster at 7:30 to 8:30 o'clock mid-ring soft mounded globe 3.5 inches dusty muted baby blue not bright blue not teal matte fabric floret texture subordinate in visual weight to the ivory peonies, three eucalyptus pod accent stems at 9 to 10 o'clock textural layer, a large droopy looped layered ribbon bow at 6 o'clock tails hanging downward toward the floor -- 5-inch wide ivory wire-edge silk statement ribbon outermost loops and longest tails drooping organically, 2-inch wide ivory and pale gold stripe wire-edge character ribbon through center knot with own loops, 1.5-inch pale gold metallic satin accent ribbon at knot center longest trailing tails, all three cascading naturally downward unequal length handmade not symmetrical not stiff, photographed flat pale warm grey textured plaster wall soft studio daylight upper left 85mm --iw [PASTE PHASE 2 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7 --no bright blue, teal, navy, bow at top, symmetrical bow, stiff ribbon, botanicals in silence arc, fresh flowers, plastic shine, dried, papery",
      }
    },
    {
      id: "hero", name: "Quiet Accord", role: "Hero",
      scale: "24in", formula: "Heavy Crescent", price: "$195-$225", done: true,
      note: "Reference render complete -- use this URL as your --oref source",
      prompts: {
        "Hero": "editorial product photograph of a warm grey limewash plaster wall above a warm wood ledge, a handcrafted luxury faux botanical 24-inch wreath hung at center, wall visible above and below establishing the wreath's scale within the room, an asymmetric crescent of three open ivory silk peonies and three velvet magnolia buds sweeping from 7 to 12 o'clock, silvery sage dusty miller and matte olive-leaf foliage extending outward in directional trailing wisps, matte slate-blue viburnum berry clusters punctuating the upper arc, heaviest density anchored at 8 to 10 o'clock, exposed grapevine base deliberate and visible from 1 to 6 o'clock, structured silk petals with natural petal memory, wired stems holding organic curves, dimensional layering from foliage base to focal bloom surface, soft north-facing window light with directional shadow falloff, hung against a warm grey limewash plaster wall above a warm wood ledge, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor editorial catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered arrangement, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial product photograph of a natural linen-white front door with warm stone steps visible below, a handcrafted luxury faux botanical 24-inch wreath hung at center of the door, full door height visible establishing wreath scale, asymmetric crescent of ivory silk peonies and magnolia buds weighted from 7 to 12 o'clock, dusty miller and olive-leaf foliage trailing outward, slate-blue viburnum berries at the crown, exposed grapevine in the lower arc, calm neutral exterior with warm stone steps, soft overcast daylight, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor catalog aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical wreath, open ivory silk peony at peak bloom, layered petal structure with natural shadow between petals, silvery dusty miller velvet leaves beneath, matte slate berry cluster at right, dimensional material depth, soft window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Sketch": "pencil and ink architectural interior illustration, a staircase entry with a luxury faux botanical wreath on the wall, fine cross-hatched pencil line work showing staircase balusters and newel post, wreath drawn in loose gestural botanical line, wall lantern above the wreath casting drawn light rays, potted plant at the base of the newel post, door frame visible at right, cream sepia paper background, warm shadow hatching, editorial pencil sketch illustration --ar 5:4 --v 7 --style raw --s 200 --no color, photograph, realistic, digital painting",
        "Phase 1": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester botanicals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 24-inch wreath visible in frame true-to-life scale, complete circular grapevine ring base 24-inch loop warm rich dark brown grapevine texture visible, ASYMMETRIC CRESCENT COMPOSITION foliage covers ONLY lower-left arc from 7 through 9 to 12 o'clock, upper-right arc from 1 through 5:30 completely bare warm dark grapevine intentional silence arc, three grey eucalyptus stems background depth smooth round oval leaves dusty blue-grey-green matte not bright green, three matte olive leaf branches 8 through 11 o'clock deep structural dark sage-green, five silvery sage dusty miller clusters 7 to 11 o'clock silvery-white felt-like velvet surface pale silver-sage distinctly silver not green, foliage wisps breaking outer silhouette at 11 and 12, each stem unique individual angle organic irregularity front-to-back layering, photographed flat pale warm grey textured plaster wall front-facing full ring, soft studio daylight upper left, 85mm lens, no ivy no vine no full ring coverage no symmetrical arrangement no real plants no wilting no bright green --ar 1:1 --style raw --s 50 --v 7",
        "Phase 2": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester florals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 24-inch wreath visible true-to-life scale, three open ivory cream faux silk peonies DOMINANT HERO -- primary fully open at 9 o'clock 4 to 4.5 inches facing viewer, secondary mid-open at 8 o'clock 4 inches angled inward, third fully open at 10 o'clock 4 inches, two bud-stage peonies one at 7:30 one at 11 ascending, silk fabric construction visible woven grain buttery ivory cream not bright white, soft silk petals visible fabric grain gentle light diffusion dimensional curl petals have weight and natural soft drape not dried not papery not plastic, three sculptural tightly-closed velvet ivory magnolia buds smooth egg-shaped closed form one at 7 o'clock one at 11:30 one at 8:30 deep layer, each stem unique individual angle organic irregularity, photographed flat pale warm grey plaster wall soft studio daylight 85mm, no fresh flowers no dried no papery no plastic sheen no open magnolia --iw [PASTE PHASE 1 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7",
        "Phase 3": "Luxury handcrafted faux botanical wreath, premium artificial silk and polyester botanicals and florals, home decor product photography, photorealistic commercial product photograph, real photograph not illustrated not painted, entire 24-inch wreath visible in frame true-to-life scale, complete circular grapevine ring base warm rich dark brown, ASYMMETRIC CRESCENT COMPOSITION botanical mass from 7 through 9 to 12 o'clock, silence arc from 1 through 5:30 o'clock raw exposed dark brown grapevine only -- designed structural feature equal visual value to the botanical mass, grey eucalyptus and silvery sage dusty miller as background foliage layer throughout the botanical arc, three open ivory cream faux silk peonies DOMINANT HERO -- primary fully open at 9 o'clock 4 to 4.5 inches facing viewer, secondary mid-open at 8 o'clock 4 inches angled inward, third fully open at 10 o'clock 4 inches, two bud-stage peonies one at 7:30 one at 11 o'clock ascending, all five silk fabric construction visible woven grain buttery ivory cream soft petal drape not dried not papery not plastic, three sculptural tightly-closed velvet ivory magnolia buds -- one at 7 o'clock, one at 11:30, one at 8:30 deep layer, one baby blue hydrangea cluster at 7:30 to 8:30 o'clock soft mounded globe 3 to 3.5 inches dusty muted baby blue not bright blue not teal matte fabric floret texture subordinate to peonies, three eucalyptus pod stems at 9 to 10 o'clock textural accent, a large droopy looped layered ribbon bow at 6 o'clock tails hanging downward toward the floor -- 5-inch ivory wire-edge silk statement ribbon outermost loops longest tails drooping organically, 2-inch ivory and pale gold stripe wire-edge character ribbon center knot own loops, 1.5-inch pale gold metallic satin accent ribbon longest trailing tails, all three cascading naturally downward unequal length handmade not symmetrical not stiff, photographed flat pale warm grey plaster wall soft studio daylight upper left 85mm --iw [PASTE PHASE 2 URL HERE] 1.5 --ar 1:1 --style raw --s 100 --v 7 --no bright blue, teal, navy, bow at top, symmetrical bow, stiff ribbon, botanicals in silence arc, fresh flowers, plastic shine, dried, papery",
      }
    },
    {
      id: "pale_interior", name: "Pale Interior", role: "Supporting",
      scale: "20in", formula: "Side Sweep", price: "$155-$175", done: false,
      prompts: {
        "Hero": "editorial product photograph of a warm grey limewash plaster wall above a warm wood ledge, a handcrafted luxury faux botanical 20-inch wreath hung at center, wall visible above and below establishing scale, foliage-forward asymmetric side sweep composition, three open ivory silk peonies anchoring an extended sweep of silvery sage dusty miller from 8 to 12 o'clock, matte olive-leaf foliage fanning outward along the sweep, heavier matte slate-blue viburnum berry clusters massed at 9 to 11 o'clock, no blooms in the lower arc, exposed grapevine base readable throughout the lower half and right quadrant, velvet foliage with organic directional lean, wired stems holding natural curves, dimensional midground depth, soft north-facing window light, hung on a warm grey limewash plaster wall, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor editorial aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial product photograph of a calm neutral hallway with plaster walls, a small handcrafted luxury faux botanical 20-inch wreath hung on an interior door, full door frame visible establishing wreath scale, foliage-forward asymmetric side sweep with three ivory silk peonies at the upper arc, dusty miller and olive-leaf foliage sweeping from 8 to 12 o'clock, slate-blue viburnum berries clustered at 10 o'clock, bare grapevine throughout the lower arc, calm neutral hallway, soft window light from the left, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium interiors editorial --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical wreath, silvery sage dusty miller velvet leaf surface in focus, matte slate-blue viburnum berries nestled at the foliage edge, wired stems showing organic direction, dimensional material depth, soft diffused window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
      }
    },
    {
      id: "ledge", name: "The Ledge", role: "Supporting",
      scale: "48in Garland", formula: "Linear Directional", price: "$165-$185", done: false,
      prompts: {
        "Hero": "editorial product photograph of a handcrafted luxury faux botanical garland draped naturally across a painted wood mantel shelf, linear directional arrangement densest at center with three velvet magnolia buds and a layered cluster of silvery sage dusty miller, matte olive-leaf foliage, and dried pampas grass wisps, matte slate-blue viburnum berry sprigs tucked throughout at irregular intervals, garland tapering to loose dusty miller wisps and bare stems at both ends, left end slightly denser than right, natural bow at center from its own weight, organic side cascades over the mantel edge, dimensional layering, soft north-facing window light, grey plaster wall in background, a large droopy looped ivory linen ribbon bow with long flowing tails at the center drape point, tails trailing naturally over the surface edge, floral elements proportionate to garland length at natural craft scale, full garland visible within frame, 85mm medium format, medium-distance product photography, shallow focus on center cluster, premium home decor editorial catalog --ar 3:2 --v 7 --style raw --s 150 --no symmetry, centered mass, fresh flowers, wilting, vase, plastic shine, craft store, glitter, stiff placement, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial product photograph of a luxury faux botanical garland draped over a narrow oak console table, asymmetric directional composition densest at center left, silvery sage dusty miller and magnolia buds clustered at the drape peak, slate-blue viburnum sprigs graduating outward, both ends trailing naturally toward the floor, ceramic vessel and folded linen in the soft background, warm grey plaster wall, north window light, floral elements at natural craft scale, full form visible within frame, 85mm, medium-distance product photography, shallow depth, premium interiors editorial --ar 3:2 --v 7 --style raw --s 150 --no symmetry, fresh flowers, stiff arrangement, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical garland center cluster, velvet magnolia bud surrounded by silvery dusty miller, matte viburnum berries nestled at foliage base, layered stem structure visible beneath, soft directional light, macro botanical detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
      }
    },
    {
      id: "rings", name: "Still Rings", role: "Atmospheric Filler",
      scale: "8in x 2", formula: "Asymmetric Cluster", price: "$55-$65 / set", done: false,
      prompts: {
        "Hero": "editorial product photograph of two small handcrafted luxury faux botanical candle rings on a warm-toned wood console surface, each ring a grapevine base with an asymmetric cluster of one small ivory silk peony bud at 8 o'clock, three silvery sage dusty miller leaves fanning from 6 to 11 o'clock, three matte slate-blue viburnum berry stems graduating outward, exposed grapevine visible through the lower half of each ring, two rings positioned at slightly different angles with one overlapping the other for editorial depth, no candles in frame, soft north-facing window light, warm grey plaster wall behind, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, centered cluster, matching identical pair, fresh flowers, wilting, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial lifestyle photograph of two small luxury faux botanical candle rings encircling natural pillar candles on a wood console surface, asymmetric ivory bud and dusty miller clusters at 8 o'clock per ring, matte slate-blue berry sprigs at the crown, exposed grapevine in the lower arcs, candles unlit, warm grey plaster wall, north window light, soft editorial composition, premium home decor styling --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, glitter, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a small luxury faux botanical candle ring, ivory silk peony bud at 8 o'clock in focus, silvery dusty miller fanning beneath, matte viburnum berries at the edge, exposed grapevine base visible, layered materials, soft window light, macro product detail, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
      }
    },
    {
      id: "gateway", name: "First Light", role: "Gateway",
      scale: "14in", formula: "Classic Asymmetric", price: "$95-$115", done: false,
      prompts: {
        "Hero": "editorial product photograph of a warm grey limewash plaster wall above a warm wood ledge, a small handcrafted luxury faux botanical 14-inch wreath hung at center, substantial wall visible above and below clearly establishing the wreath's compact scale, a single open ivory silk peony anchoring the composition at 9 o'clock, silvery sage dusty miller curving from 7 to 12 o'clock in a quiet asymmetric crescent, five matte slate-blue viburnum berry sprigs graduating in size toward the crown, no florals in the lower arc, exposed grapevine base visible and deliberate from 1 to 6 o'clock, structured silk petal with natural fold memory and velvet foliage with organic directional lean, compact and restrained, soft north-facing window light, hung on a warm grey limewash plaster wall with warm wood ledge below, a large droopy looped ivory silk ribbon bow with long flowing tails at 6 o'clock, tails cascading naturally downward along the lower arc, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full wreath visible within frame, shallow depth of field on focal cluster only, premium home decor editorial catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, bouquet, centered, fresh flowers, wilting, vase, plastic shine, craft store, glitter, ribbon, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial product photograph of a small luxury faux botanical wreath resting against a wrapped gift box on a warm wood surface, single ivory silk peony at 9 o'clock, quiet dusty miller crescent sweeping the upper arc, slate-blue berry sprigs at the crown, exposed grapevine in the lower half, kraft paper wrapping soft in the background, north window light, warm grey plaster wall, minimal props, premium home decor gifting aesthetic --ar 5:4 --v 7 --style raw --s 150 --no symmetry, fresh flowers, plastic shine, craft store, busy background, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a small luxury faux botanical wreath, single open ivory silk peony in focus, silvery dusty miller velvet leaves fanning behind, matte slate berry sprigs at the edge, dimensional petal texture with natural fold lines, soft side window light, macro botanical, shallow depth of field --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
      }
    },
    {
      id: "accent", name: "Sage + Berry Picks", role: "Accent",
      scale: "6-stem bundle", formula: "Loose bundle", price: "$22-$32", done: false,
      prompts: {
        "Hero": "editorial product photograph of a small handcrafted luxury faux botanical stem bundle, three silvery sage dusty miller stems and three matte slate-blue viburnum berry stems and one matte olive-leaf branch loosely wrapped in natural kraft paper twine, arranged with organic looseness and directional lean, stems at slightly varying heights, resting against a warm grey plaster wall on a warm wood surface, north window light, matte surfaces throughout, finished with a large droopy looped ivory linen ribbon bow and long flowing tails at the stem wrap, florals and blooms proportionate to wreath diameter at natural craft scale, 85mm medium format, medium-distance product photography, full form visible within frame, shallow depth of field on focal cluster only, minimal editorial product styling, premium home decor catalog --ar 5:4 --v 7 --style raw --s 150 --no symmetry, arranged bouquet, fresh flowers, plastic shine, craft store, glitter, ribbon, bow, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Variant A": "editorial lifestyle photograph of a loose luxury faux botanical stem bundle styled in a narrow ceramic vase on a wood console, sage dusty miller and slate-blue viburnum berries and olive leaf branch in natural organic arrangement, warm grey plaster wall, north window light, single white ceramic vessel, minimal styling, premium interiors catalog --ar 5:4 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, symmetry, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
        "Detail Crop": "close-up editorial detail of a luxury faux botanical stem bundle, silvery dusty miller velvet leaf surface in focus, matte slate-blue viburnum berry cluster beside it, natural kraft twine wrapping visible at base, organic loose arrangement, soft directional light, macro botanical product detail --ar 4:5 --v 7 --style raw --s 150 --no fresh flowers, plastic shine, craft store, cartoon, text, watermark, oversized blooms, macro floral scale, disproportionate florals, enlarged petals, blown-up flowers",
      }
    },
  ]
};

// ==========================================================
// TOKENS
// ==========================================================
const T = {
  pageBg:    "#F5F2EB",
  cardBg:    "#FFFFFF",
  panelBg:   "#F0EDE6",
  inputBg:   "#F8F5EF",
  border:    "#E4DED4",
  borderMed: "#CEC8BE",
  text1:     "#2C2820",
  text2:     "#5C5650",
  text3:     "#9C9690",
  sage:      "#4A7A52",
  sageBg:    "#EBF3EB",
  sageBd:    "#B0CEB4",
  done:      "#3A6B4A",
  doneBg:    "#EBF5EE",
  doneBd:    "#A8CEB4",
  err:       "#8B3030",
  errBg:     "#FDF0F0",
  errBd:     "#E0B8B8",
};

// ==========================================================
// APP
// ==========================================================
export default function App() {
  const [collections, setCollections] = useState([QUIET_ACCORD]);
  const [activeIdx, setActiveIdx]     = useState(0);
  const [doneMap, setDoneMap]         = useState({ "quiet_accord|hero": true });
  const [tabMap, setTabMap]           = useState({});
  const [customMap, setCustomMap]     = useState({});
  const [copied, setCopied]           = useState({});
  const [orefUrl, setOrefUrl]         = useState("");
  const [orefOn, setOrefOn]           = useState(false);
  const [srefUrl, setSrefUrl]         = useState("");
  const [srefOn, setSrefOn]           = useState(false);
  const [srefWeight, setSrefWeight]   = useState(100);
  const [showExport, setShowExport]   = useState(false);
  const [exportCopied, setExportCopied] = useState(false);
  const [showIntent, setShowIntent]   = useState(false);
  const [intentForm, setIntentForm]   = useState({ name: "", season: "", brief: "", hero: "" });
  const [isGenerating, setIsGenerating] = useState(false);
  const [genStepIdx, setGenStepIdx]   = useState(0);
  const [genError, setGenError]       = useState("");
  const [storageReady, setStorageReady] = useState(false);
  const [apiKey, setApiKey]             = useState("");
  const [imageUrls, setImageUrls]       = useState({});
  const [hoveredImg, setHoveredImg]     = useState(null);
  const [expandedImg, setExpandedImg]   = useState(null);
  const [showImgInput, setShowImgInput] = useState({});
  const [imgInputVals, setImgInputVals] = useState({});

  // -- LOAD from storage on mount --------------------------
  useEffect(() => {
    const load = async () => {
      try {
        const savedColls = await window.storage.get("ec-collections");
        if (savedColls?.value) {
          try {
            const parsed = JSON.parse(savedColls.value);
            if (Array.isArray(parsed) && parsed.length > 0) {
              // Always ensure Quiet Accord is present as the baseline collection
              const hasQA = parsed.some(c => c.id === 'quiet_accord' || c.id === 'quiet_accord_full');
              const merged = hasQA ? parsed : [QUIET_ACCORD, ...parsed];
              setCollections(merged);
            }
          } catch(parseErr) {
            // Stored collections were malformed -- reset to default
            console.warn('Stored collections parse failed, resetting:', parseErr.message);
            setCollections([QUIET_ACCORD]);
            window.storage.set("ec-collections", JSON.stringify([QUIET_ACCORD])).catch(()=>{});
          }
        }
        const savedDone = await window.storage.get("ec-done");
        if (savedDone?.value) setDoneMap(JSON.parse(savedDone.value));
        const savedIdx = await window.storage.get("ec-active-idx");
        if (savedIdx?.value) setActiveIdx(JSON.parse(savedIdx.value));
        const savedImgs = await window.storage.get("ec-image-urls");
        if (savedImgs?.value) setImageUrls(JSON.parse(savedImgs.value));
      } catch {}
      setStorageReady(true);
    };
    load();
  }, []);

  // -- SAVE collections whenever they change ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-collections", JSON.stringify(collections)).catch(() => {});
  }, [collections, storageReady]);

  // -- SAVE done states whenever they change ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-done", JSON.stringify(doneMap)).catch(() => {});
  }, [doneMap, storageReady]);

  // -- SAVE active index whenever it changes ---------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-active-idx", JSON.stringify(activeIdx)).catch(() => {});
  }, [activeIdx, storageReady]);

  // -- SAVE image URLs whenever they change -----------------
  useEffect(() => {
    if (!storageReady) return;
    window.storage.set("ec-image-urls", JSON.stringify(imageUrls)).catch(() => {});
  }, [imageUrls, storageReady]);

  // -- STEP animation during generation --------------------
  useEffect(() => {
    if (!isGenerating) return;
    setGenStepIdx(0);
    const iv = setInterval(() => setGenStepIdx(i => (i + 1) % GEN_STEPS.length), 1800);
    return () => clearInterval(iv);
  }, [isGenerating]);

  const coll = collections[Math.min(activeIdx, collections.length - 1)];

  const fp = useCallback((base) => {
    let out = base;
    if (orefOn && orefUrl.trim())
      out = out.replace("--ar", `--oref ${orefUrl.trim()} --ow 75 --ar`);
    if (srefOn && srefUrl.trim())
      out = out.replace("--ar", `--sref ${srefUrl.trim()} --sw ${srefWeight} --ar`);
    return out;
  }, [orefOn, orefUrl, srefOn, srefUrl, srefWeight]);

  const k = (prodId, sfx = "") => `${coll.id}|${prodId}${sfx ? "|" + sfx : ""}`;
  const isDone = id => !!doneMap[k(id)];
  const toggleDone = id => setDoneMap(p => ({ ...p, [k(id)]: !p[k(id)] }));
  const getTab = prod => tabMap[k(prod.id)] || Object.keys(prod.prompts)[0];
  const setTab = (id, t) => setTabMap(p => ({ ...p, [k(id)]: t }));
  const getCS = id => customMap[k(id)] || {};
  const updCS = (id, patch) => setCustomMap(p => ({ ...p, [k(id)]: { ...p[k(id)], ...patch } }));

  const doCopy = async (text, ck) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(p => ({ ...p, [ck]: true }));
      setTimeout(() => setCopied(p => ({ ...p, [ck]: false })), 2000);
    } catch {}
  };

  const doneCount = coll.products.filter(p => isDone(p.id)).length;

  const handleGenerate = async () => {
    if (!intentForm.brief.trim()) return;
    setIsGenerating(true); setGenError("");
    const msg = [
      intentForm.name && `Collection working name: ${intentForm.name}`,
      intentForm.season && `Season and timing: ${intentForm.season}`,
      `Collection intent: ${intentForm.brief}`,
      intentForm.hero && `Hero floral(s): ${intentForm.hero}`,
    ].filter(Boolean).join("\n");
    try {
      const headers = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
      };
      if (apiKey.trim()) headers["x-api-key"] = apiKey.trim();

      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 8000,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: msg }]
        }),
      });
      const data = await res.json();

      // Surface API-level errors clearly
      if (data.error) throw new Error(`API error: ${data.error.type} -- ${data.error.message}`);
      if (!data.content?.[0]?.text) throw new Error(`Unexpected response shape: ${JSON.stringify(data).slice(0, 200)}`);

      const raw = data.content[0].text.trim();
      const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
      if (s === -1 || e === -1) throw new Error(`No JSON found in response. Got: ${raw.slice(0, 200)}`);

      const parsed = JSON.parse(raw.slice(s, e + 1));
      if (!Array.isArray(parsed.products) || !parsed.products.length) throw new Error("Collection parsed but has no products");

      const newColl = { ...parsed, id: parsed.id || `coll_${Date.now()}` };
      setCollections(prev => [...prev, newColl]);
      setActiveIdx(collections.length);
      setShowIntent(false);
      setIntentForm({ name: "", season: "", brief: "", hero: "" });
    } catch (err) {
      setGenError(err.message || "Unknown error -- open browser console for details.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCustomVariant = async (prod, base) => {
    const cs = getCS(prod.id);
    if (!cs.input?.trim() || cs.loading) return;
    updCS(prod.id, { loading: true, result: null });
    try {
      const headers = {
        "Content-Type": "application/json",
        "anthropic-version": "2023-06-01",
      };
      if (apiKey.trim()) headers["x-api-key"] = apiKey.trim();
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: "claude-sonnet-4-6", max_tokens: 1000,
          system: "You are a luxury faux botanical render prompt specialist for Evercrafted. Modify Midjourney render prompts per user instructions. Preserve: asymmetric clock-position composition, matte silk/velvet faux materials, editorial product photography direction, exposed grapevine negative space, all --parameters. Return ONLY the modified prompt -- no preamble, no markdown.",
          messages: [{ role: "user", content: `Base prompt:\n${base}\n\nModification: ${cs.input.trim()}` }],
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error.message);
      updCS(prod.id, { loading: false, result: data.content?.[0]?.text?.trim() || "No result." });
    } catch (err) {
      updCS(prod.id, { loading: false, result: `Error: ${err.message}` });
    }
  };

  const buildExportText = () => {
    const divider = "=".repeat(64);
    const lines = coll.products.map(p => {
      const hdr = `${divider}\n${p.name.toUpperCase()} . ${p.role}\n${p.scale} . ${p.formula} . ${p.price}\n${divider}`;
      const pts = Object.entries(p.prompts).map(([l, t]) => `-- ${l} --\n${fp(t)}`).join("\n\n");
      return `${hdr}\n\n${pts}`;
    }).join("\n\n\n");
    return `${coll.collectionName.toUpperCase()} -- RENDER PROMPTS\nEvercrafted Studio . ${coll.season}\n\n${lines}`;
  };

  const handleExportCopy = async () => {
    try {
      await navigator.clipboard.writeText(buildExportText());
      setExportCopied(true);
      setTimeout(() => setExportCopied(false), 2500);
    } catch {}
  };

  const removeCollection = idx => {
    const coll = collections[idx];
    if (collections.length <= 1) return;
    if (coll.id === 'quiet_accord' || coll.id === 'quiet_accord_full') return; // QA is permanent
    setCollections(p => p.filter((_, i) => i !== idx));
    setActiveIdx(p => p >= idx ? Math.max(0, p - 1) : p);
  };

  // --- RENDER -------------------------------------------
  return (
    <div style={{ background: T.pageBg, minHeight: "100vh", color: T.text1, fontFamily: "system-ui, -apple-system, sans-serif" }}>

      {/* -- API KEY BAR -- */}
      <div style={{ background: apiKey.trim() ? "#F0F7F0" : "#FFF8F0", borderBottom: `1px solid ${apiKey.trim() ? T.sageBd : "#E8C88A"}`, padding: "10px 24px", display: "flex", alignItems: "center", gap: "10px" }}>
        <div style={{ flexShrink: 0 }}>
          <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "2px" }}>Anthropic API Key</div>
          <div style={{ fontSize: "9px", color: apiKey.trim() ? T.done : "#8B6020" }}>{apiKey.trim() ? "  Connected" : "  Required for collection generation"}</div>
        </div>
        <input
          type="password"
          value={apiKey}
          onChange={e => setApiKey(e.target.value)}
          placeholder="Paste your Anthropic API key here -- sk-ant-api03-..."
          style={{ flex: 1, background: "#fff", border: `1px solid ${apiKey.trim() ? T.sageBd : "#E0B870"}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "7px 12px", outline: "none", fontFamily: "monospace" }}
        />
      </div>

      {/* -- HEADER -- */}
      <div style={{ background: T.cardBg, borderBottom: `1px solid ${T.border}`, padding: "20px 24px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div>
            <div style={{ fontSize: "10px", letterSpacing: "0.16em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>
              Evercrafted . Collection Render Studio
            </div>
            <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.08em", color: T.text1 }}>
              {coll.collectionName.toUpperCase()}
            </div>
            <div style={{ fontSize: "11px", color: T.text3, marginTop: "3px", display: "flex", alignItems: "center", gap: "8px" }}>
              {coll.season} . {coll.atmosphere} . {coll.priceRange}
              {storageReady && <span style={{ fontSize: "9px", color: T.sageBd, letterSpacing: "0.08em" }}>  AUTO-SAVED</span>}
            </div>
            {coll.palette && (
              <div style={{ display: "flex", gap: "5px", marginTop: "8px", flexWrap: "wrap" }}>
                {coll.palette.map(c => (
                  <span key={c} style={{ fontSize: "10px", color: T.text2, background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "3px", padding: "2px 8px" }}>{c}</span>
                ))}
              </div>
            )}
            {coll.sightlineStory && (
              <div style={{ marginTop: "10px", padding: "10px 14px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px", maxWidth: "540px" }}>
                <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Sightline Story</div>
                <div style={{ fontSize: "11px", color: T.text2, lineHeight: "1.6", fontStyle: "italic" }}>{coll.sightlineStory}</div>
              </div>
            )}
            {(coll.floralHierarchy || coll.ribbonJourney || coll.colorMovement) && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginTop: "8px", maxWidth: "540px" }}>
                {coll.floralHierarchy && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Floral Hierarchy</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      <span style={{ color: T.text3 }}>T1 </span>{coll.floralHierarchy.tier1Signature}<br/>
                      <span style={{ color: T.text3 }}>T2 </span>{Array.isArray(coll.floralHierarchy.tier2Supporting) ? coll.floralHierarchy.tier2Supporting.join(" . ") : coll.floralHierarchy.tier2Supporting}<br/>
                      <span style={{ color: T.text3 }}>T3 </span>{Array.isArray(coll.floralHierarchy.tier3Discovery) ? coll.floralHierarchy.tier3Discovery.join(" . ") : coll.floralHierarchy.tier3Discovery}
                    </div>
                  </div>
                )}
                {coll.ribbonJourney && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Ribbon Journey</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {Object.entries(coll.ribbonJourney).map(([layer, ribbons]) => (
                        <div key={layer}><span style={{ color: T.text3 }}>{layer} </span>{typeof ribbons === "object" ? ribbons.statement || Object.values(ribbons)[0] : ribbons}</div>
                      ))}
                    </div>
                  </div>
                )}
                {coll.colorMovement && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Color Movement</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {Object.entries(coll.colorMovement).map(([k, v]) => (
                        <div key={k}><span style={{ color: T.text3 }}>{k.replace(/([A-Z])/g, ' $1').toLowerCase()} </span>{v}</div>
                      ))}
                    </div>
                  </div>
                )}
                {coll.greenerOnlyProducts?.length > 0 && (
                  <div style={{ padding: "10px 12px", background: T.panelBg, border: `1px solid ${T.border}`, borderRadius: "7px" }}>
                    <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "6px" }}>Greenery Only</div>
                    <div style={{ fontSize: "10px", color: T.text2, lineHeight: "1.7" }}>
                      {coll.greenerOnlyProducts.join(" . ")}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div style={{ display: "flex", gap: "8px", marginTop: "2px" }}>
            <button onClick={() => { setShowExport(true); setExportCopied(false); }} style={Btn(T.cardBg, T.border, T.text2)}>  Export</button>
            <button onClick={() => { setShowIntent(true); setGenError(""); }} style={Btn(T.sageBg, T.sageBd, T.done, true)}>+ New Collection</button>
          </div>
        </div>

        {/* Collection tabs */}
        <div style={{ display: "flex", marginTop: "16px", overflowX: "auto", gap: "0" }}>
          {collections.map((c, i) => (
            <div key={c.id} onClick={() => setActiveIdx(i)}
              style={{ display: "flex", alignItems: "center", gap: "6px", padding: "8px 16px", cursor: "pointer", fontSize: "12px", fontWeight: i === activeIdx ? "500" : "400", color: i === activeIdx ? T.text1 : T.text3, borderBottom: i === activeIdx ? `2px solid ${T.sage}` : "2px solid transparent", whiteSpace: "nowrap", transition: "color 0.15s" }}>
              {c.collectionName}
              {collections.length > 1 && c.id !== 'quiet_accord' && c.id !== 'quiet_accord_full' && (
                <span onClick={e => { e.stopPropagation(); removeCollection(i); }} style={{ color: T.text3, fontSize: "14px", lineHeight: 1, padding: "0 2px", cursor: "pointer" }}>x</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* -- REFERENCE PANEL -- */}
      <div style={{ background: T.cardBg, borderBottom: `1px solid ${T.border}`, padding: "10px 24px", display: "flex", flexDirection: "column", gap: "7px" }}>

        {/* --oref row */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <button onClick={() => setOrefOn(o => !o)} style={{ ...Btn(orefOn ? T.sageBg : T.panelBg, orefOn ? T.sageBd : T.border, orefOn ? T.done : T.text3), fontSize: "11px", whiteSpace: "nowrap", minWidth: "96px" }}>
            {orefOn ? "  --oref on" : "  --oref off"}
          </button>
          <input value={orefUrl} onChange={e => setOrefUrl(e.target.value)}
            placeholder="Paste your hero render URL -- locks composition and colour style across all prompts (--ow 75)"
            style={{ flex: 1, background: T.inputBg, border: `1px solid ${orefUrl && orefOn ? T.sageBd : T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "6px 10px", outline: "none", fontFamily: "monospace" }}
          />
          <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>style lock</span>
        </div>

        {/* --sref row */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
          <button onClick={() => setSrefOn(o => !o)} style={{ ...Btn(srefOn ? "#FFF3E8" : T.panelBg, srefOn ? "#E0B888" : T.border, srefOn ? "#8B5E20" : T.text3), fontSize: "11px", whiteSpace: "nowrap", minWidth: "96px" }}>
            {srefOn ? "  --sref on" : "  --sref off"}
          </button>
          <input value={srefUrl} onChange={e => setSrefUrl(e.target.value)}
            placeholder="Paste scale reference image URL -- shows MJ correct floral proportions and wreath scale (--sref)"
            style={{ flex: 1, background: T.inputBg, border: `1px solid ${srefUrl && srefOn ? "#E0B888" : T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "6px 10px", outline: "none", fontFamily: "monospace" }}
          />
          <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
            <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>--sw</span>
            <input
              type="number" min="50" max="1000" step="50"
              value={srefWeight}
              onChange={e => setSrefWeight(Number(e.target.value))}
              style={{ width: "58px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "11px", padding: "5px 8px", outline: "none", textAlign: "center" }}
            />
            <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>scale ref</span>
          </div>
        </div>

      </div>

      {/* -- PROGRESS -- */}
      <div style={{ padding: "12px 24px 0", display: "flex", alignItems: "center", gap: "10px" }}>
        <span style={{ fontSize: "10px", color: T.text3, whiteSpace: "nowrap" }}>{doneCount}/{coll.products.length} rendered</span>
        <div style={{ display: "flex", gap: "3px", flex: 1 }}>
          {coll.products.map(p => (
            <div key={p.id} style={{ flex: 1, height: "3px", borderRadius: "2px", background: isDone(p.id) ? (RS[p.role]?.badge || T.sage) : T.border, transition: "background 0.3s" }} />
          ))}
        </div>
        <span style={{ fontSize: "10px", color: T.text3 }}>{coll.priceRange}</span>
      </div>

      {/* -- PRODUCT CARDS -- */}
      <div style={{ padding: "14px 24px 40px", display: "flex", flexDirection: "column", gap: "10px" }}>
        {coll.products.map(prod => {
          const rs = RS[prod.role] || RS["Accent"];
          const done = isDone(prod.id);
          const tab = getTab(prod);
          const base = prod.prompts[tab] || "";
          const display = fp(base);
          const ck = k(prod.id, tab);
          const cs = getCS(prod.id);
          const imgKey = k(prod.id);
          const imgData = imageUrls[imgKey] || {};
          const sketchUrl = imgData.sketch || "";
          const colorUrl  = imgData.color  || "";
          const displayImg = sketchUrl || colorUrl;
          const isImgHovered = hoveredImg === imgKey;
          const showingImgInput = showImgInput[imgKey];

          return (
            <div key={prod.id} style={{ background: T.cardBg, border: `1px solid ${done ? rs.border : T.border}`, borderRadius: "10px", overflow: "hidden", boxShadow: "0 1px 4px rgba(0,0,0,0.04)", transition: "border-color 0.3s" }}>

              {/* -- SKETCH-TO-COLOR IMAGE REVEAL -- */}
              {displayImg && (
                <div
                  style={{ position: "relative", cursor: "pointer", lineHeight: 0, overflow: "hidden", background: sketchUrl ? "#F5F1EB" : T.cardBg }}
                  onMouseEnter={() => setHoveredImg(imgKey)}
                  onMouseLeave={() => setHoveredImg(null)}
                  onClick={() => setExpandedImg(colorUrl || sketchUrl)}
                >
                  {/* Sketch layer -- shows by default */}
                  {sketchUrl && (
                    <img src={sketchUrl} alt={`${prod.name} sketch`}
                      style={{
                        width: "100%", display: "block", maxHeight: "240px",
                        objectFit: "cover", objectPosition: "center top",
                        opacity: isImgHovered && colorUrl ? 0 : 1,
                        transition: "opacity 0.85s cubic-bezier(0.4,0,0.2,1)",
                        position: sketchUrl && colorUrl ? "absolute" : "relative",
                        top: 0, left: 0,
                      }}
                    />
                  )}
                  {/* Color layer -- reveals on hover */}
                  {colorUrl && (
                    <img src={colorUrl} alt={`${prod.name} color`}
                      style={{
                        width: "100%", display: "block", maxHeight: "240px",
                        objectFit: "cover", objectPosition: "center top",
                        opacity: isImgHovered || !sketchUrl ? 1 : 0,
                        transition: "opacity 0.85s cubic-bezier(0.4,0,0.2,1)",
                        filter: !sketchUrl && !isImgHovered
                          ? "grayscale(100%) contrast(1.9) brightness(1.12) sepia(10%)"
                          : "none",
                      }}
                    />
                  )}
                  {/* Hover hint -- sketch only state */}
                  {!isImgHovered && colorUrl && (
                    <div style={{
                      position: "absolute", inset: 0, pointerEvents: "none",
                      background: "linear-gradient(to top, rgba(245,241,235,0.4) 0%, transparent 60%)",
                      display: "flex", alignItems: "flex-end", justifyContent: "center", paddingBottom: "10px"
                    }}>
                      <span style={{ fontSize: "9px", letterSpacing: "0.2em", color: "rgba(44,40,32,0.45)", textTransform: "uppercase", fontWeight: "500" }}>
                        hover to reveal color
                      </span>
                    </div>
                  )}
                  {/* Click hint on hover */}
                  {isImgHovered && (
                    <div style={{
                      position: "absolute", top: "10px", right: "10px",
                      background: "rgba(255,255,255,0.92)", borderRadius: "4px",
                      padding: "3px 10px", fontSize: "9px", letterSpacing: "0.1em",
                      color: T.text2, textTransform: "uppercase", fontWeight: "500",
                      boxShadow: "0 1px 4px rgba(0,0,0,0.08)"
                    }}>
                        expand
                    </div>
                  )}
                </div>
              )}

              {/* Card header */}
              <div style={{ padding: "13px 16px 10px", display: "flex", justifyContent: "space-between", alignItems: "flex-start", background: done ? rs.bg : T.cardBg, transition: "background 0.3s" }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "7px", flexWrap: "wrap", marginBottom: "4px" }}>
                    <span style={{ background: rs.badge, color: "#fff", fontSize: "9px", fontWeight: "600", padding: "2px 8px", borderRadius: "3px", letterSpacing: "0.06em", textTransform: "uppercase" }}>{prod.role}</span>
                    {done && <span style={{ fontSize: "10px", color: T.done, fontWeight: "500" }}>  Rendered</span>}
                    {prod.note && <span style={{ fontSize: "10px", color: T.sage }}>{prod.note}</span>}
                  </div>
                  <div style={{ fontSize: "14px", fontWeight: "500", color: T.text1 }}>{prod.name}</div>
                  <div style={{ fontSize: "10px", color: T.text3, marginTop: "2px" }}>{prod.scale} . {prod.formula} . {prod.price}</div>
                </div>
                <button onClick={() => toggleDone(prod.id)} style={{ ...Btn(done ? T.doneBg : T.panelBg, done ? T.doneBd : T.border, done ? T.done : T.text2), fontSize: "11px", flexShrink: 0, marginLeft: "10px" }}>
                  {done ? "  Done" : "Mark Done"}
                </button>
              </div>

              {/* Tabs */}
              <div style={{ display: "flex", borderTop: `1px solid ${T.border}`, borderBottom: `1px solid ${T.border}` }}>
                {Object.keys(prod.prompts).map(t => (
                  <button key={t} onClick={() => setTab(prod.id, t)} style={{
                    flex: 1, padding: "7px 4px", background: "transparent", border: "none",
                    borderBottom: t === tab ? `2px solid ${rs.badge}` : "2px solid transparent",
                    color: t === tab ? T.text1 : T.text3, fontSize: "10px", cursor: "pointer",
                    fontWeight: t === tab ? "500" : "400", transition: "color 0.15s",
                  }}>{t}</button>
                ))}
              </div>

              {/* Prompt */}
              <div style={{ padding: "11px 16px 0" }}>
                <textarea readOnly value={display} onClick={e => e.target.select()}
                  style={{ width: "100%", height: "100px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text2, fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box", cursor: "text" }}
                />
                <button onClick={() => doCopy(display, ck)} style={{ ...Btn(copied[ck] ? T.doneBg : T.panelBg, copied[ck] ? T.doneBd : T.border, copied[ck] ? T.done : T.text1, copied[ck]), marginTop: "6px", width: "100%", fontSize: "11px", padding: "8px" }}>
                  {copied[ck] ? "  Copied to clipboard" : "Copy Prompt"}
                </button>
              </div>

              {/* -- IMAGE URL INPUTS -- */}
              <div style={{ padding: "0 16px 10px" }}>
                <button
                  onClick={() => setShowImgInput(p => ({ ...p, [imgKey]: !p[imgKey] }))}
                  style={{ background: "transparent", border: "none", color: T.text3, fontSize: "10px", cursor: "pointer", padding: "0", display: "flex", alignItems: "center", gap: "5px" }}
                >
                  <span style={{ display: "inline-block", transition: "transform 0.2s", transform: showingImgInput ? "rotate(90deg)" : "none" }}> </span>
                  {displayImg ? "Update render images" : "Add render images"}
                </button>
                {showingImgInput && (
                  <div style={{ marginTop: "8px", display: "flex", flexDirection: "column", gap: "6px" }}>
                    <div>
                      <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Sketch / Illustration URL</div>
                      <div style={{ display: "flex", gap: "6px" }}>
                        <input
                          value={imgInputVals[`${imgKey}-sketch`] || sketchUrl}
                          onChange={e => setImgInputVals(p => ({ ...p, [`${imgKey}-sketch`]: e.target.value }))}
                          placeholder="Paste MJ sketch render URL..."
                          style={{ flex: 1, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10px", padding: "5px 8px", outline: "none", fontFamily: "monospace" }}
                        />
                        <button
                          onClick={() => {
                            const val = imgInputVals[`${imgKey}-sketch`] || "";
                            setImageUrls(p => ({ ...p, [imgKey]: { ...(p[imgKey] || {}), sketch: val } }));
                          }}
                          style={{ ...Btn(T.sageBg, T.sageBd, T.done), fontSize: "10px", padding: "5px 10px", flexShrink: 0 }}
                        >Set</button>
                      </div>
                    </div>
                    <div>
                      <div style={{ fontSize: "9px", letterSpacing: "0.1em", color: T.text3, textTransform: "uppercase", marginBottom: "4px" }}>Color Render URL</div>
                      <div style={{ display: "flex", gap: "6px" }}>
                        <input
                          value={imgInputVals[`${imgKey}-color`] || colorUrl}
                          onChange={e => setImgInputVals(p => ({ ...p, [`${imgKey}-color`]: e.target.value }))}
                          placeholder="Paste MJ color render URL..."
                          style={{ flex: 1, background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10px", padding: "5px 8px", outline: "none", fontFamily: "monospace" }}
                        />
                        <button
                          onClick={() => {
                            const val = imgInputVals[`${imgKey}-color`] || "";
                            setImageUrls(p => ({ ...p, [imgKey]: { ...(p[imgKey] || {}), color: val } }));
                          }}
                          style={{ ...Btn(T.sageBg, T.sageBd, T.done), fontSize: "10px", padding: "5px 10px", flexShrink: 0 }}
                        >Set</button>
                      </div>
                    </div>
                    {displayImg && (
                      <button
                        onClick={() => { setImageUrls(p => ({ ...p, [imgKey]: {} })); setImgInputVals(p => ({ ...p, [`${imgKey}-sketch`]: "", [`${imgKey}-color`]: "" })); }}
                        style={{ ...Btn(T.panelBg, T.border, T.text3), fontSize: "9px", padding: "4px 10px", alignSelf: "flex-start" }}
                      >Clear images</button>
                    )}
                  </div>
                )}
              </div>

              {/* Custom variant */}
              <div style={{ padding: "8px 16px 14px" }}>
                <button onClick={() => updCS(prod.id, { open: !cs.open })} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "10px", cursor: "pointer", padding: "0", display: "flex", alignItems: "center", gap: "5px" }}>
                  <span style={{ display: "inline-block", transition: "transform 0.2s", transform: cs.open ? "rotate(90deg)" : "none" }}> </span>
                  Generate Custom Variant via Claude
                </button>
                {cs.open && (
                  <div style={{ marginTop: "8px" }}>
                    <textarea value={cs.input || ""} onChange={e => updCS(prod.id, { input: e.target.value })}
                      placeholder={`e.g. "adapt for spring with blush ranunculus" . "moody evening light" . "burgundy and dusty rose"`}
                      style={{ width: "100%", height: "50px", background: T.inputBg, border: `1px solid ${T.border}`, borderRadius: "6px", color: T.text1, fontSize: "10.5px", lineHeight: "1.5", padding: "8px 10px", resize: "none", fontFamily: "system-ui, sans-serif", boxSizing: "border-box", outline: "none" }}
                    />
                    <button onClick={() => handleCustomVariant(prod, base)} disabled={cs.loading || !cs.input?.trim()}
                      style={{ ...Btn(T.panelBg, T.borderMed, T.text2), marginTop: "5px", width: "100%", fontSize: "11px", padding: "7px", cursor: cs.loading ? "wait" : "pointer", opacity: cs.loading || !cs.input?.trim() ? 0.5 : 1 }}>
                      {cs.loading ? "Generating..." : "Generate with Claude ->"}
                    </button>
                    {cs.result && (
                      <div style={{ marginTop: "7px" }}>
                        <textarea readOnly value={cs.result} onClick={e => e.target.select()}
                          style={{ width: "100%", height: "100px", background: T.doneBg, border: `1px solid ${T.doneBd}`, borderRadius: "6px", color: T.done, fontSize: "10.5px", lineHeight: "1.65", padding: "9px 11px", resize: "none", fontFamily: "monospace", boxSizing: "border-box" }}
                        />
                        <button onClick={() => doCopy(cs.result, k(prod.id, "custom"))}
                          style={{ ...Btn(T.doneBg, T.doneBd, T.done), marginTop: "4px", width: "100%", fontSize: "11px", padding: "6px" }}>
                          {copied[k(prod.id, "custom")] ? "  Copied" : "Copy Custom Variant"}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer */}
      <div style={{ borderTop: `1px solid ${T.border}`, background: T.cardBg, padding: "12px 24px", display: "flex", justifyContent: "space-between" }}>
        <span style={{ fontSize: "10px", color: T.text3, letterSpacing: "0.06em" }}>EVERCRAFTED . COLLECTION RENDER STUDIO</span>
        <span style={{ fontSize: "10px", color: T.text3 }}>{doneCount} of {coll.products.length} complete</span>
      </div>

      {/* ============================================
          IMAGE LIGHTBOX
      ============================================ */}
      {expandedImg && (
        <div
          onClick={() => setExpandedImg(null)}
          style={{ position: "fixed", inset: 0, background: "rgba(20,16,12,0.92)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 200, padding: "20px", cursor: "zoom-out" }}
        >
          <div style={{ position: "relative", maxWidth: "92vw", maxHeight: "90vh" }}>
            <img
              src={expandedImg}
              style={{ maxWidth: "100%", maxHeight: "90vh", objectFit: "contain", borderRadius: "8px", boxShadow: "0 24px 80px rgba(0,0,0,0.6)" }}
              onClick={e => e.stopPropagation()}
            />
            <button
              onClick={() => setExpandedImg(null)}
              style={{ position: "absolute", top: "-14px", right: "-14px", background: "rgba(255,255,255,0.95)", border: "none", borderRadius: "50%", width: "32px", height: "32px", fontSize: "16px", cursor: "pointer", color: "#2C2820", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 2px 8px rgba(0,0,0,0.3)" }}
            >x</button>
          </div>
        </div>
      )}

      {/* ============================================
          EXPORT MODAL
      ============================================ */}
      {showExport && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(44,40,32,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: "20px" }}>
          <div style={{ background: T.cardBg, border: `1px solid ${T.border}`, borderRadius: "14px", width: "100%", maxWidth: "640px", maxHeight: "80vh", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: "0 8px 40px rgba(0,0,0,0.12)" }}>

            {/* Modal header */}
            <div style={{ padding: "18px 22px", borderBottom: `1px solid ${T.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", flexShrink: 0 }}>
              <div>
                <div style={{ fontSize: "10px", letterSpacing: "0.12em", color: T.text3, textTransform: "uppercase", marginBottom: "3px" }}>Export Prompts</div>
                <div style={{ fontSize: "15px", fontWeight: "500", color: T.text1 }}>{coll.collectionName} -- {coll.products.length} products . {Object.values(coll.products[0]?.prompts || {}).length * coll.products.length} prompts</div>
              </div>
              <button onClick={() => setShowExport(false)} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "20px", cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>x</button>
            </div>

            {/* Prompt textarea */}
            <textarea
              readOnly
              value={buildExportText()}
              onClick={e => e.target.select()}
              style={{ flex: 1, background: T.inputBg, border: "none", borderBottom: `1px solid ${T.border}`, color: T.text2, fontSize: "10.5px", lineHeight: "1.7", padding: "16px 20px", resize: "none", fontFamily: "monospace", outline: "none", overflowY: "auto" }}
            />

            {/* Footer actions */}
            <div style={{ padding: "14px 22px", display: "flex", alignItems: "center", gap: "10px", flexShrink: 0 }}>
              <div style={{ fontSize: "11px", color: T.text3, flex: 1 }}>
                Click the text area to select all . or use the copy button
              </div>
              <button onClick={() => setShowExport(false)} style={{ ...Btn(T.panelBg, T.border, T.text2), padding: "8px 18px", fontSize: "12px" }}>
                Close
              </button>
              <button onClick={handleExportCopy} style={{ ...Btn(exportCopied ? T.doneBg : T.sageBg, exportCopied ? T.doneBd : T.sageBd, exportCopied ? T.done : T.done, true), padding: "8px 22px", fontSize: "12px" }}>
                {exportCopied ? "  Copied" : "Copy All Prompts"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================
          INTENT OVERLAY
      ============================================ */}
      {showIntent && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(44,40,32,0.5)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100, padding: "20px" }}>
          <div style={{ background: T.cardBg, border: `1px solid ${T.border}`, borderRadius: "14px", width: "100%", maxWidth: "560px", overflow: "hidden", boxShadow: "0 8px 40px rgba(0,0,0,0.12)" }}>

            {isGenerating ? (
              <div style={{ padding: "48px 40px", textAlign: "center" }}>
                <div style={{ fontSize: "10px", letterSpacing: "0.16em", color: T.text3, textTransform: "uppercase", marginBottom: "20px" }}>Evercrafted . Building Collection</div>
                <div style={{ fontSize: "22px", fontWeight: "400", letterSpacing: "0.08em", color: T.text1, marginBottom: "6px" }}>
                  {intentForm.name ? intentForm.name.toUpperCase() : "NEW COLLECTION"}
                </div>
                <div style={{ fontSize: "11px", color: T.text3, marginBottom: "32px" }}>{intentForm.season || "Seasonal collection"}</div>

                <div style={{ display: "flex", flexDirection: "column", gap: "10px", maxWidth: "360px", margin: "0 auto 32px" }}>
                  {GEN_STEPS.map((step, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: "10px", opacity: i <= genStepIdx ? 1 : 0.25, transition: "opacity 0.4s" }}>
                      <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: i === genStepIdx ? T.sage : i < genStepIdx ? T.sageBd : T.border, flexShrink: 0, transition: "background 0.4s" }} />
                      <span style={{ fontSize: "12px", color: i === genStepIdx ? T.text1 : i < genStepIdx ? T.sage : T.text3, textAlign: "left" }}>{step}</span>
                    </div>
                  ))}
                </div>

                <div style={{ height: "2px", background: T.border, borderRadius: "1px", overflow: "hidden", maxWidth: "200px", margin: "0 auto" }}>
                  <div style={{ height: "100%", background: T.sage, borderRadius: "1px", animation: "pb 1.8s ease-in-out infinite" }} />
                </div>
                <style>{`@keyframes pb { 0%{width:0%} 50%{width:80%} 100%{width:100%} }`}</style>

                {genError && (
                  <div style={{ marginTop: "20px", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>
                    {genError}
                    <button onClick={() => setIsGenerating(false)} style={{ ...Btn("#FDF0F0", "#E0B8B8", "#8B3030"), marginTop: "10px", width: "100%", fontSize: "11px" }}>Try Again</button>
                  </div>
                )}
              </div>
            ) : (
              <div>
                <div style={{ padding: "18px 24px 14px", borderBottom: `1px solid ${T.border}`, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontSize: "10px", letterSpacing: "0.12em", color: T.text3, textTransform: "uppercase", marginBottom: "3px" }}>Evercrafted</div>
                    <div style={{ fontSize: "16px", fontWeight: "500", color: T.text1 }}>New Collection</div>
                  </div>
                  <button onClick={() => { setShowIntent(false); setGenError(""); }} style={{ background: "transparent", border: "none", color: T.text3, fontSize: "20px", cursor: "pointer", lineHeight: 1, padding: "0 4px" }}>x</button>
                </div>

                {/* Mode tabs */}
                <div style={{ display: "flex", borderBottom: `1px solid ${T.border}` }}>
                  {["Import JSON", "Generate via Claude"].map(tab => (
                    <button key={tab} onClick={() => setIntentForm(p => ({ ...p, _tab: tab }))}
                      style={{ flex: 1, padding: "10px 4px", background: "transparent", border: "none",
                        borderBottom: (intentForm._tab || "Import JSON") === tab ? `2px solid ${T.sage}` : "2px solid transparent",
                        color: (intentForm._tab || "Import JSON") === tab ? T.text1 : T.text3,
                        fontSize: "11px", cursor: "pointer",
                        fontWeight: (intentForm._tab || "Import JSON") === tab ? "500" : "400" }}>
                      {tab}
                    </button>
                  ))}
                </div>

                <div style={{ padding: "18px 24px" }}>
                  {(intentForm._tab || "Import JSON") === "Import JSON" ? (
                    <div>
                      <div style={{ fontSize: "11px", color: T.text2, marginBottom: "12px", lineHeight: "1.7" }}>
                        Ask Claude in the chat to generate a collection for you, then paste the JSON below.<br/>
                        <span style={{ color: T.text3, fontSize: "10px" }}>  Works on mobile . no API key needed</span>
                      </div>
                      <label style={Lbl}>Paste collection JSON</label>
                      <textarea
                        value={intentForm._json || ""}
                        onChange={e => setIntentForm(p => ({ ...p, _json: e.target.value }))}
                        placeholder={'{ "collectionName": "...", "products": [...] }'}
                        style={{ ...Inp(T), height: "150px", resize: "none", fontFamily: "monospace", fontSize: "10px" }}
                      />
                      {genError && (
                        <div style={{ margin: "10px 0 0", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>{genError}</div>
                      )}
                      <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
                        <button onClick={() => { setShowIntent(false); setGenError(""); }} style={{ ...Btn(T.panelBg, T.border, T.text2), flex: "0 0 auto", padding: "10px 18px", fontSize: "12px" }}>Cancel</button>
                        <button
                          onClick={() => {
                            try {
                              const raw = (intentForm._json || "").trim();
                              const s = raw.indexOf("{"), e = raw.lastIndexOf("}");
                              if (s === -1) throw new Error("No JSON found -- copy the full block from Claude");
                              const parsed = JSON.parse(raw.slice(s, e + 1));
                              if (!Array.isArray(parsed.products) || !parsed.products.length) throw new Error("Parsed OK but no products array found");
                              const newColl = { ...parsed, id: parsed.id || `coll_${Date.now()}` };
                              setCollections(prev => [...prev, newColl]);
                              setActiveIdx(collections.length);
                              setShowIntent(false);
                              setIntentForm({ name: "", season: "", brief: "", hero: "" });
                              setGenError("");
                            } catch(err) { setGenError(err.message); }
                          }}
                          disabled={!(intentForm._json || "").trim()}
                          style={{ ...Btn((intentForm._json || "").trim() ? T.sageBg : T.panelBg, (intentForm._json || "").trim() ? T.sageBd : T.border, (intentForm._json || "").trim() ? T.done : T.text3, true), flex: 1, fontSize: "13px", fontWeight: "500", padding: "10px", opacity: (intentForm._json || "").trim() ? 1 : 0.5 }}>
                          Add Collection ->
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "14px" }}>
                        <div><label style={Lbl}>Working name</label><input value={intentForm.name} onChange={e => setIntentForm(p => ({ ...p, name: e.target.value }))} placeholder="e.g. Winter Solstice" style={Inp(T)} /></div>
                        <div><label style={Lbl}>Season & timing</label><input value={intentForm.season} onChange={e => setIntentForm(p => ({ ...p, season: e.target.value }))} placeholder="e.g. Late winter, Jan-Mar" style={Inp(T)} /></div>
                      </div>
                      <div style={{ marginBottom: "14px" }}>
                        <label style={{ ...Lbl, display: "flex", justifyContent: "space-between" }}>
                          <span>Collection intent <span style={{ color: T.err }}>*</span></span>
                          <span style={{ color: T.text3, fontWeight: "400" }}>Be evocative</span>
                        </label>
                        <textarea value={intentForm.brief} onChange={e => setIntentForm(p => ({ ...p, brief: e.target.value }))}
                          placeholder="Describe the feeling, atmosphere, mood, and world of this collection..."
                          style={{ ...Inp(T), height: "100px", resize: "none" }} />
                      </div>
                      <div style={{ marginBottom: "16px" }}>
                        <label style={Lbl}>Hero floral(s) <span style={{ color: T.text3, fontWeight: "400" }}>optional</span></label>
                        <input value={intentForm.hero} onChange={e => setIntentForm(p => ({ ...p, hero: e.target.value }))} placeholder="e.g. burgundy dahlias, moody ranunculus" style={Inp(T)} />
                      </div>
                      {genError && !isGenerating && (
                        <div style={{ marginBottom: "12px", padding: "10px 14px", background: "#FDF0F0", border: "1px solid #E0B8B8", borderRadius: "6px", color: "#8B3030", fontSize: "11px" }}>{genError}</div>
                      )}
                      <div style={{ display: "flex", gap: "8px" }}>
                        <button onClick={() => setShowIntent(false)} style={{ ...Btn(T.panelBg, T.border, T.text2), flex: "0 0 auto", padding: "10px 18px", fontSize: "12px" }}>Cancel</button>
                        <button onClick={handleGenerate} disabled={!intentForm.brief.trim()}
                          style={{ ...Btn(intentForm.brief.trim() ? T.sageBg : T.panelBg, intentForm.brief.trim() ? T.sageBd : T.border, intentForm.brief.trim() ? T.done : T.text3, true), flex: 1, fontSize: "13px", fontWeight: "500", padding: "10px", opacity: intentForm.brief.trim() ? 1 : 0.5 }}>
                          Generate with Claude ->
                        </button>
                      </div>
                      <div style={{ marginTop: "10px", fontSize: "10px", color: T.text3, textAlign: "center" }}>Requires API key . desktop recommended</div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// -- Style helpers -----------------------------------------
const Btn = (bg, border, color, bold = false) => ({
  background: bg, border: `1px solid ${border}`, borderRadius: "6px",
  color, cursor: "pointer", padding: "5px 12px",
  fontWeight: bold ? "500" : "400", transition: "all 0.15s"
});

const Lbl = {
  display: "block", fontSize: "10px", letterSpacing: "0.06em",
  textTransform: "uppercase", color: "#9C9690", marginBottom: "6px", fontWeight: "500"
};

const Inp = T => ({
  width: "100%", background: T.inputBg, border: `1px solid ${T.border}`,
  borderRadius: "6px", color: T.text1, fontSize: "12px",
  padding: "8px 12px", outline: "none", fontFamily: "system-ui, sans-serif",
  boxSizing: "border-box"
});

# AI Image Generation Prompts: "Winter's Embrace" Wreath
## Complete Prompt Library for Individual Elements + Wreath Compositions

---

# PART 1: INDIVIDUAL FLORAL ELEMENT PROMPTS

## Primary Elements

### 1. Eucalyptus Stems (Seeded)

**Product Photography Style:**
```
Professional product photograph of single artificial seeded eucalyptus stem, 12-14 inches long, on pure white background. Dusty sage green leaves with silver-gray undertones, matte finish with slightly fuzzy round seed pods evenly distributed along stem. Natural botanical appearance, ultra-sharp focus showing realistic faux foliage texture, soft directional lighting from upper left creating gentle shadows, high-end silk flower quality, professional florist supply catalog image, Canon EOS R5, 100mm macro lens, f/5.6, even studio lighting, color-accurate sage green with silvery highlights.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial eucalyptus seed pods and leaves, showing intricate textile construction and realistic botanical details. Fuzzy matte seed pods in dusty sage green with silver sheen, detailed leaf venation, soft natural texture. Shallow depth of field with seed pod cluster in sharp focus, stem fading to soft blur, white seamless background, side lighting emphasizing dimensional texture, luxury artificial botanical craftsmanship, fine art still life photography style.
```

---

### 2. Lambs Ear Foliage

**Product Photography Style:**
```
Professional product photograph of single artificial lambs ear leaf stem, 8-10 inches long, on pure white background. Silver-gray velvety textured leaves with soft sage green base color, realistic fuzzy surface appearance mimicking natural lambs ear plant. Multiple leaves along single stem, ultra-sharp focus showing plush textile construction, soft even studio lighting, high-quality faux botanical, professional florist catalog image, top-down angled view showing leaf shape and surface texture, Canon macro lens, f/4, color-accurate silver-gray with green undertones.
```

**Artistic Detail Style:**
```
Extreme close-up macro of artificial lambs ear leaf showing velvety fuzzy texture surface, silver-gray color with subtle green base. Dramatic side lighting creating texture shadows across plush fabric surface, ultra-sharp focus on tactile fibers, white background completely out of focus, luxury botanical craftsmanship detail, fine art macro photography, shallow depth of field isolating single leaf, soft and sophisticated aesthetic.
```

---

### 3. White Ranunculus

**Product Photography Style:**
```
Professional product photograph of single large artificial white ranunculus flower, 3-4 inch diameter, on pure white background. Cream white layered petals with subtle blush pink center, realistic paper-like petal texture with delicate edges, multiple concentric petal layers creating full romantic bloom. Ultra-sharp focus throughout flower showing high-quality silk construction, soft even lighting from above, professional florist supply catalog image, slight three-quarter angle showing dimensional depth, green stem visible, Canon 100mm macro, f/8, luxury artificial flower quality.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial ranunculus flower center showing intricate layered petal construction, cream white petals with soft blush pink gradient in center. Shallow depth of field with sharp focus on center petals, outer petals fading to dreamy blur, paper-like petal texture clearly visible, soft directional lighting creating gentle shadows between petal layers, white seamless background, fine art floral photography, romantic and delicate aesthetic, professional macro lens work.
```

**Bloom Cluster Style:**
```
Professional photograph of three artificial white ranunculus blooms clustered together, varying sizes 3-4 inches, on white background. Cream petals with blush centers, overlapping composition showing how flowers nest together naturally, stems crossing at base, ultra-sharp focus across all three blooms, soft studio lighting, professional arrangement demonstration image, florist design reference photo, shows scale and grouping for wreath work.
```

---

### 4. Blush Peonies

**Product Photography Style - Large Bloom:**
```
Professional product photograph of single large artificial blush pink peony flower, 4-5 inch diameter, on pure white background. Soft blush pink ruffled petals fading to cream edges, full romantic bloom with multiple petal layers, realistic silk fabric construction with natural petal variation. Ultra-sharp focus showing petal texture and layering, soft even studio lighting, three-quarter view angle showing dimensional fullness, short green stem visible, Canon 100mm macro, f/5.6, luxury wedding flower quality, professional florist catalog image.
```

**Product Photography Style - Medium Bloom:**
```
Professional product photograph of single medium artificial blush pink peony flower, 3 inch diameter, on pure white background. Delicate blush pink color with cream petal edges, ruffled romantic petals, slightly less open than full bloom showing some center petals still gathered. Ultra-sharp focus, soft studio lighting, angled view showing bloom structure, high-quality silk flower construction, professional catalog image for wedding florals.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial peony bloom center showing intricate ruffled petal layers, soft blush pink gradient fading to cream at petal edges. Shallow depth of field with center in sharp focus, outer petals creating dreamy soft blur, realistic fabric texture visible on petals, side lighting creating gentle shadows emphasizing ruffled texture, white seamless background, fine art romantic floral photography, luxury artificial flower craftsmanship.
```

**Bloom Cluster Style:**
```
Professional photograph of three artificial blush peonies clustered together - one large 5-inch bloom and two medium 3-inch blooms - on white background. Varying stages of openness, overlapping petals creating natural bouquet effect, soft blush pink with cream edges throughout, ultra-sharp focus across entire grouping, soft studio lighting, florist arrangement reference photo showing scale relationships and clustering technique.
```

---

### 5. Dried Statice

**Product Photography Style:**
```
Professional product photograph of artificial dried statice cluster, 4-6 small flower heads on branched stem, on pure white background. Pale lavender-gray papery flowers with delicate cloud-like texture, matte finish mimicking natural dried statice, thin wiry stems. Ultra-sharp focus showing realistic dried flower construction, soft even lighting, airy and delicate appearance, professional florist supply catalog image, top-down angled view, Canon macro lens, f/5.6, subtle and sophisticated dried botanical aesthetic.
```

**Artistic Detail Style:**
```
Extreme close-up macro of artificial dried statice flower clusters showing papery delicate texture, pale lavender-gray color with subtle purple undertones. Shallow depth of field isolating single flower cluster in sharp focus, branching stems creating geometric interest in soft background blur, side lighting creating translucent effect on papery petals, white seamless background, fine art botanical photography, ethereal and delicate aesthetic.
```

---

### 6. Artificial Berries (Frosted)

**Product Photography Style:**
```
Professional product photograph of single artificial frosted berry cluster, 8-12 berries per cluster on wired stem, on pure white background. Dusty mauve berries 8mm diameter each with white frosted coating creating matte sparkle finish, naturally irregular cluster arrangement on thin flexible wire stem. Ultra-sharp focus showing frosted texture detail, soft studio lighting creating subtle highlights on frost coating, professional holiday floral supply catalog image, Canon macro lens, f/8, elegant winter berry aesthetic.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial frosted berries showing detailed matte sparkle coating, dusty mauve base color with white crystalline frost effect. Three to five berries in sharp focus showing texture variation, shallow depth of field with background berries softly blurred, side lighting emphasizing frosted surface texture and subtle shine, white seamless background, fine art still life photography, sophisticated winter botanical detail.
```

**Multi-Cluster Style:**
```
Professional photograph of three separate artificial frosted berry clusters arranged on white background, showing variety in cluster sizes and berry groupings. Dusty mauve with white frost coating throughout, ultra-sharp focus across all clusters, soft even lighting, florist supply reference image showing how clusters vary naturally, design planning photo for wreath component layout.
```

---

### 7. Preserved Fern Fronds

**Product Photography Style:**
```
Professional product photograph of single artificial preserved fern frond, 6-8 inches long, on pure white background. Sage green color with subtle brown undertones, delicate feathery pinnate leaf structure with fine detailed leaflets along central stem. Ultra-sharp focus showing realistic dried botanical texture, soft even studio lighting, side angle showing natural graceful curve of frond, professional botanical supply catalog image, Canon 100mm macro, f/5.6, elegant preserved plant aesthetic.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial fern frond showing intricate feathery leaflet detail, sage green with brown undertones creating aged preserved appearance. Shallow depth of field with mid-section of frond in sharp focus, delicate geometric pattern of leaflets clearly visible, side lighting creating shadows between leaflets emphasizing dimensional structure, white seamless background, fine art botanical photography, sophisticated natural texture study.
```

---

### 8. Cream Lisianthus

**Product Photography Style:**
```
Professional product photograph of single artificial cream lisianthus flower, 2-3 inch diameter, on pure white background. Ivory cream rose-like petals with slightly waxy realistic texture, semi-open bloom showing some center detail, multiple delicate petals creating full romantic flower. Ultra-sharp focus throughout bloom, soft even studio lighting, three-quarter angled view showing dimensional structure, short green stem and small bud visible, Canon 100mm macro, f/5.6, luxury silk flower quality, professional wedding florist catalog image.
```

**Artistic Detail Style:**
```
Extreme macro close-up of artificial lisianthus bloom center showing waxy petal texture and ivory cream color, delicate rose-like petal arrangement. Shallow depth of field with center petals in sharp focus fading to soft blur at edges, side lighting creating gentle highlights on waxy petal surface, white seamless background, fine art floral photography, elegant and sophisticated aesthetic, realistic silk flower craftsmanship detail.
```

---

# PART 2: WREATH COMPOSITION PROMPTS

## Full Wreath Views

### Master Hero Shot (Primary Product Image)

```
A luxurious 24-inch diameter faux floral wreath photographed from directly front, perfectly centered composition against pure white seamless background, professional high-end product photography lighting. Natural grapevine base wreath adorned with dusty sage eucalyptus branches with silver seed pods, soft silver-gray velvety lambs ear foliage, cream white ranunculus flowers with subtle blush centers, blush pink peonies with ruffled petals, pale lavender dried statice clusters, frosted mauve berries, sage green preserved fern fronds, and ivory lisianthus blooms. Two distinct focal points clearly visible: lower right quadrant features dense clustered white ranunculus arrangement (4-7 o'clock position), upper left showcases large statement blush peony as hero bloom (10-11 o'clock position). Dramatic dimensional depth with elements extending 4-6 inches forward from base creating sculptural three-dimensional effect. Romantic sophisticated color palette of sage greens, cream whites, soft blush pinks, and silver grays creating cohesive winter elegance. Soft natural-style lighting from upper left with gentle shadows showing depth and dimensional layering. Ultra-high resolution 8K quality, razor-sharp focus on all flower petals showing realistic texture detail, professional luxury florist quality, elegant winter wedding aesthetic, Canon EOS R5 with 85mm f/1.4 lens shot at f/2.8, soft directional key light with fill, color-graded for natural accuracy.
```

---

### Alternate Angle - Three-Quarter View

```
Professional product photograph of 24-inch luxury faux floral wreath captured from 45-degree three-quarter angle against pure white background, showing dimensional depth and sculptural construction. Natural grapevine wreath base with dusty sage eucalyptus, silver lambs ear, cream ranunculus cluster, large blush peony hero bloom, pale statice, frosted mauve berries, fern fronds, and ivory lisianthus. Angle emphasizes how elements extend 4-6 inches forward from base, showing layered depth of focal points at lower right and upper left positions. Soft studio lighting creating natural shadows that define three-dimensional structure, ultra-sharp focus across entire wreath, professional luxury product photography, Canon 85mm lens, f/4, sophisticated winter color palette, premium florist quality demonstration.
```

---

### Perfectly Centered Straight-On (Catalog Standard)

```
Professional catalog product photograph of 24-inch faux floral wreath, perfectly centered front-facing view, pure white background, completely even studio lighting. Natural grapevine base with dusty sage eucalyptus distributed evenly around circumference, two distinct focal points: ranunculus cluster at lower right (5 o'clock), large blush peony at upper left (11 o'clock). Silver lambs ear, pale lavender statice, frosted mauve berries, sage fern fronds, ivory lisianthus creating balanced asymmetric design. Sharp focus edge to edge showing all components in equal detail, no dramatic shadows, bright and clean presentation, professional florist supply catalog image, product specification reference photo, Canon macro lens, f/8 for maximum depth of field, color-accurate rendering of complete wreath design.
```

---

### Dramatic Mood Lighting Shot

```
Artistic product photograph of 24-inch luxury faux floral wreath against pure white background with dramatic side lighting creating strong shadows and dimensional emphasis. Natural grapevine wreath with dusty sage eucalyptus, silver lambs ear, cream ranunculus, blush peonies, pale statice, frosted berries, fern fronds. Single key light from left side at 45-degree angle creating chiaroscuro effect, deep shadows between layers emphasizing 6-inch depth, highlights catching frosted berry sparkle and peony petal texture. Moody and sophisticated, ultra-sharp focus on hero peony bloom with gradual focus fall-off, fine art product photography style, Canon 85mm f/1.4 at f/2, elegant and dramatic winter wreath presentation.
```

---

## Detail & Close-Up Shots

### Detail Shot 1: Ranunculus Focal Point (Lower Right)

```
Extreme close-up macro photograph of cream white ranunculus flower cluster focal point on faux winter wreath, filling frame with detailed view of lower right quadrant section. Five ranunculus blooms clustered together showing intricate layered paper-like petals with subtle blush pink centers, surrounded by dusty sage eucalyptus stems with silver seed pods, two frosted mauve berry clusters tucked between blooms, and delicate pale statice creating soft texture. Natural grapevine base visible in background providing rustic texture contrast. Soft natural window-style light from upper left, white background gently out of focus, ultra-sharp focus on center ranunculus petals showing realistic artificial flower craftsmanship, depth of field highlighting three-dimensional clustered arrangement creating forward depth, Canon 100mm macro lens, f/2.8, professional luxury floral product photography, gentle shadows revealing petal layering and dimensional placement.
```

---

### Detail Shot 2: Peony & Lambs Ear Focal Point (Upper Left)

```
Close-up detail photograph of large 5-inch blush pink peony hero bloom on faux wreath focal point, filling upper third of frame with dramatic romantic presence. Full ruffled peony with blush pink petals fading to cream edges, nestled against backdrop of soft velvety silver-gray lambs ear foliage creating contrasting texture, with two smaller medium peonies visible in composition and ivory lisianthus accent flowers adding balance. Hero flower positioned slightly off-center left in frame, photographed at 45-degree angle showing dimensional depth and intricate petal layers, natural grapevine wreath base visible in background providing rustic texture. Soft diffused lighting from above creating gentle shadows between ruffled petals, white backdrop, professional florist product photography, sharp focus on peony center with gradual focus fall-off creating depth, showing realistic high-quality artificial flower construction, winter wedding color palette, elegant and sophisticated romantic styling, Canon 100mm macro, f/2.8.
```

---

### Detail Shot 3: Texture & Depth Study (Side Angle)

```
Artistic angle photograph of faux wreath section showing layered depth and texture variety, captured from 30-degree side angle emphasizing three-dimensional construction. Foreground features frosted mauve berry cluster in razor-sharp focus with matte sparkle coating clearly visible, mid-ground shows cream ranunculus petals and sage eucalyptus leaves in moderate focus, background displays soft pale lavender statice clusters and feathery fern fronds extending outward creating depth layers fading to gentle blur. Natural grapevine base texture visible creating rustic foundation. Professional studio lighting highlighting texture contrasts: velvety lambs ear, papery statice, waxy lisianthus petals, matte frosted berries, fuzzy eucalyptus seed pods. White seamless background, shallow depth of field (f/4) creating pronounced focus fall-off, Canon 85mm lens, demonstrating premium artificial flower construction quality and sophisticated color harmony of sage, cream, blush, and silver tones, fine art product photography aesthetic.
```

---

### Detail Shot 4: Eucalyptus & Fern Texture

```
Close-up macro photograph of wreath transitional zone showing dusty sage eucalyptus stems with silver seed pods interwoven with delicate feathery fern fronds, creating textural contrast study. Eucalyptus stems angled 25-35 degrees outward with matte fuzzy seed pods, fern fronds extending at 45-60 degree angles creating airy dimension, natural grapevine base visible between elements. Ultra-sharp focus on eucalyptus seed pod cluster in foreground, fern fronds in mid-ground sharp focus, background fading to soft blur, white seamless background, side lighting emphasizing botanical textures, professional product detail photography, Canon 100mm macro, f/4, sophisticated green-on-green tonal study.
```

---

### Detail Shot 5: Berry & Statice Delicate Elements

```
Extreme macro close-up of frosted mauve berry cluster nestled among pale lavender statice flowers on wreath, showing delicate accent element pairing. Three to five berries in sharp focus showing white frosted coating with subtle sparkle, surrounded by cloud-like papery statice blooms creating soft textural contrast, hints of cream ranunculus petals softly blurred in background. Side lighting creating translucent effect on statice and highlighting frost texture on berries, white seamless background, shallow depth of field isolating subject, fine art botanical detail photography, Canon 100mm macro, f/2.8, elegant winter accent elements, sophisticated dusty mauve and lavender-gray color palette.
```

---

## Lifestyle & Context Shots

### Lifestyle Shot 1: Modern Farmhouse Entryway

```
Elegant faux winter wreath hanging on white shiplap wall above modern farmhouse console table, photographed in bright naturally lit entryway interior scene. The 24-inch wreath features romantic blush peonies, cream ranunculus, dusty sage eucalyptus, and silver lambs ear in sophisticated winter palette, centered on wall at eye level. Styled console table below includes slim white ceramic vase with fresh eucalyptus stems, pair of small brass candlesticks, neutral oatmeal linen table runner, and small potted succulent. Soft morning light streaming from right side window creating gentle shadows, bright and airy atmosphere, white walls and light wood flooring, whole scene evoking peaceful luxury and enduring warmth. Interior design photography style, Instagram-worthy home decor aesthetic, professional real estate photography quality, Sony A7III, 35mm lens, f/4, natural color grading emphasizing whites, creams, and soft greens, sharp focus on wreath with console styling in supporting focus.
```

---

### Lifestyle Shot 2: Bedroom Above Dresser

```
Luxury faux winter wreath hanging on soft gray accent wall above vintage white dresser in serene master bedroom, photographed in natural window light. 24-inch wreath with blush peonies and cream flowers creating romantic focal point, centered above dresser at 6 feet height. Dresser styling includes white ceramic lamp with linen shade, small brass mirror, and white ceramic tray with jewelry. Soft natural light from left window creating gentle illumination, glimpse of white bedding and sage green throw pillow in foreground blur, whole scene creating peaceful sanctuary aesthetic. Interior design lifestyle photography, soft and romantic mood, professional home staging quality, Canon 5D Mark IV, 50mm lens, f/2.8, warm natural color grading, aspirational bedroom decor inspiration.
```

---

### Lifestyle Shot 3: Dining Room Wall Display

```
Faux winter wreath displayed on dining room wall above modern wood sideboard, photographed in naturally lit interior with large windows. 24-inch wreath creating elegant focal point with blush and cream florals, hanging centered on sage green painted accent wall. Sideboard styling includes white ceramic serving pieces, brass candlesticks with white candles, and wooden bowl with eucalyptus. Dining table visible in foreground with white chairs and linen napkins, natural wood tones throughout, bright and welcoming atmosphere. Interior design editorial photography, entertaining and hosting aesthetic, professional home magazine quality, natural window light from left, Canon EOS R, 35mm lens, f/4, balanced color grading emphasizing greens, whites, and natural wood tones.
```

---

### Lifestyle Shot 4: Front Door Exterior

```
Luxury faux winter wreath hanging on white front door of modern farmhouse exterior, photographed in soft natural daylight. 24-inch wreath centered on door with black hardware, blush peonies and sage eucalyptus creating welcoming entrance statement. White horizontal siding, black door frame, glimpse of front porch with white rocking chair and potted plants, winter greenery in planters flanking door. Soft overcast natural light creating even illumination without harsh shadows, welcoming and sophisticated curb appeal, professional real estate exterior photography, Canon 5D Mark IV, 35mm lens, f/5.6, natural color grading, aspirational home exterior styling, Instagram-worthy entry decor.
```

---

## Technical & Reference Shots

### Overhead Flat Lay (Design Pattern Blueprint View)

```
Directly overhead flat lay photograph of 24-inch faux winter wreath on pure white background, perfect circle composition shot from bird's eye view showing complete design pattern and exact floral placement for reference documentation. Natural grapevine wreath base with dusty sage eucalyptus stems distributed evenly around entire circumference creating foundation layer, two distinct focal points clearly mapped: clustered cream ranunculus arrangement at 5 o'clock position (150-degree mark), large blush peony cluster at 10-11 o'clock position (300-330 degree mark). Silver-gray lambs ear placed at focal points, pale lavender statice clusters filling transitional zones, frosted mauve berry clusters at focal points, sage fern fronds radiating outward at strategic angles, ivory lisianthus blooms creating balance opposite focal points. Completely even overhead studio lighting eliminating all shadows, ultra-sharp focus across entire wreath circumference showing all elements in equal detail without any depth-of-field blur, product catalog photography style, high-resolution blueprint reference quality showing exact component placement and spacing, professional florist technical documentation image, color-accurate rendering of sage, cream, blush, and silver palette, Canon macro lens, f/11 for maximum depth of field, tethered shooting for precision alignment.
```

---

### Side Profile (Dimensional Depth Documentation)

```
Side profile photograph of faux wreath showing 6-inch maximum dimensional depth and sculptural three-dimensional construction, captured from direct 90-degree side view against pure white seamless background. Wreath positioned vertically showing how floral elements extend outward from 18-inch natural grapevine base in layered depth zones. Large blush peony hero bloom prominently extending 4 inches forward from base creating maximum projection, cream ranunculus cluster showing varied depths from 1-3 inches creating mid-range layers, eucalyptus branches angled 25-35 degrees outward establishing foundation depth, fern fronds reaching furthest at 45-60 degree angles creating outermost dimensional layer. Dramatic side lighting (chiaroscuro style) positioned 90 degrees from camera creating strong shadows that emphasize depth zones and dimensional layers, professional product photography showcasing construction quality and spatial design, sharp focus throughout entire profile showing how each element contributes to overall volume and three-dimensional presence, luxury floral design demonstration image, architectural photography approach to floral art documentation, Canon 85mm lens, f/8, technical reference for depth specifications.
```

---

### Construction Detail - Grapevine Base Texture

```
Close-up macro photograph of natural grapevine wreath base showing rustic texture detail before floral elements added, photographed against white background. Twisted vine branches woven together creating organic circular form, brown-gray natural wood texture with rough bark, visible wire reinforcement at connection points. Ultra-sharp focus showing vine texture detail, soft even lighting, professional supply documentation image showing base material quality, Canon 100mm macro, f/5.6, natural wood tones, reference image for wreath foundation specifications.
```

---

### Component Layout Grid (Assembly Reference)

```
Overhead flat lay photograph showing all individual floral components laid out separately in organized grid pattern on white background before assembly, professional florist workstation documentation. Top row: 8 eucalyptus stems arranged horizontally, second row: 12 lambs ear pieces, third row: 5 white ranunculus blooms, fourth row: 3 blush peonies (size variation visible), fifth row: clusters of statice, berries, fern fronds, and lisianthus blooms. 18-inch grapevine base positioned separately. All components labeled with quantity counts, even studio lighting, ultra-sharp focus across entire layout, professional tutorial reference image, assembly instruction documentation, Canon 50mm lens, f/8, color-accurate product photography for component inventory visualization.
```

---

# USAGE NOTES

**For Individual Element Prompts:**
- Use "Product Photography Style" for catalog/inventory images
- Use "Artistic Detail Style" for emotional marketing content
- Use "Cluster Style" (where provided) for showing scale/grouping

**For Wreath Composition Prompts:**
- "Master Hero Shot" = primary e-commerce product image
- "Catalog Standard" = technical specification reference
- Detail shots = secondary product images showing craftsmanship
- Lifestyle shots = aspirational marketing content
- Technical shots = assembly instructions and blueprints

**Recommended AI Tools:**
- Midjourney v6: Best for artistic/lifestyle shots
- DALL-E 3: Best for product photography precision
- Stable Diffusion XL: Best for batch generation consistency

**Prompt Modification Tips:**
- Add "--ar 1:1" for square compositions
- Add "--ar 4:5" for portrait Instagram posts
- Add "--ar 16:9" for landscape lifestyle shots
- Adjust f-stop numbers for depth of field control
- Modify lighting direction (left/right/above) for variation

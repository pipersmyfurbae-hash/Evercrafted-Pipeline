# Photorealistic Wreath Blueprint - Image Generation Prompts

## PROMPT 1: Technical Blueprint View (Top-Down)
**Purpose:** Manufacturing schematic with polar coordinate overlay

**Prompt:**
"Professional technical blueprint drawing of a 24-inch Christmas wreath, top-down orthographic view, white background. Precise polar coordinate grid overlay with degree markings (0°, 30°, 60°, 90°, 120°, 150°, 180°, 210°, 240°, 270°, 300°, 330°) and concentric radius circles at 8", 9", 10", 11", and 12" from center. Each floral element labeled with material codes (M001-M006) and coordinate annotations. Noble fir branches in deep forest green, frosted eucalyptus in sage with white frost, silver birch branches in natural white, pine cones in brown with white tips, champagne gold berries, cream velvet ribbon bow at 270°. Clean architectural drawing style with dimension arrows, measurement callouts, and material legend. CAD-quality linework, professional blueprint aesthetic, high detail, 8K resolution, photorealistic materials within technical drawing context."

---

## PROMPT 2: Photorealistic Front View
**Purpose:** Product photography showing completed wreath

**Prompt:**
"Hyper-realistic professional product photography of a 24-inch luxury Christmas wreath hanging on white shiplap wall. Wreath features deep forest green noble fir branches as foundation, frosted eucalyptus stems with delicate white shimmer, natural white birch branches creating architectural dimension, 9 realistic pine cones with white-tipped scales positioned at focal points following golden ratio, clusters of metallic champagne gold berries catching light, cream velvet ribbon bow at bottom with 14-inch tails. Perfect circular form, 6 inches of depth creating dramatic shadows, materials look real and tangible. Soft natural window light from left creating gentle shadows, professional studio photography, macro detail visible in pine cone textures and frost on eucalyptus, no artificial looking elements, every material appears touchable and authentic, 8K resolution, shot with 85mm lens, shallow depth of field on bow with wreath in sharp focus."

---

## PROMPT 3: Isometric Technical View
**Purpose:** 3D dimensional blueprint showing depth and layering

**Prompt:**
"Isometric technical illustration of 24-inch wreath blueprint, 30-degree angle revealing depth and layering. Transparent overlay showing internal wire frame structure (18-inch double-ring base). Color-coded layers: Layer 1 (foundation noble fir in dark green), Layer 2 (frosted eucalyptus in translucent sage), Layer 3 (birch branches in white with measurement lines), Layer 4 (pine cones with depth indicators 4.5"-5.5"), Layer 5 (berry clusters with 3D positioning arrows). Polar coordinate grid visible as light blue wireframe. Dimension callouts showing 24" outer diameter, 14" inner diameter, 6" maximum depth. Material cross-sections showing stem insertion angles. Professional CAD rendering style, clean white background, precise measurements, engineering blueprint aesthetic mixed with realistic material textures, 8K resolution, technical perfection."

---

## PROMPT 4: Detail Close-Up (Focal Area)
**Purpose:** Showcase material quality and texture relationships

**Prompt:**
"Extreme macro photograph of wreath section at 0° position, showing layering detail and material interaction. In sharp focus: one large pine cone (3 inches) with realistically textured scales tipped in white frost, emerging from deep forest green noble fir needles, accompanied by frosted eucalyptus leaf cluster with visible glitter coating, champagne gold berries catching directional light creating specular highlights, natural birch branch with authentic black bark marks visible in background blur. Depth of field shows 6 inches of dimensional layering. Natural daylight, professional macro photography, every texture crisp and tangible - can see individual pine cone scales, needle structure of fir, velvet surface of eucalyptus frost, metallic sheen on berries. Shot with 100mm macro lens at f/2.8, 8K resolution, no artificial or fake-looking materials, botanical photography quality."

---

## PROMPT 5: Exploded Assembly View
**Purpose:** Show component separation and assembly sequence

**Prompt:**
"Exploded axonometric diagram of 24-inch wreath assembly, components floating in organized layers above base ring. Bottom: 18-inch wire wreath frame in dark gray metal. Layer 1 (floating 4" above): 12 noble fir stems arranged in circle with angle annotations (0°, 30°, 60°, etc.). Layer 2 (8" above): 8 frosted eucalyptus stems with placement arrows. Layer 3 (12" above): 6 birch branches with rotation indicators. Layer 4 (16" above): 9 pine cones with golden ratio distribution pattern highlighted. Layer 5 (20" above): 12 berry clusters with spacing guides. Top (24" above): Cream velvet ribbon bow with construction diagram. Each component labeled with material code and polar coordinates. Dashed lines connecting components to final positions on base. Clean white background, professional technical illustration style, photorealistic material rendering, assembly sequence numbers, 8K resolution."

---

## PROMPT 6: Polar Coordinate Overlay Diagram
**Purpose:** Pure technical schematic for manufacturing

**Prompt:**
"Precision engineering schematic, top-down view, 24-inch diameter circle on white background. Polar coordinate system with origin at center. Concentric circles at exact measurements: 7" (inner boundary), 9" (base layer), 10.5" (secondary layer), 12" (outer boundary). Radial lines every 15 degrees with clear numerical labels (0°, 15°, 30°, 45°, etc.). Each material placement marked with precise coordinate notation: 'M001 @ θ=45°, r=9", d=2.5", rot=60°'. Color coding: Noble fir (dark green dots), Eucalyptus (sage green triangles), Birch (white squares), Pine cones (brown circles), Berries (gold stars), Bow (cream ribbon symbol at 270°). Grid lines, measurement callouts, legend box in corner, professional CAD blueprint style, black line art on white, mathematical precision, manufacturing-ready schematic, 8K resolution, suitable for CNC or precision assembly."

---

## PROMPT 7: Mood/Lifestyle Context
**Purpose:** Emotional marketing shot showing wreath in real setting

**Prompt:**
"Elegant lifestyle photograph of 24-inch luxury Christmas wreath hanging on charcoal gray front door of upscale modern farmhouse. Late afternoon golden hour light creating warm glow on cream velvet bow and champagne berries. Wreath showcases rich forest green noble fir foundation, delicate frosted eucalyptus catching sunlight, natural birch branches creating organic movement, pine cones with realistic texture and white frost detail, bow tails gently swaying. Visible through nearby window: soft white curtains, warm interior lighting, hints of decorated Christmas tree. Wreath casts subtle shadow on door, depth and dimension clearly visible. Professional real estate photography quality, inviting and warm color palette, perfect focus on wreath with slight background blur, natural materials look authentic and high-end, 8K resolution, shot with 50mm lens at f/4, no artificial or plasticky appearance."

---

## PROMPT 8: Material Palette Reference
**Purpose:** Flat lay of all components before assembly

**Prompt:**
"Overhead flat lay photograph on white marble surface showing all wreath materials organized before assembly. Top row: 12 noble fir stems (14" long) arranged in parallel, rich forest green with realistic needle texture. Second row: 8 frosted eucalyptus stems (10" long) with visible white glitter coating on sage green leaves. Third row: 6 silver birch branches (12" long) showing natural white bark with black markings. Fourth row: 9 pine cones (3" diameter) displaying dimensional scales with white tips. Fifth row: 12 champagne gold berry clusters, metallic finish catching overhead light. Bottom: 72" cream velvet ribbon artfully curved, 2.5" width visible, luxurious texture apparent. Center: 18" wire wreath frame. Each material group labeled with code (M001-M006). Professional styling, perfect overhead lighting, every texture sharp and detailed, natural shadows, 8K resolution, botanical specimen photography quality, materials look premium and touchable."

---

## PROMPT 9: Cross-Section Technical View
**Purpose:** Show internal structure and depth engineering

**Prompt:**
"Architectural cross-section diagram of wreath, cutaway view revealing internal construction. Left half shows external photorealistic appearance: noble fir, eucalyptus, birch, pine cones, berries, and bow in full color and texture. Right half shows technical cross-section: wire frame structure in gray wireframe, floral stems inserted at precise angles (45°, 60°, 70° from horizontal), depth measurements annotated (2"-6" from base plane), material layers numbered and labeled, wire attachment points highlighted in red, structural support zones indicated. Dimension lines showing: 24" outer diameter, 14" inner opening, 6" maximum projection depth, 18" base ring diameter. Hybrid illustration combining photorealistic materials (left) with technical schematic (right), clean white background, professional engineering drawing standards, 8K resolution, suitable for manufacturing documentation."

---

## PROMPT 10: 360° Rotation Composite
**Purpose:** Multi-angle view showing complete form

**Prompt:**
"Four-panel composite image showing same 24-inch wreath from multiple angles on white background. Panel 1 (top left): Front view, wreath facing camera, cream bow at bottom (6 o'clock position), symmetrical display of all materials, perfect circular form. Panel 2 (top right): Three-quarter right view, showing 6-inch depth, dimensional layering of birch branches, pine cones creating shadow depth, bow visible at angle. Panel 3 (bottom left): Side profile view, dramatic depth visible, materials projecting at varying distances from base plane, bow tails hanging vertically. Panel 4 (bottom right): Three-quarter left view, complementing right view, showing balance and material distribution. All panels same lighting (soft directional from upper left), professional product photography, consistent white background, each view sharp and detailed, materials appear authentic in all angles, 8K resolution, perfect for e-commerce presentation."

---

## TECHNICAL SPECIFICATIONS FOR ALL RENDERS

**Universal Settings:**
- Resolution: 8K (7680 × 4320 minimum)
- Color Space: sRGB for web, Adobe RGB for print
- File Format: PNG with transparency for technical diagrams, JPEG for lifestyle shots
- Aspect Ratio: 16:9 for composite views, 1:1 for blueprint/technical views
- Lighting: Consistent soft directional light from upper left (315° at 45° elevation) unless otherwise specified
- Material Realism: All elements must look tangible and authentic, avoid artificial/plastic appearance
- Focus: Maintain sharp detail on foreground elements, acceptable shallow DOF for depth in lifestyle shots

**Accuracy Requirements:**
- Maintain exact 24" diameter in all scaled views
- Polar coordinates must be mathematically accurate
- Material colors must match specified palette: forest green, sage with white frost, natural birch white, brown with white tips, champagne gold, cream
- All measurements and annotations must be legible at full resolution
- Bow position fixed at 270° (bottom center) in all views

**Material Texture Notes:**
- Noble fir: Soft, realistic needle clusters with slight sheen
- Eucalyptus: Smooth leaves with delicate glitter/frost coating
- Birch: Natural wood texture with authentic black bark marks
- Pine cones: Dimensional scales with subtle color variation
- Berries: Metallic champagne with specular highlights
- Ribbon: Velvet texture with subtle light absorption and sheen

---

## RECOMMENDED AI GENERATION WORKFLOW

1. **Start with PROMPT 1** (Blueprint) - Establishes technical foundation
2. **Generate PROMPT 6** (Polar Diagram) - Validates coordinate system
3. **Create PROMPT 2** (Photorealistic Front) - Main product hero shot
4. **Produce PROMPT 3** (Isometric) - Shows 3D structure
5. **Detail with PROMPT 4** (Macro Close-Up) - Proves material quality
6. **Support with PROMPT 5** (Exploded View) - Assembly understanding
7. **Context with PROMPT 7** (Lifestyle) - Emotional connection
8. **Reference with PROMPT 8** (Material Palette) - Component verification
9. **Technical with PROMPT 9** (Cross-Section) - Engineering detail
10. **Complete with PROMPT 10** (360° Composite) - Comprehensive view

**Iteration Strategy:**
- Generate each prompt 3-5 times to select best result
- Use consistent seed values for technical diagrams to maintain accuracy
- Adjust lighting/composition parameters for lifestyle shots to find optimal mood
- Combine technical accuracy of early renders with material realism of later renders
